
(function () {
  'use strict';
  if (window.HansenTTSVolume) return;

  var KEY = 'hansen_tts_volume';
  var SILENT_MAX = 0.01;

  function read() {
    try {
      var v = parseInt(localStorage.getItem(KEY), 10);
      if (isFinite(v) && v >= 0 && v <= 100) return v;
    } catch (e) {}
    return 100;
  }
  function write(v) {
    v = Math.max(0, Math.min(100, Math.round(+v || 0)));
    try { localStorage.setItem(KEY, String(v)); } catch (e) {}
    try { document.dispatchEvent(new CustomEvent('hsn-tts-volume', { detail: v })); } catch (e) {}
    return v;
  }
  function factor() { return read() / 100; }

  try {
    var Native = window.SpeechSynthesisUtterance;
    if (Native && !Native.__hsnWrapped) {
      var Wrapped = function (text) {
        var u = new Native(text);
        try {
          var applied = false;

          u.volume = factor();
          Object.defineProperty(u, 'volume', {
            configurable: true,
            get: function () { return this.__v == null ? factor() : this.__v; },
            set: function (val) {
              var n = +val;
              if (!isFinite(n)) return;

              this.__v = (n <= SILENT_MAX) ? n : factor() * Math.max(0, Math.min(1, n));
              applied = true;
            }
          });
          u.volume = 1;
        } catch (e) {}
        return u;
      };
      Wrapped.prototype = Native.prototype;
      Wrapped.__hsnWrapped = true;
      window.SpeechSynthesisUtterance = Wrapped;
    }
  } catch (e) {}

  try {
    var NativeAudio = window.Audio;
    if (NativeAudio && !NativeAudio.__hsnWrapped) {
      var WrappedAudio = function (src) {
        var a = src === undefined ? new NativeAudio() : new NativeAudio(src);

        try {
          var want = 1;
          Object.defineProperty(a, 'volume', {
            configurable: true,
            get: function () { return want * factor(); },
            set: function (v) {
              v = +v; if (!isFinite(v)) v = 1;
              want = Math.max(0, Math.min(1, v));
              try {
                var d = Object.getOwnPropertyDescriptor(NativeAudio.prototype, 'volume');
                if (d && d.set) d.set.call(a, want * factor());
              } catch (e) {}
            }
          });
          a.volume = 1;
        } catch (e) { try { a.volume = factor(); } catch (e2) {} }
        return a;
      };
      WrappedAudio.prototype = NativeAudio.prototype;
      WrappedAudio.__hsnWrapped = true;
      window.Audio = WrappedAudio;
    }
  } catch (e) {}

  try {
    document.addEventListener('hsn-tts-volume', function () {
      var f = factor();
      try {
        var list = document.querySelectorAll('audio');
        for (var i = 0; i < list.length; i++) {
          try { list[i].volume = f; } catch (e) {}
        }
      } catch (e) {}
    });
  } catch (e) {}

  function preview(word) {
    try {
      if (!window.speechSynthesis) return false;
      speechSynthesis.cancel();
      var u = new window.SpeechSynthesisUtterance(word || 'hello');
      u.lang = 'en-US';
      speechSynthesis.speak(u);
      return true;
    } catch (e) { return false; }
  }

  window.HansenTTSVolume = {
    get: read, set: write, factor: factor, preview: preview, KEY: KEY
  };
})();
