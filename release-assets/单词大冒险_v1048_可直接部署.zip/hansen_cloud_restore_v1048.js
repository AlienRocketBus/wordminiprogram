
(function () {
  'use strict';
  if (window.HansenCloudRestore) return;

  var ASKED_KEY = 'hansen_restore_asked_v1048';

  function signedIn() {
    try {
      var A = window.HansenAuth;
      return !!(A && typeof A.isSignedIn === 'function' && A.isSignedIn());
    } catch (e) { return false; }
  }
  function CS() { return window.HansenCloudSave; }

  function localProgress() {
    var islands = 0, learned = 0, xp = 0;
    try {
      xp = +localStorage.getItem('hansen_wallet_charxp') || 0;
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('wordIsland') === 0) {
          var o = JSON.parse(localStorage.getItem(k) || 'null');
          if (o && o.learned && o.learned.length) { islands++; learned += o.learned.length; }
        }
      }
    } catch (e) {}
    return { islands: islands, learned: learned, xp: xp };
  }

  function localLastUp() {
    try {
      var st = JSON.parse(localStorage.getItem('hansen_cloud_state_v965') || '{}');
      return +st.lastUpAt || 0;
    } catch (e) { return 0; }
  }

  function alreadyAsked(stamp) {
    try { return localStorage.getItem(ASKED_KEY) === String(stamp); } catch (e) { return false; }
  }
  function markAsked(stamp) {
    try { localStorage.setItem(ASKED_KEY, String(stamp)); } catch (e) {}
  }

  function now(opts) {
    opts = opts || {};
    var cs = CS();
    if (!cs || typeof cs.restoreWithKey !== 'function')
      return Promise.resolve({ ok: false, reason: 'cloudsave-unavailable' });
    if (!signedIn())
      return Promise.resolve({ ok: false, reason: 'not-signed-in' });
    return cs.restoreWithKey(cs.ensureKey()).then(function (r) {
      if (r && r.ok) {
        if (opts.silent !== true) {
          try { alert('已从云端找回你的进度，页面即将重新载入。'); } catch (e) {}
        }

        setTimeout(function () { try { location.reload(); } catch (e) {} }, 600);
        return { ok: true };
      }
      return { ok: false, reason: (r && r.reason) || 'restore-failed' };
    }).catch(function (e) {
      return { ok: false, reason: String((e && e.message) || e).slice(0, 160) };
    });
  }

  function check() {
    if (!signedIn()) return Promise.resolve({ skip: 'not-signed-in' });
    var cs = CS();
    if (!cs || typeof cs.accountCloudInfo !== 'function')
      return Promise.resolve({ skip: 'unavailable' });
    return cs.accountCloudInfo().then(function (info) {
      if (!info || info.exists !== true) return { skip: 'no-cloud-save' };
      var lp = localProgress();
      var cloudAt = +info.updatedAt || 0;
      var localAt = localLastUp();
      var localEmpty = (lp.learned === 0 && lp.xp === 0);
      var cloudNewer = cloudAt > 0 && cloudAt > localAt + 60000;
      if (!localEmpty && !cloudNewer) return { skip: 'local-is-current' };
      if (alreadyAsked(cloudAt)) return { skip: 'already-asked' };
      markAsked(cloudAt);
      var when = cloudAt ? new Date(cloudAt).toLocaleString() : '时间未知';
      var msg = localEmpty
        ? ('☁️ 这个账号在云端有一份存档（保存于 ' + when + '）。\n\n'
           + '本机目前没有进度。要现在恢复吗？')
        : ('☁️ 云端有一份更新的存档（保存于 ' + when + '）。\n\n'
           + '本机当前：' + lp.islands + ' 个岛 · 已学 ' + lp.learned + ' 词\n\n'
           + '恢复会用云端进度替换本机当前进度，确定吗？');
      var yes = false;
      try { yes = confirm(msg); } catch (e) {}
      if (!yes) return { skip: 'user-declined' };
      return now({ silent: true }).then(function (r) {
        if (!r.ok) { try { alert('恢复没成功：' + (r.reason || '未知原因')); } catch (e) {} }
        return r;
      });
    }).catch(function (e) { return { skip: 'error', reason: String((e && e.message) || e).slice(0, 120) }; });
  }

  function boot() {
    var run = function () { check(); };
    if (typeof window.requestIdleCallback === 'function') requestIdleCallback(run, { timeout: 6000 });
    else setTimeout(run, 3500);

    try { document.addEventListener('hsn-auth-changed', function () { setTimeout(run, 1200); }); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  window.HansenCloudRestore = { check: check, now: now, _localProgress: localProgress };
})();
