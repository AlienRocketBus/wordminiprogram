#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =============================================================================
#  hansen_evolve.py — 单词大冒险 · 贾维斯(JARVIS)自主进化引擎 (Autonomous Evolution Engine) v12.1
#  「启动贾维斯」= python3 jarvis.py (会调用本引擎做全面巡检)
#  v12.1 新增(说明书同步自动化·v526): self_check 检测到《自主进化引擎·完整说明书.md》附录嵌入源码与本体失同步且 --apply-safe 时, 自动修复(_manual_doc_sync: 先备份→自适应fence重写→逐字复验→失败回滚)——根除 v12.0 当日"改引擎只同步README漏了说明书"的结构不对称; 同版 build.py --label 真正接入部署 zip 名(旧版硬编码陈年标签且 label 解析了从未使用)。
#  v12.0 新增(与README彻底融为一体·贾维斯进化): ①四方一致性审计 kb_guard_sync_audit(知识库↔守卫↔代码🔴标记↔README/VERSION 全联动核对) ②退役FX守卫过时检测 retired_fx_guard_audit(v511教训自动化: 老FX退役时其历史守卫必须改写为死代码守卫, 否则拦截) ③工具备份同步 tool_backup_sync_check(README《🧰核心开发工具源码备份》与七工具本体逐字比对·--apply-safe 自动同步修复)。
#  v11.0 新增(发布运营闭环): 自动保留(未上线快照只留最近 KEEP_SNAPSHOTS 个, 多余自动删; 已上线版与发布说明永久保留) ·
#        --mark-deployed 标记某版"已上线"(永久钉住 + 发布说明标 🚀) · --rollback-prep 一键准备回滚到上一上线版(复制包+清单) ·
#        发布说明新增"相比上次上线版的变更"(= 用户上次更新以来变了什么)。仍只快照/准备, 不自动部署(守安全宪章)。
#  v10.0 新增(版本化发布 + 可随时下载): --release 打一个可直接静态部署的版本化小程序包(index.html 在根,
#        排除 .py/.md/.txt 及引擎产物)存入 releases/, 并维护 releases/单词大冒险_最新可部署包.zip 始终指向最新;
#        自动维护 releases/发布说明.md —— 每个版本记录: 版本号/时间/健康分/相比上次发布改了哪些文件/本轮自动修复/
#        当前已知问题/部署铁律。--apply-safe 真正应用修复后也会自动出一个版本。只快照不改游戏(守安全宪章)。
#  v9.0 新增(抓更多真实坑): 跨岛内联函数 MD5 漂移检测 —— 18 个普通岛逐个抽取同名内联函数体做 MD5,
#        若"多数岛一致、少数岛却不同"即疑似"改了某岛忘同步其余岛", WARN 列出偏离岛(守宪章, 不自动改游戏)。
#        共享 hansen_*.js 单文件无此风险; 此检查专盯各岛各拷一份的内联函数(markAnswer/boss 等最易漏改)。
#  v8.0 新增(更聪明·会自我纠正): 引擎自完整性守卫(每轮自检核对自身源码备份 README/说明书 与本体是否逐字一致,
#        自动化"改引擎必同步"铁律, 改了忘同步会被自己抓住) · 缓存戳漂移接入安全自愈(--apply-safe 下自动跑
#        build.py 重统一 + 验证 + 失败回滚) · 报告输出"下一步进化建议"(引擎自我指方向, 仍只建议不自动改游戏)。
#  v7.0 新增(更智能更扎实): 缓存戳一致性闸(主 ?v= 全岛统一 + 对齐 VERSION, 防混版/旧缓存) ·
#        悬空脚本引用检测(<script src> 指向的文件必须真实存在) · 充值/内疚型黑暗文案扫描(面向未成年) ·
#        '我的学习'成长面板纳入路线图自检。新发现自动进 健康分/维度/排序/知识库/报告 全链路。
# =============================================================================
#  目标: 一个"不用人盯着"的 AI 守护者 —— 自己理解小程序的目的(读 hansen_mission.md),
#        自己跨多维度挖问题(崩溃/bug/经济失衡/黑暗模式/不一致), 自己学习成长(知识库每轮
#        累积、修过的问题固化成永久回归守卫), 自己写报告, 并把小程序持续推向"找不到缺点"。
#  已完整集成"启动监察官"(hansen_inspector.py): 每轮自动跑监察官静态层(A+B+KB);
#        --deep 跑监察官全部 4 层(含真机浏览器)+ 健康检查。跑本引擎 = 也跑了监察官。
#
#  ⚠️ 安全宪章(写死, 绝不违背 —— 见 hansen_mission.md 第五节):
#    · 绝不无人监管地改游戏逻辑。自动修复只限"安全/可逆/改后能立即自动验证"一类。
#    · 任何自动改动先备份到 .evolution_backups/, 改后立即重跑 check_resources 验证, 不过就回滚。
#    · 其余一切(动游戏逻辑/经济/UI 的)只生成"提案", 交人一键采纳 —— 保护游戏不被 AI 弄坏。
#
#  用法:
#    python3 hansen_evolve.py                 # 跑一轮(安全: 只发现+提案, 不自动改)
#    python3 hansen_evolve.py --watch 30      # 无人值守: 每 30 分钟自动跑一轮(挂 cron/服务器/云函数)
#    python3 hansen_evolve.py --probe         # 额外: 真机崩溃压力测试(Playwright 狂点/竞态/越级)
#    python3 hansen_evolve.py --deep          # 额外: 监察官全部4层(含真机浏览器) + 健康检查全量(慢)
#    python3 hansen_evolve.py --ai            # 额外: 开 Claude 深度推理层(需 ANTHROPIC_API_KEY)
#    python3 hansen_evolve.py --apply-safe    # 允许自动应用"安全可逆"类修复(默认关; 仍先备份+验证)
#    python3 hansen_evolve.py --release        # 立即打一个可直接静态部署的版本化包到 releases/ + 更新 发布说明.md
#    python3 hansen_evolve.py --mark-deployed  # 把"最近一次发布"标记为已上线(永久保留, 不被自动清理)
#    python3 hansen_evolve.py --rollback-prep  # 准备回滚到上一个已上线版本(复制成 回滚到上一稳定版.zip + 打印回滚清单)
#  可组合, 例: python3 hansen_evolve.py --probe --ai --apply-safe
#  退出码: 发现任何 ERROR 或 WARN -> 1；跳过/崩溃的断言按 ERROR 处理。
# =============================================================================
import os, sys, re, json, glob, time, shutil, subprocess, datetime, urllib.request, urllib.parse

ARGS        = sys.argv[1:]
PROBE       = "--probe" in ARGS
DEEP        = "--deep" in ARGS
USE_AI      = "--ai" in ARGS
APPLY_SAFE  = "--apply-safe" in ARGS
RELEASE     = "--release" in ARGS  # v942: 仅用于给出迁移错误；旧打包器已封死
MARK_DEPLOYED = "--mark-deployed" in ARGS
ROLLBACK_PREP = "--rollback-prep" in ARGS
CONTENT     = "--content" in ARGS
def _argval(flag, default=None):
    if flag in ARGS:
        i = ARGS.index(flag)
        if i+1 < len(ARGS): return ARGS[i+1]
    return default
WATCH = _argval("--watch")   # 分钟数(字符串) or None

ROOT       = os.path.dirname(os.path.abspath(__file__))
KB_PATH    = os.path.join(ROOT, "hansen_evolve_kb.json")
MISSION    = os.path.join(ROOT, "hansen_mission.md")
REPORT_DIR = os.path.join(ROOT, "evolution_reports")
BACKUP_DIR = os.path.join(ROOT, ".evolution_backups")
BACKLOG    = os.path.join(ROOT, "hansen_evolve_backlog.json")
KEEP_SNAPSHOTS = 8   # releases/ 里最多保留几个"未上线"的快照包; 已上线(--mark-deployed)的永久钉住不计入, 多余的旧快照自动删

# 六个使命维度(对应 hansen_mission.md 的价值优先级); 每条发现归到其一, 便于细分打分看出弱在哪
DIMENSIONS = ["崩溃韧性", "健康无黑暗", "视觉音质", "经济平衡", "跨岛一致", "学习价值"]
CAT2DIM = {
    "静态质检": "崩溃韧性", "工具": "崩溃韧性", "崩溃韧性": "崩溃韧性", "崩溃压测": "崩溃韧性",
    "监察官": "崩溃韧性", "健康检查": "崩溃韧性", "改进·卫生": "崩溃韧性", "改进·性能": "崩溃韧性",
    "健康/无黑暗模式": "健康无黑暗",
    "视觉音质": "视觉音质", "改进·音质": "视觉音质",
    "经济平衡": "经济平衡", "跨岛一致": "跨岛一致",
    "知识库一致": "崩溃韧性", "退役守卫": "崩溃韧性", "备份同步": "崩溃韧性",
    "数据完整": "学习价值", "学习价值": "学习价值", "改进·学习": "学习价值", "AI推理": "学习价值", "内容体检": "学习价值", "AI内容": "学习价值",
}
def _dim_of(cat): return CAT2DIM.get(cat, "崩溃韧性")

ERROR, WARN, INFO = "ERROR", "WARN", "INFO"
RANK = {ERROR: 0, WARN: 1, INFO: 2}

def read(p):
    try: return open(p, encoding="utf-8").read()
    except Exception: return ""
def now_ts(): return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
def islands(): return sorted(glob.glob(os.path.join(ROOT, "island_*.html")))
def jsfiles(): return sorted(glob.glob(os.path.join(ROOT, "hansen_*.js")))

# ---- 本轮发现收集 ----
class Run:
    def __init__(self): self.findings = []
    def add(self, sev, cat, cid, msg, where="", fix=""):
        self.findings.append({"sev": sev, "cat": cat, "id": cid, "msg": msg, "where": where, "fix": fix})
    def by(self, sev): return [f for f in self.findings if f["sev"] == sev]
    def fingerprints(self): return {f["cat"] + "|" + f["id"] for f in self.findings}

# =============================================================================
#  1) 读使命(让引擎理解小程序的目的与价值)
# =============================================================================
def load_mission():
    t = read(MISSION)
    if not t:
        print("  ⚠️ 缺 hansen_mission.md —— 引擎将用最小默认价值观运行(建议补回使命宪法)")
        return {"ok": False, "text": ""}
    # 抽取价值关键词(给 AI 层与黑暗模式扫描参考)
    return {"ok": True, "text": t}

# =============================================================================
#  2) 自主发现项目结构(随项目成长自适应, 不写死)
# =============================================================================
def discover():
    isl = islands()
    season = any(p.endswith("island_season.html") for p in isl)
    shared = [os.path.basename(p) for p in jsfiles()]
    # 从动物岛(基准岛)抽游戏模式 + 货币线索
    base = read(os.path.join(ROOT, "island_animal.html"))
    modes = sorted(set(re.findall(r"data-mode=['\"]([a-zA-Z_]+)['\"]", base)) |
                   set(re.findall(r"mode\s*===?\s*['\"]([a-zA-Z_]+)['\"]", base)))
    currencies = []
    if any("HansenCoins" in read(p) for p in jsfiles()): currencies.append("金币(软,全局钱包)")
    if any("HansenGems" in read(p) for p in jsfiles()):  currencies.append("钻石(硬,成就给)")
    themes_coin = len(re.findall(r"THEME_PRICE", read(os.path.join(ROOT, "hansen_theme_lock.js"))))
    dia = read(os.path.join(ROOT, "hansen_diamond_shop.js"))
    themes_dia = len(re.findall(r"type:'theme'", dia))
    d = {"islands": len(isl), "season": season, "shared_modules": len(shared),
         "shared_list": shared, "modes": modes, "currencies": currencies,
         "diamond_themes": themes_dia}
    print("  🔎 自主发现: %d 岛(赛季岛:%s) · 共享系统 %d 个 · 游戏模式 %d 种 · 货币 %s · 钻石主题 %d 个"
          % (d["islands"], "有" if season else "无", d["shared_modules"], len(modes),
             "/".join(currencies) or "?", themes_dia))
    return d

# =============================================================================
#  3) 静态主关: 调用 check_resources.py(出厂质检 10+ 项)
# =============================================================================
def run_check_resources(run):
    p = os.path.join(ROOT, "check_resources.py")
    if not os.path.exists(p):
        run.add(ERROR, "工具", "no_check_resources", "缺 check_resources.py；静态断言未执行")
        return
    try:
        r = subprocess.run([sys.executable, p], cwd=ROOT, capture_output=True, text=True, timeout=120)
        out = (r.stdout or "") + (r.stderr or "")
        if r.returncode == 0:
            print("  ✅ check_resources: 全部通过")
        else:
            print("  ❌ check_resources: 发现问题")
            for line in out.splitlines():
                s = line.strip()
                if s.startswith("- ") or s.startswith("   - "):
                    run.add(ERROR, "静态质检", "check_resources", s.lstrip("- ").strip())
            if not run.by(ERROR):
                run.add(ERROR, "静态质检", "check_resources", "check_resources 未通过(详见报告)")
    except Exception as e:
        run.add(ERROR, "工具", "check_resources_run", "check_resources 运行异常；断言未执行: %s" % str(e)[:80])

# =============================================================================
#  4) 引擎自有 · 对齐使命的深查(与 check_resources 互补)
# =============================================================================
def has(fname, *needles):
    t = read(os.path.join(ROOT, fname))
    return bool(t) and all(n in t for n in needles)

def mission_checks(run, disc):
    isl = islands()
    n = len(isl)

    # --- 价值#2 健康/无黑暗模式: 已知 near-miss 假动画文案必须不存在 + 扫压迫/罪恶感文案 ---
    near_miss = sum(read(p).count("还差0分") + read(p).count("还差 0 分") for p in isl)
    if near_miss:
        run.add(ERROR, "健康/无黑暗模式", "near_miss_text", "出现 near-miss 误导文案'还差0分'(%d 处) —— 欺骗性,违背健康原则" % near_miss,
                fix="改为不暗示'就差一点'的中性结算文案")
    else:
        run.add(INFO, "健康/无黑暗模式", "near_miss_text", "无 near-miss 误导文案 ✅")
    pressure_pat = re.compile(r"(再不[来玩签]|否则.*清空|马上就要失去|错过就没|连续.*中断.*清零|快没时间了)")
    hits = []
    for p in isl + jsfiles():
        for i, ln in enumerate(read(p).splitlines(), 1):
            if pressure_pat.search(ln): hits.append("%s:%d" % (os.path.basename(p), i))
    if hits:
        run.add(WARN, "健康/无黑暗模式", "pressure_language",
                "疑似制造焦虑/罪恶感的压迫文案(%d 处, 需人工确认是否违背健康原则)" % len(hits),
                where=", ".join(hits[:6]))

    # --- 价值#2 健康: 充值压迫 / 内疚挽留 文案(面向未成年人, 高危黑暗模式) ---
    mon_pat = re.compile(r"(不充值|花钱才能|付费才能|充值才能|充值解锁|你确定要放弃|确定要抛弃|忍心放弃|再不充)")
    mon_hits = []
    for p in isl + jsfiles():
        for i, ln in enumerate(read(p).splitlines(), 1):
            if mon_pat.search(ln): mon_hits.append("%s:%d" % (os.path.basename(p), i))
    if mon_hits:
        run.add(WARN, "健康/无黑暗模式", "monetization_guilt",
                "疑似充值压迫/内疚挽留文案(%d 处, 面向初中生属高危黑暗模式, 请人工确认)" % len(mon_hits),
                where=", ".join(mon_hits[:6]), fix="移除充值胁迫与'放弃就内疚'式文案")
    else:
        run.add(INFO, "健康/无黑暗模式", "monetization_guilt", "无充值压迫/内疚挽留文案 ✅")

    # --- 价值#1 崩溃韧性(低误报启发式) ---
    for p in jsfiles() + isl:
        t = read(p); si = t.count("setInterval("); ci = t.count("clearInterval(")
        if si >= 2 and ci == 0:
            run.add(INFO, "崩溃韧性", "timer_leak_%s" % os.path.basename(p),
                    "%s 有 %d 处 setInterval 但 0 处 clearInterval(长玩可能定时器堆积, 建议确认)" % (os.path.basename(p), si))

    # --- 价值#4 经济不变量(冗余守护, 与监察官互为双保险) ---
    diamond_shop = read(os.path.join(ROOT, "hansen_diamond_shop.js"))
    equip_start = diamond_shop.find("function equip(id)")
    equip_end = diamond_shop.find("function ", equip_start + len("function equip(id)")) if equip_start >= 0 else -1
    equip_body = diamond_shop[equip_start:equip_end if equip_end >= 0 else len(diamond_shop)] if equip_start >= 0 else ""
    equip_owned_guard = all(token in equip_body for token in (
        "!_diamondMeta(id)",
        "!Object.prototype.hasOwnProperty.call(o.owned,id)",
        "o.owned[id]!==true",
        "return false",
    ))
    economy = [
        ("钱包余额守卫(金币+钻石)", has("hansen_coin_wallet.js", "spend:", "return false") and has("hansen_gem_system.js", "spend:", "return false"), "spend 须先查余额不足返回 false"),
        ("钻石主题 equip 校验已购", equip_owned_guard, "equip 须同时验证目录、own key 与严格布尔 true(防原型键/后台白嫖)"),
        ("抽卡价 GACHA_COST 存在", has("hansen_gacha.js", "GACHA_COST"), "抽卡价变量须存在"),
    ]
    for name, ok, why in economy:
        if ok: run.add(INFO, "经济平衡", "eco_" + name, "%s ✅" % name)
        else:  run.add(ERROR, "经济平衡", "eco_" + name, "经济不变量缺失: %s —— %s" % (name, why), fix=why)

    # --- 价值#5 跨岛一致: 关键共享系统须全岛(含赛季)加载 ---
    critical = ["hansen_theme_lock.js", "hansen_diamond_shop.js", "hansen_checkin_global.js",
                "hansen_coin_wallet.js", "hansen_gem_system.js", "hansen_season.js"]
    for mod in critical:
        if not os.path.exists(os.path.join(ROOT, mod)): continue
        loaded = sum(1 for p in isl if mod in read(p))
        if loaded == n:
            run.add(INFO, "跨岛一致", "load_" + mod, "%s 全 %d 岛加载 ✅" % (mod, n))
        else:
            miss = [os.path.basename(p) for p in isl if mod not in read(p)]
            run.add(ERROR, "跨岛一致", "load_" + mod, "%s 只在 %d/%d 岛加载, 漏: %s" % (mod, loaded, n, ", ".join(miss[:6])),
                    fix="在缺失岛 <head> 加载 %s" % mod)

    # --- 价值#3 资产完整(主戳已交 check_resources, 这里查 boss 图/词表存在性兜底) ---
    if not has("word_map.js", "WORD_MAP") and not glob.glob(os.path.join(ROOT, "word_map.js")):
        run.add(WARN, "数据完整", "word_map", "未找到 word_map.js(数据底座)")

# =============================================================================
#  5) 自我学习 · 成长知识库(每轮累积; 修过的固化为永久回归守卫; 记健康分趋势)
# =============================================================================
def improvement_scan(run, disc):
    """挖还能更好的改进机会(不是 bug; 记为 INFO 改进, 不扣健康分, 进入持久化待办清单)。
       新增维度: 真人发音覆盖 / 错词复习机制 / 文件体积 / 代码卫生 —— 让引擎更全面。"""
    isl = islands(); allf = isl + jsfiles()
    review_kw = ("复习", "间隔重复", "复习易错", "复习错词")
    if not any(any(k in read(p) for k in review_kw) for p in allf):
        run.add(INFO, "改进·学习", "spaced_repetition",
                "未检测到错词复习/间隔重复机制 —— 学习价值最高的改进方向",
                fix="基于已记录的错词加复习易错词模式, 按隔天/3天/7天重现直至记牢")
    if not any("hansen_mylearning" in read(p) for p in allf):
        run.add(INFO, "改进·学习", "my_learning_panel",
                "未检测到'我的学习'跨岛成长面板 —— 让孩子看见自己变强(已掌握/正确率/探索度), 正向动机最强",
                fix="加跨岛聚合成长面板, 把各岛 S.learned/正确率/连签汇总展示")
    sizes = sorted(os.path.getsize(p) / 1024.0 for p in isl) if isl else []
    med = sizes[len(sizes)//2] if sizes else 0
    big = ["%s(%.0fKB)" % (os.path.basename(p), os.path.getsize(p)/1024.0)
           for p in isl if med and os.path.getsize(p)/1024.0 > 1.8*med and os.path.getsize(p)/1024.0 > 500]
    if big:
        run.add(INFO, "改进·性能", "island_size",
                "%d 个岛 HTML 明显偏大(>1.8x中位且>500KB): %s" % (len(big), ", ".join(big[:6])),
                fix="把重复的内联 JS/CSS 抽成共享文件以减小单岛体积")
    marks = 0; where = []
    for p in allf:
        for i, ln in enumerate(read(p).splitlines(), 1):
            if "debugger" in ln or "TODO" in ln or "FIXME" in ln:
                marks += 1
                if len(where) < 6: where.append("%s:%d" % (os.path.basename(p), i))
    if marks:
        run.add(INFO, "改进·卫生", "code_markers",
                "代码里有 %d 处 debugger/TODO/FIXME 残留" % marks, where=", ".join(where), fix="清理未完成标记")

def perf_sentinel(run):
    """🔴v858/v944 性能超级哨兵。
       保留图片压缩、backdrop-filter 清理和图片卫生；v944 永久禁止会让主题
       图标在真实触摸/惯性滚动中停止的根级动画暂停闸门。"""
    import glob as _g, re as _re
    # v859语料修正: 全量html(剔evolution_dashboard=报告回声会把死名单假活化)+全量js(此前只收hansen_*漏了perf_boost/click_sound等8个+boss_hall等卫星页→27项死名单几乎全是假阳性)
    _all_html = [p for p in sorted(_g.glob(os.path.join(ROOT, '*.html'))) if not p.endswith('evolution_dashboard.html')]
    _all_js = sorted(_g.glob(os.path.join(ROOT, '*.js')))
    # ① backdrop-filter 零容忍(滚动卡顿第一杀手·五类禁令第5类·v858全清·任何回归=ERROR)
    offenders = []
    scan = _all_html + _all_js + [os.path.join(ROOT,'island_data.json')]
    for p in scan:
        for i, ln in enumerate(read(p).splitlines(), 1):
            if 'backdrop-filter' not in ln: continue
            if 'v719薄纱豁免' in ln: continue  # 唯一合法backdrop: 首页14px沉浸欣赏薄纱点(Hansen v719-722钦定磨砂质感·面积极小合成成本≈0)
            if _re.search(r'backdrop-filter\s*:\s*(?!none)[a-z(]', ln):
                offenders.append('%s:%d' % (os.path.basename(p), i))
    if offenders:
        run.add(ERROR, '性能', 'backdrop_filter_regress',
                '出现 %d 处 backdrop-filter(滚动卡顿第一杀手·v858已全清·禁止回归)' % len(offenders),
                where=', '.join(offenders[:8]),
                fix='去掉blur、背景rgba透明度提到.8+做补偿(v858手术配方见知识库)')
    # ② 图片体积预算(单张>800KB=WARN·总量趋势=INFO)
    big = []; total = 0
    for d in ('bosses','pets','icons','avatars','themes','bosses_bg','weapons','speed','robots'):
        for f in _g.glob(os.path.join(ROOT, d, '*')):
            sz = os.path.getsize(f); total += sz
            if os.path.basename(f).startswith('saelya'): continue  # 星空女皇画质法令: 银河/星空唯一合法持有者·三形态立绘不设预算(密集星云量化必糊)
            if sz > 800*1024: big.append('%s(%.0fKB)' % (os.path.relpath(f, ROOT), sz/1024))
    if big:
        run.add(WARN, '性能', 'img_budget', '%d 张图超800KB预算: %s' % (len(big), ', '.join(big[:5])),
                fix='pngquant --quality=78-95 + 类目上限(普通boss768·赛季boss1100=v809高清法令·icons640·avatars不缩纯量化=v773的720法令·配方见知识库v858)')
    run.add(INFO, '性能', 'img_total', '图片资产总量 %.1fMB(v858守法基线41.9MB·超50MB就该再做一轮压缩)' % (total/1048576))
    # ③ perf引擎在位(页面接线 + 图片卫生齐全 + 滚动不暂停主题)
    _wire = [os.path.join(ROOT, x) for x in ('template.html','index.html','boss_hall.html','season_showcase.html','spelling_bee.html')] + islands()
    miss = [os.path.basename(p) for p in _wire if 'hansen_perf_v944.js?v=' not in read(p)]
    if miss:
        run.add(ERROR, '性能', 'perf_engine_missing', '%d 个页面没接 hansen_perf_v944.js(图片卫生+滚动连续性)' % len(miss),
                where=', '.join(miss[:6]), fix='template/index 加 <script hansen_perf_v944.js> 后重跑 generate')
    pj = read(os.path.join(ROOT, 'hansen_perf_v944.js'))
    for key, label in (("setAttribute('decoding','async')",'解码async'), ("setAttribute('loading','lazy')",'图片墙lazy'), ('MutationObserver','动态图片卫生')):
        if key not in pj:
            run.add(ERROR, '性能', 'perf_engine_gutted', 'hansen_perf_v944.js 缺【%s】核心逻辑' % label, fix='对照知识库 v858 恢复')
    if 'hsn-scrolling' in pj or _re.search(r'animation-play-state\s*:\s*paused', pj):
        run.add(ERROR, '性能', 'scroll_animation_pause_regress',
                'hansen_perf_v944.js 恢复了滚动动画暂停，主题图标会在手指/惯性滚动中停止',
                fix='删除滚动暂停样式与 scroll/touchmove 闸门；保留图片卫生和独立后台/离屏暂停')
    # v944 首载必须先跨越 v943 ignoreSearch Worker，再执行任何业务脚本。
    # The regex below deliberately returns only the opening tag.  Compare like
    # with like; including </script> here makes every healthy entry look broken.
    cache_version = read(os.path.join(ROOT, 'VERSION')).strip()
    gate_open = '<script src="hansen_sw_upgrade_gate_v944.js?v=%s">' % cache_version
    upgrade_entries = [os.path.join(ROOT, name) for name in (
        'index.html', '_frame.html', 'boss_hall.html', 'season_showcase.html',
        'spelling_bee.html', 'land_map.html',
    )] + islands()
    bad_gate = []
    for entry in upgrade_entries:
        source = read(entry)
        first = _re.search(r'<script\b[^>]*>', source, _re.I)
        if not first or first.group(0) != gate_open:
            bad_gate.append(os.path.basename(entry))
    worker = read(os.path.join(ROOT, 'sw_v944.js'))
    gate_source = read(os.path.join(ROOT, 'hansen_sw_upgrade_gate_v944.js'))
    upgrade_source = read(os.path.join(ROOT, '_sw_upgrade_v944.html'))
    if (bad_gate or not all((worker, gate_source, upgrade_source))
            or "'./hansen_sw_upgrade_gate_v944.js'" not in worker
            or "'./_sw_upgrade_v944.html'" not in worker
            or 'serviceWorker.register(\'./sw_v944.js\'' not in read(os.path.join(ROOT, 'index.html'))
            or os.path.exists(os.path.join(ROOT, 'sw.js'))):
        run.add(ERROR, '性能', 'sw_atomic_upgrade_regress',
                'v943→v944 首载原子升级门缺失或顺序回退，可能执行新HTML+旧同名脚本的混版',
                where=', '.join(bad_gate[:8]),
                fix='33入口首脚本固定hansen_sw_upgrade_gate_v944.js；仅注册sw_v944.js；保留隔离升级页和新备份pathname')
    # ④ 动画预算(infinite 数量超支预警)
    for fn, cap in (('index.html', 65), ('template.html', 32)):
        n = len(_re.findall(r'animation:[^;"}]*infinite', read(os.path.join(ROOT, fn))))
        if n > cap:
            run.add(WARN, '性能', 'anim_budget', '%s infinite 动画 %d 个 > 预算 %d(滚动合成负载·卡顿源)' % (fn, n, cap),
                    fix='新增常驻动画前先问值不值·或并入既有关键帧·滚动闸门只是兜底不是纵容')
    # ⑤ 巨图尺寸哨兵(非背景类 >1400px = 手机纯浪费解码)
    over = []
    try:
        from PIL import Image as _Im
        for d in ('bosses','pets','icons','avatars','weapons'):
            for f in _g.glob(os.path.join(ROOT, d, '*.png')):
                try:
                    with _Im.open(f) as im:
                        if max(im.size) > 1400: over.append('%s(%dx%d)' % (os.path.relpath(f, ROOT), im.size[0], im.size[1]))
                except Exception: pass
    except Exception: pass
    if over:
        run.add(WARN, '性能', 'img_dim', '%d 张非背景图超1400px: %s' % (len(over), ', '.join(over[:4])),
                fix='按类目上限缩(普通boss768·赛季boss1100=v809法令·icons640·pets512·avatars绝不缩=v773法令)+pngquant')
    # ⑥ 死资产扫描(不被任何页面/JS/数据引用 = 白占CDN与部署包)
    refs = ' '.join(read(p) for p in _all_html + _all_js + [os.path.join(ROOT,'island_data.json')])
    dead = []; deadsz = 0
    _stem = _re.compile(r'\d+\.[a-z]+$')
    for d in ('bosses','pets','icons','avatars','themes','bosses_bg','weapons','speed','robots'):
        for f in _g.glob(os.path.join(ROOT, d, '*')):
            bn = os.path.basename(f)
            if bn in refs: continue
            # v859动态家族规则: levelN.webp 这类"前缀+数字"是运行时拼的('bosses_bg/level'+lv)——basename永远不在语料。
            # 去尾数字取词干, dir/词干 出现在语料 = 整族存活(实锤: boss_hall.html bgPath)。
            fam = d + '/' + _stem.sub('', bn)
            if len(fam) > len(d) + 3 and fam in refs: continue
            dead.append(os.path.relpath(f, ROOT)); deadsz += os.path.getsize(f)
    if dead:
        run.add(INFO, '改进·性能', 'dead_assets',
                '%d 个资产文件无任何引用·白占 %.1fMB: %s%s' % (len(dead), deadsz/1048576, ', '.join(dead[:6]), '…' if len(dead) > 6 else ''),
                fix='确认后删掉(部署包直接瘦身); 若是给未来功能预留的, 在知识库登记免得反复报')

def cache_stamp_checks(run):
    """缓存戳一致性: 主 ?v=NNN 必须全岛统一(否则部署后用户拿到混版/旧缓存, 必然诡异 bug), 且应与 VERSION 对齐。
       这是'三套缓存戳系统'最易翻车处 —— build.py 漏跑 / 手改某岛 / 部分打包都会被这里抓住。"""
    isl = islands()
    if not isl: return
    from collections import Counter
    per = {}; allstamps = set()
    for p in isl:
        st = set(re.findall(r'\?v=(\d+)', read(p)))
        per[os.path.basename(p)] = st; allstamps |= st
    if len(allstamps) > 1:
        c = Counter()
        for st in per.values():
            for v in st: c[v] += 1
        detail = ", ".join("v=%s(%d岛)" % (v, c[v]) for v in sorted(c, key=lambda x: -c[x]))
        run.add(ERROR, "跨岛一致", "cache_stamp_drift",
                "主缓存戳 ?v= 不统一(%s) —— 部署后用户会拿到混版/旧缓存, 必然出诡异 bug" % detail,
                fix="跑 python3 build.py NNN 重新统一全部缓存戳")
    elif allstamps:
        only = next(iter(allstamps)); ver = read(os.path.join(ROOT, "VERSION")).strip()
        if ver and only != ver:
            run.add(WARN, "跨岛一致", "cache_stamp_vs_version",
                    "主缓存戳 ?v=%s 与 VERSION(%s) 不一致 —— 可能漏跑 build.py" % (only, ver),
                    fix="跑 python3 build.py %s 重新打戳" % ver)
        else:
            run.add(INFO, "跨岛一致", "cache_stamp", "主缓存戳全 %d 岛统一为 ?v=%s ✅" % (len(isl), only))

def dangling_ref_checks(run):
    """悬空引用: 每个岛 <script src=本地文件> 引用的文件必须真实存在, 否则该页静默加载失败。
       新增共享 JS 却漏建文件 / 改名后漏改引用, 都会被这里抓住。"""
    isl = islands(); missing = {}
    for p in isl:
        for m in re.finditer(r'<script[^>]+src=["\']([^"\']+)["\']', read(p)):
            src = m.group(1)
            if src.startswith("http") or src.startswith("//"): continue
            f = src.split("?")[0].split("#")[0].lstrip("./")
            if "/" in f or not f: continue
            if not os.path.exists(os.path.join(ROOT, f)):
                missing.setdefault(f, []).append(os.path.basename(p))
    if missing:
        for f, where in missing.items():
            run.add(ERROR, "崩溃韧性", "dangling_" + f,
                    "引用了不存在的脚本 %s(%d 岛)—— 该页会静默加载失败" % (f, len(where)),
                    where=", ".join(where[:6]), fix="补回 %s 文件, 或从这些岛移除该 <script> 引用" % f)
    else:
        run.add(INFO, "崩溃韧性", "dangling_script", "所有 <script> 本地引用均指向真实文件 ✅")

def inline_drift_checks(run):
    """跨岛内联函数漂移(MD5): 共享 hansen_*.js 是单文件无此风险, 但 markAnswer/learnWord/boss 等
       '内联在每个岛各拷一份'的函数最易'改了某岛忘同步其余岛'-> 静默行为漂移。做法: 18 个普通岛
       (排除 island_season.html, 其机制本就不同)逐个抽同名顶层函数体做 MD5; 若某函数在'明显多数岛
       一致、少数岛却不同', 极可能漏改 -> WARN 列出偏离岛, 由人工确认哪个版本为准(不自动改, 守安全宪章)。
       save/load 等各岛皆异(键不同)无明显多数, 自动不报, 避免误报。"""
    import hashlib
    from collections import Counter, defaultdict
    isl = [p for p in islands() if os.path.basename(p) != "island_season.html"]
    if len(isl) < 4:
        return
    def fn_md5s(text):
        out = {}
        for m in re.finditer(r"\bfunction\s+([A-Za-z_$][\w$]*)\s*\(", text):
            name = m.group(1)
            i = text.find("{", m.end() - 1)
            if i < 0: continue
            depth = 0; j = i; L = len(text)
            while j < L:
                c = text[j]
                if c == "{": depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0: break
                j += 1
            if name not in out:  # 只取首个同名定义
                out[name] = hashlib.md5(text[m.start():j + 1].encode("utf-8", "ignore")).hexdigest()
        return out
    per = [(os.path.basename(p).replace("island_", "").replace(".html", ""), fn_md5s(read(p))) for p in isl]
    n = len(per)
    names = set()
    for _, d in per: names.update(d)
    # 第一步: 找"明显多数一致 + 少数偏离"的函数, 记录其偏离岛
    drift = {}  # fn -> sorted(偏离岛)
    for name in sorted(names):
        present = [(nm, d[name]) for nm, d in per if name in d]
        if len(present) < max(4, int(n * 0.6)):  # 必须多数岛都有此函数(=确为共享内联)
            continue
        cnt = Counter(h for _, h in present)
        if len(cnt) == 1:  # 全岛一致 ✅
            continue
        maj_hash, maj = cnt.most_common(1)[0]
        # save/load 等各岛皆异无明显多数, 此条件天然排除, 避免误报
        if maj >= max(4, int(len(present) * 0.7)) and maj < len(present):
            drift[name] = sorted(nm for nm, h in present if h != maj_hash)
    if not drift:
        run.add(INFO, "跨岛一致", "inline_drift", "关键内联函数跨 %d 普通岛 MD5 一致, 无漏改漂移 ✅" % n)
        return
    # 第二步: 按"偏离岛集合"聚合, 再分级(降噪 + 区分'疑似事故' vs '有意变体')
    groups = defaultdict(list)
    for fn, outs in drift.items():
        groups[tuple(outs)].append(fn)
    warns = 0
    for outs, fns in sorted(groups.items(), key=lambda kv: (-len(kv[1]), kv[0])):
        fns = sorted(fns)
        isls = ", ".join(outs[:8]) + (" 等%d岛" % len(outs) if len(outs) > 8 else "")
        fl = ", ".join(fns[:12]) + (" …共%d个" % len(fns) if len(fns) > 12 else "")
        # 分级: 单岛仅在 1~2 个函数偏离 = 最像'漏同步事故' -> WARN; 否则(单岛多函数/多岛成组)= 多半有意 -> INFO
        if len(outs) == 1 and len(fns) <= 2:
            run.add(WARN, "跨岛一致", "inline_drift_" + "_".join(fns),
                    "疑似漏同步: 内联函数 %s() 仅 %s 岛与其余多数岛不同 —— 多半是改了该岛忘同步其余(或反之), 请核对并统一" % (fl, isls),
                    where="偏离岛: " + isls,
                    fix="确认目标版本后对全部普通岛统一 str_replace 该函数, 重跑应转为 ✅")
            warns += 1
        else:
            run.add(INFO, "跨岛一致", "inline_drift_grp_" + "_".join(outs)[:40],
                    "跨岛内联差异(%d 函数, 偏离岛: %s)—— 多半是主力岛/变体玩法岛, 如非有意可忽略; 需一致则同步: %s" % (len(fns), isls, fl))
    run.add(INFO, "跨岛一致", "inline_drift_summary",
            "内联漂移扫描: %d 函数有跨岛差异, 归 %d 组, 其中 %d 组疑似漏同步(WARN)" % (len(drift), len(groups), warns))

# =============================================================================
#  v12.0 ① 四方一致性审计: 知识库 ↔ check_resources 守卫 ↔ 代码🔴标记 ↔ README/VERSION
#  目标: 贾维斯与 README"彻底融为一体"——任何一方记录了的版本/BUG, 其余方必须同步在位。
# =============================================================================
def kb_guard_sync_audit(run):
    try:
        ver = read(os.path.join(ROOT, "VERSION")).strip()
        readme = read(os.path.join(ROOT, "README.md"))
        kb_md  = read(os.path.join(ROOT, "贾维斯_知识库.md"))
        cr     = read(os.path.join(ROOT, "check_resources.py"))
        hba    = read(os.path.join(ROOT, "hansen_boss_attack.js"))
        # 1) VERSION ↔ README 当前版本行
        m = re.search(r"当前版本:\s*v(\d+)", readme)
        if m and ver and m.group(1) != ver:
            run.add(ERROR, "知识库一致", "ver_readme_drift",
                    "VERSION=%s 但 README 首条当前版本=v%s —— 出版本后 README 行未插或插错位" % (ver, m.group(1)),
                    "README.md", "在 README 顶部插入 v%s 当前版本行(置于旧行之上)" % ver)
        # 2) 代码 //🔴 vNNN ⊆ 守卫 # 🔴 vNNN 且 ⊆ 知识库 【vNNN
        js_vers = set(re.findall(r"//\s*🔴\s*v(\d{3})", hba))
        cr_vers = set(re.findall(r"#\s*🔴\s*v(\d{3})", cr))
        # 历史知识既有【vNNN】行，也有规范 Markdown 标题“## ... vNNN ...”。
        # 两种都算已登记，避免明明存在完整章节却被误报为知识缺口。
        kb_vers = set(re.findall(r"【v(\d{3})", kb_md))
        kb_vers |= set(re.findall(r"(?mi)^#{1,6}[^\n]*\bv(\d{3})\b", kb_md))
        for v in sorted(js_vers - cr_vers):
            run.add(WARN, "知识库一致", "guard_missing_v" + v,
                    "代码里有 //🔴 v%s 标记但 check_resources 无对应 # 🔴 v%s 守卫" % (v, v),
                    "check_resources.py", "为 v%s 补守卫(配置/分支/CSS类/键帧)" % v)
        for v in sorted(js_vers - kb_vers):
            run.add(WARN, "知识库一致", "kb_missing_v" + v,
                    "代码里有 //🔴 v%s 标记但 贾维斯_知识库.md 无【v%s 条目" % (v, v),
                    "贾维斯_知识库.md", "补 v%s 知识库条目(设计/配置/教训/验证)" % v)
        # 3) 代码所有 BUG#N 标记(🔴新式 或 "BUG#N修复"旧式 均认)必须已入知识库
        #    知识库"已记录" = 详细章节/正文出现 BUG#N  或  主目录表 | N | 行(早期bug表)
        code_all = hba
        for fp in jsfiles():
            if fp.endswith("hansen_boss_attack.js"): continue
            code_all += read(fp)
        for fp in (glob.glob(os.path.join(ROOT, "*.html")) + glob.glob(os.path.join(ROOT, "island_*.html"))):
            try: code_all += read(fp)
            except Exception: pass
        code_bugs = set(int(n) for n in re.findall(r"BUG#(\d+)", code_all))
        kb_bugs   = set(int(n) for n in re.findall(r"BUG#(\d+)", kb_md))
        kb_bugs  |= set(int(n) for n in re.findall(r"(?m)^\|\s*(\d+)\s*\|", kb_md))   # 知识库主目录表 | N | 行也算已记录(早期 bug 1-49 以表格登记)
        for n in sorted(code_bugs - kb_bugs):
            run.add(WARN, "知识库一致", "kb_missing_bug%d" % n,
                    "代码有 BUG#%d 标记但知识库(详细章节或主目录表)均无 BUG#%d 记录" % (n, n),
                    "贾维斯_知识库.md", "补 BUG#%d 条目(现象/根因/防线)或登记进主目录表" % n)
        run.add(INFO, "知识库一致", "bug_knowledge_full",
                "全 bug 知识核验: 代码标记 %d 个 BUG·知识库已记录 %d 个·缺口 %d 个(0=贾维斯完整掌握所有要防的 bug)" % (len(code_bugs), len(kb_bugs), len(code_bugs - kb_bugs)))
        if not run.fingerprints() & {"知识库一致|ver_readme_drift"}:
            pass
        run.add(INFO, "知识库一致", "sync_audit_done",
                "四方一致性: 代码版本标记%d个/守卫%d个/知识库%d条 · VERSION=v%s 与 README 对齐核验完成" % (len(js_vers), len(cr_vers), len(kb_vers), ver))
    except Exception as e:
        run.add(WARN, "知识库一致", "sync_audit_err", "一致性审计异常: %s" % str(e)[:120])

# =============================================================================
#  v12.0 ② 退役FX守卫过时检测(v511教训自动化): 守卫若仍要求"必须配置某FX类型",
#  但全部 boss 已无人使用该类型 且 守卫文本未标 死代码/历史/遗产 —— 直接 ERROR 拦截。
# =============================================================================
def retired_fx_guard_audit(run):
    try:
        cr  = read(os.path.join(ROOT, "check_resources.py"))
        hba = read(os.path.join(ROOT, "hansen_boss_attack.js"))
        seen = set()
        for m in re.finditer(r"未配置\s+([A-Za-z_]\w*)", cr):
            typ = m.group(1)
            if typ in seen: continue
            seen.add(typ)
            cnt = hba.count("t:'" + typ + "'")
            if cnt == 0:
                ctx = cr[max(0, m.start()-700): m.start()+700]
                if not any(k in ctx for k in ("死代码", "历史", "遗产")):
                    run.add(ERROR, "退役守卫", "stale_guard_" + typ,
                            "守卫仍要求配置 %s 但已无 boss 使用(count=0)且未标死代码 —— v511教训: 老FX退役必须同步改写其历史守卫" % typ,
                            "check_resources.py", "把该守卫改写为死代码守卫(只查 t==='%s' 分支与组件不丢, 不再查配置)" % typ)
        run.add(INFO, "退役守卫", "retired_audit_done", "退役FX守卫核验完成(扫描 %d 个被要求配置的类型)" % len(seen))
    except Exception as e:
        run.add(WARN, "退役守卫", "retired_audit_err", "退役守卫审计异常: %s" % str(e)[:120])

# =============================================================================
#  v12.0 ③ 工具备份同步: README《🧰 核心开发工具源码备份》各 ```python fence 与本体逐字比对。
#  --apply-safe 时自动修复: 先备份 README → 用本体重写对应 fence → 复验。jarvis.py 小节缺失也会补建。
# =============================================================================
_BK_HEAD = "## 🧰 核心开发工具 · 完整源码备份"
_BK_TOOLS = ["build.py", "check_resources.py", "hansen_health_check.py", "hansen_inspector.py", "hansen_loudness_audit.py", "hansen_evolve.py", "jarvis.py"]

def _fence_for(live):
    runs = re.findall(r"`+", live)
    L = max((len(r) for r in runs), default=0)
    return "`" * max(3, L + 1)

def _bk_zone(readme):
    i = readme.find(_BK_HEAD)
    if i < 0: return -1, -1
    j = readme.find("\n## ", i + 10)
    return i, (j if j > 0 else len(readme))

def tool_backup_sync_check(run):
    try:
        rp = os.path.join(ROOT, "README.md")
        readme = read(rp)
        zi, zj = _bk_zone(readme)
        if zi < 0:
            run.add(WARN, "备份同步", "bk_zone_missing", "README 缺《%s》区段" % _BK_HEAD, "README.md", "重建工具备份区")
            return
        zone = readme[zi:zj]
        stale, missing = [], []
        for fn in _BK_TOOLS:
            live = read(os.path.join(ROOT, fn))
            if not live: continue
            hm = re.search(r"^###\s+\d+\.\s+`" + re.escape(fn) + r"`", zone, re.M)
            if not hm:
                missing.append(fn); continue
            tail = zone[hm.start():]
            nm = re.search(r"^###\s+\d+\.\s+`", tail[3:], re.M)
            blk = tail[: nm.start()+3] if nm else tail
            fm = re.search(r"(`{3,})python\n(.*?)\n?\1", blk, re.S)
            if not fm or fm.group(2).strip() != live.strip():
                stale.append(fn)
        if not stale and not missing:
            run.add(INFO, "备份同步", "bk_sync_ok", "README 工具备份与 %d 个本体逐字一致 ✅" % len(_BK_TOOLS))
            return
        fixed = False
        if APPLY_SAFE and (stale or missing):
            fixed = _bk_autofix(stale, missing)
        for fn in stale:
            run.add(INFO if fixed else WARN, "备份同步", "bk_stale_" + fn,
                    ("已自动同步: " if fixed else "") + "README 备份与本体不一致: %s" % fn,
                    "README.md", "python3 hansen_evolve.py --apply-safe 自动同步(先备份README)")
        for fn in missing:
            run.add(INFO if fixed else WARN, "备份同步", "bk_missing_" + fn,
                    ("已自动补建: " if fixed else "") + "README 备份区缺少小节: %s" % fn,
                    "README.md", "python3 hansen_evolve.py --apply-safe 自动补建小节")
    except Exception as e:
        run.add(WARN, "备份同步", "bk_sync_err", "备份同步检查异常: %s" % str(e)[:120])

def _bk_autofix(stale, missing):
    """安全自修: 备份 README → fence 重写/小节补建 → 复验逐字一致。失败回滚。"""
    rp = os.path.join(ROOT, "README.md")
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        bk = os.path.join(BACKUP_DIR, "README_%s.md" % now_ts())
        shutil.copy2(rp, bk)
        readme = read(rp)
        zi, zj = _bk_zone(readme)
        zone = readme[zi:zj]
        for fn in stale:
            live = read(os.path.join(ROOT, fn))
            hm = re.search(r"^###\s+\d+\.\s+`" + re.escape(fn) + r"`", zone, re.M)
            tail = zone[hm.start():]
            nm = re.search(r"^###\s+\d+\.\s+`", tail[3:], re.M)
            blk_end = hm.start() + (nm.start()+3 if nm else len(tail))
            blk = zone[hm.start():blk_end]
            fm = re.search(r"(`{3,})python\n(.*?)\n?\1", blk, re.S)
            fence = _fence_for(live)
            new_blk = blk[:fm.start()] + fence + "python\n" + live + ("" if live.endswith("\n") else "\n") + fence + blk[fm.end():]
            zone = zone[:hm.start()] + new_blk + zone[blk_end:]
        for fn in missing:
            live = read(os.path.join(ROOT, fn))
            nums = [int(n) for n in re.findall(r"^###\s+(\d+)\.", zone, re.M)] or [0]
            fence = _fence_for(live)
            sec = "\n### %d. `%s` — 贾维斯启动器(「启动贾维斯」= python3 jarvis.py; 串联 check_resources 红线 + 进化引擎 + 汇报)\n\n%spython\n%s%s%s\n" % (max(nums)+1, fn, fence, live, "" if live.endswith("\n") else "\n", fence)
            zone = zone.rstrip() + "\n" + sec
        open(rp, "w", encoding="utf-8").write(readme[:zi] + zone + readme[zj:])
        # 复验
        readme2 = read(rp)
        zi2, zj2 = _bk_zone(readme2)
        zone2 = readme2[zi2:zj2]
        for fn in stale + missing:
            live = read(os.path.join(ROOT, fn))
            hm = re.search(r"^###\s+\d+\.\s+`" + re.escape(fn) + r"`", zone2, re.M)
            if not hm: raise RuntimeError("补建后仍缺 " + fn)
            tail = zone2[hm.start():]
            nm = re.search(r"^###\s+\d+\.\s+`", tail[3:], re.M)
            blk = tail[: nm.start()+3] if nm else tail
            fm = re.search(r"(`{3,})python\n(.*?)\n?\1", blk, re.S)
            if not fm or fm.group(2).strip() != live.strip(): raise RuntimeError("同步后仍不一致 " + fn)
        print("  🔧 备份同步自动修复完成(README 旧版备份: %s)" % os.path.basename(bk))
        return True
    except Exception as e:
        try: shutil.copy2(bk, rp)
        except Exception: pass
        print("  ⚠️ 备份同步自修失败已回滚: %s" % str(e)[:120])
        return False

def load_kb():
    if os.path.exists(KB_PATH):
        try: return json.loads(read(KB_PATH))
        except Exception: pass
    return {"created": now_ts(), "history": [], "known": {}, "resolved_guards": []}

def health_score(run):
    # 只由 ERROR/WARN 驱动; INFO 是通过项/提示, 不扣分(无错无警 = 满分 100)
    pen = 10*len(run.by(ERROR)) + 3*len(run.by(WARN))
    return max(0, round(100 - pen, 1))

def score_by_dimension(run):
    """把本轮 ERROR/WARN 按六个使命维度归类, 各维度独立打分(100-10E-3W), 看出弱在哪。"""
    d = {k: {"E": 0, "W": 0} for k in DIMENSIONS}
    for f in run.by(ERROR): d[_dim_of(f["cat"])]["E"] += 1
    for f in run.by(WARN):  d[_dim_of(f["cat"])]["W"] += 1
    return {k: {"score": max(0, round(100 - 10*d[k]["E"] - 3*d[k]["W"], 1)), "E": d[k]["E"], "W": d[k]["W"]} for k in DIMENSIONS}

def kb_learn(kb, run, score):
    ts = now_ts()
    fps = run.fingerprints()
    # 1. 合并/记录本轮问题(只学 ERROR/WARN, INFO 是"通过"项不入问题库)
    new_cnt = recur_cnt = 0
    for f in run.by(ERROR) + run.by(WARN):
        fp = f["cat"] + "|" + f["id"]
        if fp in kb["known"]:
            kb["known"][fp]["count"] += 1; kb["known"][fp]["last_seen"] = ts
            kb["known"][fp]["sev"] = f["sev"]; recur_cnt += 1
        else:
            kb["known"][fp] = {"first_seen": ts, "last_seen": ts, "count": 1, "sev": f["sev"], "msg": f["msg"]}
            new_cnt += 1
    # 2. 之前记过、本轮消失 = 视为已修 → 固化成永久回归守卫
    resolved = 0
    for fp in list(kb["known"].keys()):
        if fp not in fps and not kb["known"][fp].get("resolved"):
            kb["known"][fp]["resolved"] = ts
            if fp not in [g["fp"] for g in kb["resolved_guards"]]:
                kb["resolved_guards"].append({"fp": fp, "resolved": ts, "msg": kb["known"][fp]["msg"]})
            resolved += 1
    # 3. 健康分趋势
    kb["history"].append({"ts": ts, "score": score,
                          "E": len(run.by(ERROR)), "W": len(run.by(WARN)), "I": len(run.by(INFO))})
    kb["history"] = kb["history"][-200:]
    try: open(KB_PATH, "w", encoding="utf-8").write(json.dumps(kb, ensure_ascii=False, indent=2))
    except Exception as e: print("  ⚠️ KB 写入失败: %s" % e)
    return {"new": new_cnt, "recurring": recur_cnt, "resolved": resolved,
            "total_known": len(kb["known"]), "guards": len(kb["resolved_guards"])}

def load_backlog():
    if os.path.exists(BACKLOG):
        try: return json.loads(read(BACKLOG))
        except Exception: pass
    return {"created": now_ts(), "items": {}}

def update_backlog(bk, run):
    """持久化改进待办(cat 以改进开头的发现); 本轮不再出现的 open 项 -> 自动标记完成(进化进度)。"""
    ts = now_ts()
    cur = {f["cat"] + "|" + f["id"]: f for f in run.findings if f["cat"].startswith("改进")}
    opened = done = 0
    for fp, f in cur.items():
        it = bk["items"].get(fp)
        if it and not it.get("done"):
            it["last_seen"] = ts; it["msg"] = f["msg"]
        elif it and it.get("done"):
            it["done"] = None; it["last_seen"] = ts; opened += 1
        else:
            bk["items"][fp] = {"first_seen": ts, "last_seen": ts, "msg": f["msg"],
                               "fix": f.get("fix", ""), "dim": _dim_of(f["cat"]), "done": None}
            opened += 1
    for fp, v in bk["items"].items():
        if fp not in cur and not v.get("done"):
            v["done"] = ts; done += 1
    try: open(BACKLOG, "w", encoding="utf-8").write(json.dumps(bk, ensure_ascii=False, indent=2))
    except Exception as e: print("  warn backlog write: %s" % e)
    items = [(fp, v) for fp, v in bk["items"].items() if not v.get("done")]
    return {"open": len(items), "opened": opened, "done": done, "total": len(bk["items"]), "items": items}

def regression_alert(kb, run, score):
    """回归预警: 健康分较上一轮下降, 或已固化的修过问题又复发。"""
    alerts = []; hist = kb.get("history", [])
    if len(hist) >= 2:
        prev = hist[-2].get("score", score)
        if score < prev: alerts.append("健康分较上轮下降 %.1f 分(%.1f->%.1f)" % (prev - score, prev, score))
    fps = run.fingerprints()
    for g in [g for g in kb.get("resolved_guards", []) if g["fp"] in fps][:5]:
        alerts.append("已修问题复发: %s" % str(g.get("msg", g["fp"]))[:80])
    return alerts

# =============================================================================
# 🔴v526 说明书嵌入源码自动同步(教训: v12.0 当日改引擎只同步了 README、漏了《说明书》——
#   根因 = self_check 双文档检测但自动修复只覆盖 README 的结构不对称, 自此根除。
#   与 README 备份同等待遇: 先备份 → 自适应 fence 重写 → 逐字复验 → 失败回滚。机械可逆·守安全宪章。)
# =============================================================================
def _manual_doc_sync(dp, ls, open_i, close_i, mine, mk):
    """把文档(《说明书》)内嵌引擎源码 fence 与本体逐字同步; 成功 True, 失败回滚返回 False。"""
    bk = None
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        bk = os.path.join(BACKUP_DIR, os.path.basename(dp).rsplit(".", 1)[0] + "_%s.md" % now_ts())
        shutil.copy2(dp, bk)
        runs = re.findall(r"`+", mine)
        fence = "`" * max(4, max((len(r) for r in runs), default=0) + 1)  # ≥4 保证 self_check F4 仍可见
        lang = ls[open_i].lstrip().lstrip("`").strip() or "python"
        body = mine.rstrip("\n").split("\n")
        new_ls = ls[:open_i] + [fence + lang] + body + [fence] + ls[close_i + 1:]
        open(dp, "w", encoding="utf-8").write("\n".join(new_ls))
        # 复验: 与 self_check 完全同口径重新提取比对
        f4 = "`" * 4
        ls2 = read(dp).split("\n")
        hit2 = [i for i, l in enumerate(ls2) if mk in l]
        mi2 = hit2[0]
        pre2 = [i for i in range(mi2) if ls2[i].lstrip().startswith(f4)]
        post2 = [i for i in range(mi2 + 1, len(ls2)) if ls2[i].lstrip().startswith(f4)]
        emb2 = "\n".join(ls2[pre2[-1] + 1: post2[0]])
        if emb2.rstrip("\n") != mine.rstrip("\n"):
            raise RuntimeError("复验不一致")
        return True
    except Exception as e:
        try:
            if bk:
                shutil.copy2(bk, dp)
        except Exception:
            pass
        print("  ⚠️ 《%s》同步自修失败已回滚: %s" % (os.path.basename(dp), str(e)[:120]))
        return False


def self_check():
    """引擎自检(meta-health): 子工具/数据文件/运行环境是否就绪, 避免哑巴失败。"""
    import shutil
    notes = []
    for t in ["check_resources.py", "hansen_inspector.py", "hansen_health_check.py"]:
        if not os.path.exists(os.path.join(ROOT, t)): notes.append("缺子工具 %s" % t)
    if not os.path.exists(MISSION): notes.append("缺使命文件 hansen_mission.md")
    for f in [KB_PATH, BACKLOG]:
        if os.path.exists(f):
            try: json.loads(read(f))
            except Exception: notes.append("数据文件可能损坏 %s" % os.path.basename(f))
    if (PROBE or DEEP) and not shutil.which("node"):
        notes.append("--probe/--deep 需要 node(Playwright)但未检测到；浏览器断言无法执行")
    # v942: source recovery is guaranteed by package_release.py's required-file
    # list + SHA256SUMS, not by multi-megabyte embedded copies in documentation.
    # Embedded copies inevitably drift and made a healthy engine report false
    # confidence after checking the wrong snapshot.
    return notes
    # v8.0: 引擎自完整性 —— 我的源码备份(README/说明书)是否与本体逐字一致(自动化铁律: 改了引擎忘同步会被自己抓住)
    try:
        mine = read(os.path.join(ROOT, "hansen_evolve.py"))
        MK = "#  hansen_evolve.py — 单词大冒险 · 自主进化引擎 (Autonomous Evolution Engine)"
        F4 = "`" * 4
        if mine and MK in mine:
            for doc in ["README.md", "自主进化引擎·完整说明书.md"]:
                dp = os.path.join(ROOT, doc)
                if not os.path.exists(dp): continue
                ls = read(dp).split("\n")
                hit = [i for i, l in enumerate(ls) if MK in l]
                if not hit: continue
                mi = hit[0]
                pre = [i for i in range(mi) if ls[i].lstrip().startswith(F4)]
                post = [i for i in range(mi + 1, len(ls)) if ls[i].lstrip().startswith(F4)]
                if not pre or not post: continue
                emb = "\n".join(ls[pre[-1] + 1: post[0]])
                if emb.rstrip("\n") != mine.rstrip("\n"):
                    if doc != "README.md" and APPLY_SAFE and _manual_doc_sync(dp, ls, pre[-1], post[0], mine, MK):
                        notes.append("🔧已自动同步《%s》嵌入引擎源码(--apply-safe·旧版已备份至 .evolution_backups)" % doc)
                    else:
                        hint = "(README 由备份同步审计 --apply-safe 修复)" if doc == "README.md" else "(--apply-safe 可自动修复)"
                        notes.append("⚠️源码备份与引擎本体不一致(违反铁律): 《%s》嵌入源码需重新同步%s" % (doc, hint))
    except Exception:
        pass
    return notes

def detect_changes(kb):
    """变更感知: 对源文件做指纹并与上轮比较, 报出本轮改动/新增的文件(引擎知道你动了什么)。"""
    import hashlib
    cur = {}
    for p in islands() + jsfiles() + glob.glob(os.path.join(ROOT, "word_map.js")):
        try: cur[os.path.basename(p)] = hashlib.md5(read(p).encode("utf-8")).hexdigest()
        except Exception: pass
    prev = kb.get("file_hashes") or {}
    added = sorted(f for f in cur if f not in prev) if prev else []
    changed = sorted(f for f, h in cur.items() if f in prev and prev[f] != h) if prev else []
    kb["file_hashes"] = cur
    return {"changed": changed, "added": added, "baseline": bool(prev)}

def trend_verdict(kb):
    """质量走向: 看最近几轮健康分是升是降。"""
    h = [x.get("score", 0) for x in kb.get("history", [])[-6:]]
    if len(h) < 2: return "数据不足(刚开始记录)"
    d = round(h[-1] - h[0], 1)
    return ("上升 +%s 分" % d) if d > 0 else (("下降 %s 分" % d) if d < 0 else "持平")

def ranked_actions(run, kb):
    """优先级行动清单: 按 严重度 × 复发次数 × 是否有明确改法 排序, 告诉你先修哪几个。"""
    known = kb.get("known", {})
    scored = []
    for f in run.by(ERROR) + run.by(WARN):
        fp = f["cat"] + "|" + f["id"]
        recur = known.get(fp, {}).get("count", 1)
        sev_w = 10 if f["sev"] == ERROR else 3
        pri = sev_w * (1 + 0.5 * (recur - 1)) + (1 if f.get("fix") else 0)
        scored.append((round(pri, 1), f, recur))
    scored.sort(key=lambda x: -x[0])
    return scored[:3]

# =============================================================================
#  6) 真机崩溃压力测试(--probe; Playwright 狂点/快速切主题/狂存档/试越级)
# =============================================================================
FUZZ_JS = r"""
const { chromium } = require("playwright");
(async () => {
  let b; const out = { pageerrors: [], notes: [], tested: [] };
  try {
    b = await chromium.launch();
    for (const url of process.argv.slice(2)) {
      const name = url.split("/").pop();
      const pg = await b.newPage();
      pg.on("pageerror", e => out.pageerrors.push(name + " :: " + String(e).slice(0,140)));
      pg.on("dialog", d => d.accept().catch(()=>{}));
      try {
        await pg.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
        await pg.waitForTimeout(2200);
        // 狂点(每次重查; 若页面跳转致查询失败=正常, 记提示并停本页点击)
        for (let i=0;i<30;i++){
          let btns;
          try { btns = await pg.$$("button, .btn, [onclick]"); }
          catch(e){ out.notes.push(name+" 点击触发页面跳转(正常, 非崩溃)"); break; }
          if (btns && btns.length){
            try{ await btns[Math.floor(Math.random()*btns.length)].click({timeout:400,force:true}); }catch(e){}
          }
          await pg.waitForTimeout(60);
        }
        // 主题风暴 + 狂存档 + 试越级(页面内执行, 不依赖元素句柄)
        try {
          await pg.evaluate(async () => {
            const T=["cosmos","pink","ocean","forest","rainbow","peach"];
            for (let k=0;k<12;k++){ try{ window.applyTheme && window.applyTheme(T[k%T.length]); }catch(e){} }
            for (let k=0;k<8;k++){ try{ window.save && window.save(); }catch(e){} try{ window.persist && window.persist(); }catch(e){} }
            try{ window.startBoss && window.startBoss(20); }catch(e){}
          });
        } catch(e){ out.notes.push(name+" evaluate 阶段页面状态变化(正常)"); }
        await pg.waitForTimeout(300);
        out.tested.push(name);
      } catch(e){ out.notes.push(name+" :: "+String(e).slice(0,90)); }
      await pg.close();
    }
  } catch(e){ out.notes.push("FATAL "+String(e).slice(0,120)); }
  if (b) await b.close();
  console.log(JSON.stringify(out));
})();
"""

def crash_fuzz(run):
    isl = islands()
    if not isl: return
    targets = []
    for nm in ("island_animal.html", "island_season.html", "index.html"):
        p = os.path.join(ROOT, nm)
        if os.path.exists(p): targets.append(p)
    targets = targets[:2] or isl[:2]
    fuzz_path = os.path.join(ROOT, "_evolve_fuzz.js")
    open(fuzz_path, "w", encoding="utf-8").write(FUZZ_JS)
    port = "8731"
    srv = subprocess.Popen([sys.executable, "-m", "http.server", port], cwd=ROOT,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)
    try:
        urls = ["http://localhost:%s/%s" % (port, os.path.basename(t)) for t in targets]
        r = subprocess.run(["node", fuzz_path] + urls, cwd=ROOT, capture_output=True, text=True, timeout=180)
        data = {}
        for line in (r.stdout or "").splitlines():
            line = line.strip()
            if line.startswith("{"):
                try: data = json.loads(line)
                except Exception: pass
        tested = data.get("tested", []); pageerrors = data.get("pageerrors", []); notes = data.get("notes", [])
        if pageerrors:
            for e in pageerrors[:12]:
                run.add(ERROR, "崩溃压测", "fuzz_pageerror", "压测触发真实 JS 报错: %s" % e)
            print("  ❌ 崩溃压测: 触发 %d 处真实 JS 报错" % len(pageerrors))
        else:
            run.add(INFO, "崩溃压测", "fuzz_clean", "压测 %d 目标狂点/切主题/狂存档/试越级 —— 零 JS 报错 ✅" % len(tested))
            print("  ✅ 崩溃压测: %d 目标, 零 JS 报错%s" % (len(tested), ("(%d 条跳转提示)" % len(notes)) if notes else ""))
    except Exception as e:
        run.add(WARN, "崩溃压测", "fuzz_run", "压测运行异常(可能缺 node/playwright): %s" % str(e)[:80])
        print("  ⚠️ 崩溃压测跳过: %s" % str(e)[:80])
    finally:
        try: srv.terminate()
        except Exception: pass
        try: os.remove(fuzz_path)
        except Exception: pass

# =============================================================================
#  7) 深度层(--deep; 调监察官 --quick + 健康检查 --quick)
# =============================================================================
def _parse_inspector_report(run):
    """读监察官报告, 把它的 ERROR/WARN 发现并入引擎(计入健康分与知识库)。"""
    rp = os.path.join(ROOT, "hansen_inspector_report.md")
    if not os.path.exists(rp): return 0
    folded = 0; cur = None
    for ln in read(rp).splitlines():
        s = ln.strip()
        if s.startswith("## ❌ ERROR"): cur = ERROR; continue
        if s.startswith("## ⚠️ WARN"): cur = WARN; continue
        if s.startswith("## "): cur = None; continue
        if cur and s.startswith("- **["):
            m = re.match(r"- \*\*\[(.*?)\]\*\*\s*(.*)", s)
            cat = m.group(1) if m else "监察官"
            msg = (m.group(2) if m else s).split("  —  ")[0].strip()
            run.add(cur, "监察官:" + cat, "insp_%d" % folded, msg)
            folded += 1
    return folded

def run_inspector(run, full):
    """完整集成"启动监察官": 默认每轮跑静态 A+B+KB(--no-browser); --deep 跑全部 4 层(含真机浏览器)。
       --ai 时 AI 层也传给监察官。把它的发现并入引擎。跑本引擎 = 也跑了监察官。"""
    p = os.path.join(ROOT, "hansen_inspector.py")
    if not os.path.exists(p):
        run.add(ERROR, "监察官", "no_inspector", "缺 hansen_inspector.py；监察断言未执行"); return
    ai_on = bool(USE_AI and os.environ.get("ANTHROPIC_API_KEY"))
    args = ([] if full else ["--no-browser"]) + (["--ai"] if ai_on else [])
    label = ("监察官·全部4层" + ("+AI" if ai_on else "")) if full else "监察官·静态(A+B+KB)"
    to = 600 if full else 180
    try:
        inspector_report = os.path.join(ROOT, "hansen_inspector_report.md")
        try:
            os.remove(inspector_report)
        except FileNotFoundError:
            pass
        r = subprocess.run([sys.executable, p] + args, cwd=ROOT, capture_output=True, text=True, timeout=to)
        folded = _parse_inspector_report(run)
        report_fresh = os.path.exists(inspector_report)
        if r.returncode == 0 and folded == 0 and report_fresh:
            run.add(INFO, "监察官", "inspector_pass", "%s: 全部通过 ✅" % label)
            print("  ✅ %s: 全部通过" % label)
        else:
            if (r.returncode != 0 or not report_fresh) and folded == 0:
                run.add(ERROR, "监察官", "inspector_failed",
                        "%s 退出码 %d/新报告=%s；断言未完成" % (label, r.returncode, report_fresh))
            print("  ⚠️ %s: 并入 %d 项 ERROR/WARN(详见 hansen_inspector_report.md)" % (label, folded))
    except subprocess.TimeoutExpired:
        _parse_inspector_report(run)
        run.add(ERROR, "监察官", "inspector_timeout", "%s 超时；断言未完整执行" % label)
        print("  ❌ %s 超时，按未执行断言处理" % label)
    except Exception as e:
        run.add(ERROR, "监察官", "inspector_run", "%s 运行异常；断言未执行: %s" % (label, str(e)[:60]))
        print("  ❌ %s 异常: %s" % (label, str(e)[:60]))

def run_health_full(run):
    """--deep: 健康检查全量(真机加载全部岛)。"""
    p = os.path.join(ROOT, "hansen_health_check.py")
    if not os.path.exists(p):
        run.add(ERROR, "健康检查", "health_missing", "缺 hansen_health_check.py；浏览器断言未执行")
        return
    try:
        r = subprocess.run([sys.executable, p], cwd=ROOT, capture_output=True, text=True, timeout=600)
        out = (r.stdout or "") + (r.stderr or ""); ec = out.count("❌")
        if r.returncode != 0:
            tail = out[-600:].replace("\n", " ")
            run.add(ERROR, "健康检查", "health_full",
                    "健康检查失败/未完成(❌×%d, 退出码 %d): %s" % (ec, r.returncode, tail))
            print("  ❌ 健康检查全量: ❌×%d (退出码 %d)" % (ec, r.returncode))
        else:
            run.add(INFO, "健康检查", "health_full", "健康检查全量: 全部通过 ✅")
            print("  ✅ 健康检查全量: 全部通过")
    except subprocess.TimeoutExpired:
        run.add(ERROR, "健康检查", "health_timeout", "健康检查浏览器层超时；断言未完整执行")
        print("  ❌ 健康检查超时，按失败处理")
    except Exception as e:
        run.add(ERROR, "健康检查", "health_run", "健康检查异常；断言未执行: %s" % str(e)[:60])

# =============================================================================
#  8) AI 深度推理层(--ai; 需 ANTHROPIC_API_KEY; 挖静态查不出的深层问题 + 提案)
# =============================================================================
def ai_reason(run, mission, disc):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        print("  ⏭  AI 深度推理层: 跳过(未设 ANTHROPIC_API_KEY —— 设好 key 后加 --ai 启用)")
        run.add(INFO, "AI推理", "ai_skip", "AI 层未启用(无 key)")
        return
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-5")   # 设成你有权限的模型
    # 给 AI 一份代码摘要(文件清单 + 关键共享系统签名), 避免超长
    digest_files = ["hansen_diamond_shop.js", "hansen_theme_lock.js", "hansen_gacha.js",
                    "hansen_island_upgrade.js", "hansen_checkin_global.js", "hansen_season.js"]
    digest = []
    for f in digest_files:
        t = read(os.path.join(ROOT, f))
        if t: digest.append("### %s (前80行)\n%s" % (f, "\n".join(t.splitlines()[:80])))
    found = "\n".join("- [%s] %s: %s" % (f["sev"], f["cat"], f["msg"]) for f in run.by(ERROR)+run.by(WARN)) or "(本轮静态无 ERROR/WARN)"
    prompt = (
        "你是「单词大冒险」H5 背单词小程序的自主进化 AI。下面是它的使命宪法、代码摘要、本轮静态发现。\n"
        "请挖掘**静态检查发现不了的深层问题**:微妙的逻辑/状态 bug、可能导致崩溃的边界、UX 缺陷、"
        "经济失衡、以及任何**违背健康/无黑暗模式原则**的设计。\n"
        "严格只输出一个 JSON 数组, 每项: {\"sev\":\"ERROR|WARN|INFO\",\"cat\":\"类别\",\"id\":\"短标识\","
        "\"msg\":\"问题描述\",\"where\":\"文件/位置(可空)\",\"fix\":\"具体建议改法\"}。不要任何额外文字或 ```。\n\n"
        "## 使命宪法\n" + mission["text"][:4000] +
        "\n\n## 自主发现\n" + json.dumps(disc, ensure_ascii=False) +
        "\n\n## 代码摘要\n" + "\n\n".join(digest)[:9000] +
        "\n\n## 本轮静态发现\n" + found
    )
    body = json.dumps({"model": model, "max_tokens": 4000,
                       "messages": [{"role": "user", "content": prompt}]}).encode("utf-8")
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body,
            headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        resp = json.loads(urllib.request.urlopen(req, timeout=150).read().decode("utf-8"))
        text = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text").strip()
        text = re.sub(r"^```(json)?|```$", "", text.strip()).strip()
        items = json.loads(text)
        cnt = 0
        for it in items:
            if not isinstance(it, dict): continue
            sev = it.get("sev", "INFO"); sev = sev if sev in RANK else "INFO"
            run.add(sev, "AI:" + it.get("cat", "深度"), "ai_" + str(it.get("id", cnt)),
                    it.get("msg", ""), where=it.get("where", ""), fix=it.get("fix", ""))
            cnt += 1
        print("  🤖 AI 深度推理: 提出 %d 条洞见(模型 %s)" % (cnt, model))
    except Exception as e:
        print("  ⚠️ AI 层调用失败(key/网络/模型名?): %s" % str(e)[:120])
        run.add(INFO, "AI推理", "ai_error", "AI 层调用失败: %s" % str(e)[:80])

# =============================================================================
#  9) 分级处置: 安全可逆类自动修(--apply-safe, 备份+验证+回滚) + 其余生成提案
# =============================================================================
CONTENT_JS = r"""
const { chromium } = require("playwright");
(async () => {
  const urls = process.argv.slice(2);
  const out = {}; const b = await chromium.launch(); const CONC = 6;
  async function one(url) {
    const name = url.split("/").pop(); const pg = await b.newPage();
    pg.on("dialog", d => d.accept().catch(()=>{}));
    try {
      const t0 = Date.now();
      await pg.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
      const ms = Date.now() - t0;
      await pg.waitForTimeout(700);
      const r = await pg.evaluate(() => {
        let words = null;
        try { if (typeof allW !== "undefined" && Array.isArray(allW)) words = allW; } catch(e){}
        try { if (!words && typeof DATA !== "undefined") words = DATA.flatMap(c => (c.words||[])); } catch(e){}
        if (!words) return { ok:false, reason:"runtime word list not readable" };
        const iss = []; const seen = {}; let n = 0;
        for (const w of words) { n++;
          const en=(w&&w.en||"").trim(), cn=(w&&w.cn||"").trim(), ex=(w&&w.ex||"").trim();
          if (!en) iss.push("空英文词条");
          else { if (seen[en.toLowerCase()]) iss.push("岛内重复词: "+en); seen[en.toLowerCase()]=1; }
          if (en && !cn) iss.push("缺中文释义: "+en);
          if (en && !ex) iss.push("缺例句: "+en);
        }
        return { ok:true, n, iss };
      });
      r.ms = ms; out[name] = r;
    } catch(e){ out[name] = { ok:false, reason:String(e).slice(0,70) }; }
    await pg.close();
  }
  for (let i=0;i<urls.length;i+=CONC){ await Promise.all(urls.slice(i,i+CONC).map(one)); }
  await b.close(); console.log(JSON.stringify(out));
})();
"""

def _dump_words():
    """无头浏览器读每岛运行时真实词表 -> {island:[{en,pn,cn,ex,exCn}]}。失败返回 {}。"""
    import shutil, subprocess
    if not shutil.which("node"): return {}
    isl = islands()
    if not isl: return {}
    js = r"""
const { chromium } = require("playwright");
(async () => {
  const out = {}; const b = await chromium.launch();
  for (const url of process.argv.slice(2)) {
    const name = url.split("/").pop().replace("island_","").replace(".html","");
    const pg = await b.newPage(); pg.on("dialog", d=>d.accept().catch(()=>{}));
    try { await pg.goto(url,{waitUntil:"domcontentloaded",timeout:20000}); await pg.waitForTimeout(800);
      out[name] = await pg.evaluate(() => { let w=null; try{if(typeof allW!=="undefined")w=allW;}catch(e){} try{if(!w&&typeof DATA!=="undefined")w=DATA.flatMap(c=>(c.words||[]));}catch(e){} return w?w.map(x=>({en:x.en,pn:x.pn,cn:x.cn,ex:x.ex,exCn:x.exCn})):null; });
    } catch(e){ out[name]=null; }
    await pg.close();
  }
  await b.close(); require("fs").writeFileSync("_hsn_words.json", JSON.stringify(out)); console.log("ok");
})();
"""
    port = 8313
    srv = subprocess.Popen([sys.executable,"-m","http.server",str(port)], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)
    jsp = os.path.join(ROOT, "_hsn_words.js")
    try:
        open(jsp,"w",encoding="utf-8").write(js)
        urls = ["http://localhost:%d/%s" % (port, os.path.basename(p)) for p in isl]
        subprocess.run(["node", jsp] + urls, cwd=ROOT, capture_output=True, text=True, timeout=220)
        outp = os.path.join(ROOT, "_hsn_words.json")
        data = json.loads(read(outp)) if os.path.exists(outp) else {}
        try: os.remove(outp)
        except Exception: pass
        return data
    except Exception:
        return {}
    finally:
        try: os.remove(jsp)
        except Exception: pass
        srv.terminate()

def ai_content_audit(run):
    """AI 内容纠错(--ai): 把真实词条(英/音标/中/例句)分批送 Claude, 判断 翻译准否/例句地道与语法/音标 是否有错,
       挑出"存在但不对"的内容问题(记 WARN 供人核)。需 ANTHROPIC_API_KEY + 消耗 token。"""
    import urllib.request
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not (USE_AI and key): return
    words = _dump_words()
    flat = [(isl, w) for isl, ws in words.items() if ws for w in ws if w and w.get("en")]
    if not flat:
        run.add(INFO, "AI内容", "no_words", "AI内容纠错: 未取到词表(需 node 抽取)"); return
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-5")
    found = 0; BATCH = 40
    for bi in range(0, len(flat), BATCH):
        batch = flat[bi:bi+BATCH]
        items = [{"i": j, "island": isl, "en": w.get("en"), "pn": w.get("pn"), "cn": w.get("cn"), "ex": w.get("ex"), "exCn": w.get("exCn")} for j, (isl, w) in enumerate(batch)]
        prompt = ("你是中考英语教研专家。下面是单词卡(en英文/pn音标/cn中文释义/ex英文例句/exCn例句中译)。"
                  "只挑出确有错误的卡:中文释义不准或错、例句语法错或不地道、例句与词义不符、例句中译与英文不符、音标明显错误。"
                  "没问题的不要报。严格只输出 JSON 数组, 每项 {\"i\":序号,\"problem\":\"简述\",\"fix\":\"建议\"};无问题输出 []。数据:" + json.dumps(items, ensure_ascii=False))
        try:
            req = urllib.request.Request("https://api.anthropic.com/v1/messages",
                data=json.dumps({"model": model, "max_tokens": 1500, "messages": [{"role": "user", "content": prompt}]}).encode("utf-8"),
                headers={"content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
            resp = json.loads(urllib.request.urlopen(req, timeout=70).read().decode("utf-8"))
            txt = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text")
            txt = txt[txt.find("["): txt.rfind("]")+1] if "[" in txt else "[]"
            for it in (json.loads(txt) or []):
                idx = it.get("i", -1)
                if isinstance(idx, int) and 0 <= idx < len(batch):
                    isl, w = batch[idx]
                    run.add(WARN, "AI内容", "aic_%s_%s" % (isl, w.get("en", "")[:20]), "%s · %s(%s): %s" % (isl, w.get("en"), w.get("cn"), it.get("problem", "")), fix=it.get("fix", ""))
                    found += 1
        except Exception as e:
            run.add(INFO, "AI内容", "err", "AI内容纠错某批失败(可能网络/额度): %s" % str(e)[:70]); break
    if not found:
        run.add(INFO, "AI内容", "clean", "AI 内容纠错: 送审 %d 词, 未发现明显错误 ✅" % len(flat))

def content_check(run):
    """运行时内容体检(--content / --deep): 无头浏览器读每岛真实词表, 查 空词条/缺中文释义/缺例句/岛内重复词。
       查"学习内容本身对不对"的唯一可靠办法 —— 读运行时真实数据, 不靠正则猜, 不误报。"""
    import shutil, subprocess, hashlib
    if not shutil.which("node"):
        run.add(INFO, "内容体检", "no_node", "未装 node(Playwright), 跳过运行时内容体检"); return
    isl = islands()
    if not isl: return
    port = 8311
    srv = subprocess.Popen([sys.executable, "-m", "http.server", str(port)], cwd=ROOT,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2)
    jsp = os.path.join(ROOT, "_hsn_content_probe.js")
    try:
        open(jsp, "w", encoding="utf-8").write(CONTENT_JS)
        urls = ["http://localhost:%d/%s" % (port, os.path.basename(p)) for p in isl]
        r = subprocess.run(["node", jsp] + urls, cwd=ROOT, capture_output=True, text=True, timeout=240)
        lines = [x for x in (r.stdout or "").strip().splitlines() if x.strip().startswith("{")]
        data = json.loads(lines[-1]) if lines else {}
        unread = [n for n, v in data.items() if not v.get("ok")]
        total_w = sum(v.get("n", 0) for v in data.values() if v.get("ok"))
        _times = [(n, v.get("ms")) for n, v in data.items() if v.get("ok") and isinstance(v.get("ms"), (int, float))]
        if _times:
            _mss = sorted(t for _, t in _times); _med = _mss[len(_mss)//2]
            _slow = ["%s(%dms)" % (n, t) for n, t in _times if _med and t > 2.0 * _med and t > 1500]
            if _slow:
                run.add(INFO, "改进·性能", "slow_islands", "%d 个岛加载明显偏慢(>2x中位 %dms): %s" % (len(_slow), _med, ", ".join(_slow[:6])), fix="精简该岛初始化/资源以加快加载")
        if unread:
            run.add(INFO, "内容体检", "unreadable", "%d 岛运行时词表未能读取(本轮未体检): %s" % (len(unread), ", ".join(unread[:6])))
        issues = [(n, it) for n, v in data.items() for it in (v.get("iss") or [])]
        if issues:
            for n, it in issues[:40]:
                cid = "c_" + hashlib.md5((n + it).encode("utf-8")).hexdigest()[:8]
                sev = ERROR if ("缺中文释义" in it or "空英文词条" in it) else WARN
                run.add(sev, "内容体检", cid, "%s — %s" % (n, it), fix="补全/去重该词条数据")
        elif data:
            run.add(INFO, "内容体检", "clean", "运行时内容体检通过: %d 岛 %d 词, 无空释义/缺例句/岛内重复 ✅" % (len([1 for v in data.values() if v.get('ok')]), total_w))
    except Exception as e:
        run.add(INFO, "内容体检", "error", "内容体检异常(不阻断): %s" % str(e)[:80])
    finally:
        try: os.remove(jsp)
        except Exception: pass
        srv.terminate()

def _backup_html_js():
    dst = os.path.join(BACKUP_DIR, now_ts())
    os.makedirs(dst, exist_ok=True)
    for p in glob.glob(os.path.join(ROOT, "*.html")) + glob.glob(os.path.join(ROOT, "*.js")) + [os.path.join(ROOT, "VERSION")]:
        if os.path.exists(p): shutil.copy2(p, dst)
    return dst

def _verify_check_resources():
    p = os.path.join(ROOT, "check_resources.py")
    if not os.path.exists(p): return True
    try:
        return subprocess.run([sys.executable, p], cwd=ROOT, capture_output=True, text=True, timeout=120).returncode == 0
    except Exception: return False

def safe_autofix(run):
    """安全可逆修复白名单。每个都: 备份 -> 改 -> 重跑 check_resources 验证 -> 不过则回滚。"""
    applied = []
    if not APPLY_SAFE:
        return applied
    # 安全修复 #1: 主缓存戳失同步(check_resources 报 或 v7.0 的 cache_stamp_drift)-> 跑 build.py 当前版本重同步
    desync = any((f["id"] == "check_resources" and ("缓存戳" in f["msg"] or "?v=" in f["msg"])) or f["id"] == "cache_stamp_drift" for f in run.by(ERROR))
    if desync and os.path.exists(os.path.join(ROOT, "build.py")):
        ver = read(os.path.join(ROOT, "VERSION")).strip() or "0"
        bdir = _backup_html_js()
        try:
            r = subprocess.run([sys.executable, "build.py", ver], cwd=ROOT, capture_output=True, text=True, timeout=300)
            if r.returncode == 0 and _verify_check_resources():
                applied.append("缓存戳重同步(build v%s) —— 已验证通过(备份: %s)" % (ver, os.path.basename(bdir)))
            else:
                for p in glob.glob(os.path.join(bdir, "*")): shutil.copy2(p, ROOT)  # 回滚
                applied.append("缓存戳重同步失败 -> 已自动回滚(备份: %s)" % os.path.basename(bdir))
        except Exception as e:
            for p in glob.glob(os.path.join(bdir, "*")): shutil.copy2(p, ROOT)
            applied.append("缓存戳重同步异常 -> 已回滚: %s" % str(e)[:60])
    return applied

def write_proposals(run, autofixed):
    """把未自动修的 ERROR/WARN 写成提案文件(每条带建议改法 + 采纳提示)。"""
    todo = [f for f in run.by(ERROR) + run.by(WARN)]
    if not todo: return None
    os.makedirs(REPORT_DIR, exist_ok=True)
    path = os.path.join(REPORT_DIR, "proposed_%s.md" % now_ts())
    L = ["# 自主进化引擎 · 修改提案 (%s)\n" % now_ts(),
         "> 引擎只对'安全可逆'类自动修复(见下方报告);以下问题**需 Hansen 审核后采纳**, 引擎不擅自改游戏逻辑。\n"]
    for i, f in enumerate(todo, 1):
        L.append("## %d. [%s] %s — %s" % (i, f["sev"], f["cat"], f["id"]))
        L.append("- **问题**: %s" % f["msg"])
        if f["where"]: L.append("- **位置**: %s" % f["where"])
        L.append("- **建议改法**: %s" % (f["fix"] or "(见问题描述; 需人工判断)"))
        L.append("")
    open(path, "w", encoding="utf-8").write("\n".join(L))
    return path

# =============================================================================
#  报告
# =============================================================================
def write_report(run, disc, score, kbinfo, autofixed, prop_path, kb, dims=None, bkinfo=None, alerts=None, selfnotes=None, changes=None, actions=None):
    os.makedirs(REPORT_DIR, exist_ok=True)
    path = os.path.join(REPORT_DIR, "report_%s.md" % now_ts())
    hist = kb["history"][-8:]
    trend = " → ".join("%s(%s)" % (h["score"], h["ts"][5:16]) for h in hist) or str(score)
    E, W, I = run.by(ERROR), run.by(WARN), run.by(INFO)
    L = []
    L.append("# 🤖 单词大冒险 · 自主进化报告  %s\n" % now_ts())
    L.append("## 健康分: **%s / 100**  (ERROR×%d · WARN×%d · INFO×%d)\n" % (score, len(E), len(W), len(I)))
    if alerts:
        L.append("## 🚨 回归预警\n" + "\n".join("- %s" % a for a in alerts) + "\n")
    if dims:
        L.append("## 📊 六维度健康分\n" + "\n".join("- **%s**: %s/100%s" % (k, v["score"], ("  (ERROR×%d WARN×%d)" % (v["E"], v["W"])) if (v["E"] or v["W"]) else "") for k, v in dims.items()) + "\n")
    L.append("**趋势(近8轮)**: %s\n" % trend)
    # v8.0: 下一步进化建议(引擎自我指方向; 仅建议不自动改游戏 —— 守安全宪章)
    if E:
        _nxt = "先清零阻断问题: " + E[0]["msg"][:72]
    elif actions:
        _nxt = "优先处理: " + actions[0][1]["msg"][:78]
    elif W:
        _nxt = "处理待办项: " + W[0]["msg"][:72]
    else:
        _nxt = "已无 ERROR/WARN —— 在最低维度上继续打磨, 或推进路线图下一项(真人发音补齐 / 答题反馈音效)。"
    L.append("## 🧭 下一步进化建议\n- %s\n" % _nxt)
    L.append("**质量走向**: %s\n" % trend_verdict(kb))
    if changes is not None and (changes.get("changed") or changes.get("added")):
        _ch = changes.get("changed", []); _ad = changes.get("added", [])
        L.append("## 🔍 本轮变更感知\n- 改动文件 %d 个%s · 新增 %d 个%s\n" % (len(_ch), ("(" + ", ".join(_ch[:8]) + ")") if _ch else "", len(_ad), ("(" + ", ".join(_ad[:6]) + ")") if _ad else ""))
    if selfnotes:
        L.append("## 🩺 引擎自检\n" + "\n".join("- %s" % x for x in selfnotes) + "\n")
    if actions:
        L.append("## 🎯 建议优先处理(按 严重度×复发×可操作 排序)\n" + "\n".join("%d. [%s·复发%d] %s%s" % (i, f["sev"], rc, f["msg"], ("  · 改法: " + f["fix"]) if f.get("fix") else "") for i, (pri, f, rc) in enumerate(actions, 1)) + "\n")
    L.append("## 自主发现\n- 岛 %d(赛季:%s) · 共享系统 %d · 游戏模式 %d 种 · 货币 %s · 钻石主题 %d\n"
             % (disc["islands"], "有" if disc["season"] else "无", disc["shared_modules"],
                len(disc["modes"]), "/".join(disc["currencies"]) or "?", disc["diamond_themes"]))
    L.append("## 自我学习(知识库)\n- 本轮新问题 %d · 复发 %d · 判定已修(固化为永久守卫) %d\n- 知识库累计问题指纹 %d · 永久回归守卫 %d\n"
             % (kbinfo["new"], kbinfo["recurring"], kbinfo["resolved"], kbinfo["total_known"], kbinfo["guards"]))
    if bkinfo is not None:
        L.append("## 💡 改进待办清单(自动累积; 检测到的改进点列在这, 修一项自动划掉一项)\n- 当前待办 **%d** 项 · 本轮新增 %d · 本轮完成 %d · 累计登记 %d\n"
                 % (bkinfo["open"], bkinfo["opened"], bkinfo["done"], bkinfo["total"]))
        if bkinfo["items"]:
            L.append("\n".join("  - [%s] %s%s" % (v.get("dim", ""), v["msg"], ("  · 建议: " + v["fix"]) if v.get("fix") else "") for fp, v in bkinfo["items"][:20]) + "\n")
    if autofixed:
        L.append("## ✅ 已自动修复(安全可逆类, 已验证)\n" + "\n".join("- " + a for a in autofixed) + "\n")
    else:
        L.append("## 自动修复\n- 本轮无安全可逆类修复%s\n" % ("" if APPLY_SAFE else "(且未开 --apply-safe, 一切只提案)"))
    if E:
        L.append("## ❌ ERROR(%d)\n" % len(E) + "\n".join("- **%s** %s%s" % (f["cat"], f["msg"], ("  · 建议: "+f["fix"]) if f["fix"] else "") for f in E) + "\n")
    if W:
        L.append("## ⚠️ WARN(%d)\n" % len(W) + "\n".join("- **%s** %s%s" % (f["cat"], f["msg"], ("  · 建议: "+f["fix"]) if f["fix"] else "") for f in W) + "\n")
    if prop_path:
        L.append("## 待审提案\n- 详见: `%s`\n" % os.path.relpath(prop_path, ROOT))
    L.append("## ✅ 通过项(%d, 折叠)\n<details><summary>展开</summary>\n\n%s\n</details>\n"
             % (len([f for f in I if not f["cat"].startswith("改进")]), "\n".join("- %s: %s" % (f["cat"], f["msg"]) for f in I if not f["cat"].startswith("改进"))))
    L.append("\n---\n*由 hansen_evolve.py 自动生成。绝不无人监管改游戏逻辑;只自动修安全可逆类,其余提案待人采纳。*")
    open(path, "w", encoding="utf-8").write("\n".join(L))
    return path

def _notify(summary, title="单词大冒险·进化引擎"):
    """若设了环境变量 HANSEN_NOTIFY_URL, 把本轮摘要推送到你的群机器人/微信。
       自动识别 企业微信 / 钉钉 / 飞书 / Server酱 的不同格式。"""
    url = os.environ.get("HANSEN_NOTIFY_URL")
    if not url:
        return False
    try:
        u = url.lower()
        if "feishu" in u or "larksuite" in u:
            data = json.dumps({"msg_type": "text", "content": {"text": title + "\n" + summary}}).encode("utf-8"); ct = "application/json"
        elif "ftqq" in u or "sctapi" in u:
            data = urllib.parse.urlencode({"title": title, "desp": summary}).encode("utf-8"); ct = "application/x-www-form-urlencoded"
        else:
            data = json.dumps({"msgtype": "text", "text": {"content": title + "\n" + summary}}).encode("utf-8"); ct = "application/json"
        req = urllib.request.Request(url, data=data, headers={"content-type": ct})
        urllib.request.urlopen(req, timeout=20)
        print("  \U0001F4F2 已推送本轮汇报到你的 webhook")
        return True
    except Exception as e:
        print("  \u26a0\ufe0f 推送失败(检查 HANSEN_NOTIFY_URL): %s" % str(e)[:80])
        return False


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _write_dashboard(kb, run, score, dims=None, bkinfo=None, alerts=None):
    """每轮写总览看板 evolution_dashboard.html —— 你随时打开就看到引擎全部工作与学习历史。"""
    hist = kb.get("history", []); known = kb.get("known", {}); guards = kb.get("resolved_guards", [])
    E, W = run.by(ERROR), run.by(WARN)
    open_n = len([1 for k, v in known.items() if not v.get("resolved")])
    pts = [h.get("score", 0) for h in hist[-30:]] or [score]; n = len(pts)
    def sx(i): return 20 + (i * (560.0 / (n - 1)) if n > 1 else 280)
    def sy(v): return 115 - (v / 100.0 * 95)
    poly = " ".join("%.1f,%.1f" % (sx(i), sy(v)) for i, v in enumerate(pts))
    dots = "".join('<circle cx="%.1f" cy="%.1f" r="2.6" fill="#BF8F00"/>' % (sx(i), sy(v)) for i, v in enumerate(pts))
    if E:   status, color = "\u274c 有阻断问题", "#ef4444"
    elif W: status, color = "\u26a0\ufe0f 有待办项", "#f59e0b"
    else:   status, color = "\u2705 健康", "#22c55e"
    if E + W:
        irows = "".join("<tr><td><span class='tag %s'>%s</span></td><td>%s</td><td>%s</td></tr>" % (f["sev"][0], f["sev"], _esc(f["cat"]), _esc(f["msg"])) for f in (E + W))
    else:
        irows = "<tr><td colspan='3' class='empty'>本轮没有发现问题 \u2705 引擎会继续巡检</td></tr>"
    if guards:
        grows = "".join("<tr><td>%s</td><td>%s</td></tr>" % (_esc(g.get("msg", "")), g.get("resolved", "")) for g in guards[-20:])
    else:
        grows = "<tr><td colspan='2' class='empty'>暂无(修过的问题会自动固化到这里, 保证永不复发)</td></tr>"
    rrows = "".join("<tr><td>%s</td><td style='color:%s;font-weight:700'>%s</td><td>ERROR\u00d7%d WARN\u00d7%d</td></tr>" % (h.get("ts", ""), ("#22c55e" if h.get("score", 0) >= 100 else ("#ef4444" if h.get("E", 0) else "#f59e0b")), h.get("score", 0), h.get("E", 0), h.get("W", 0)) for h in reversed(hist[-12:]))
    dimrows = ""
    if dims:
        for k, v in dims.items():
            sc = v["score"]; bc = "#22c55e" if sc >= 100 else ("#ef4444" if sc < 70 else "#f59e0b")
            dimrows += "<div class='dim'><div class='dl'>%s</div><div class='bar'><i style='width:%d%%;background:%s'></i></div><div class='dv'>%s</div></div>" % (_esc(k), int(sc), bc, sc)
    if bkinfo and bkinfo.get("items"):
        blrows = "".join("<tr><td>%s</td><td>%s</td></tr>" % (_esc(v.get("dim", "")), _esc(v["msg"])) for fp, v in bkinfo["items"][:20])
    else:
        blrows = "<tr><td colspan='2' class='empty'>暂无待办(检测到的改进点会自动列在这, 修好自动划掉)</td></tr>"
    bopen = bkinfo.get("open", 0) if bkinfo else 0; bdone = bkinfo.get("done", 0) if bkinfo else 0
    alertbar = ("<div class='alert'>🚨 回归预警: %s</div>" % _esc("; ".join(alerts))) if alerts else ""
    html = """<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>单词大冒险 · 进化引擎看板</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0b1530;color:#e6edf7;font-family:"Microsoft YaHei",system-ui,sans-serif;padding:22px;line-height:1.6}
.wrap{max-width:920px;margin:0 auto}
h1{font-size:21px;color:#fff}
.sub{color:#8aa0c0;font-size:12.5px;margin:4px 0 18px}
.hero{display:flex;align-items:center;gap:26px;background:#11203f;border:1px solid #1f3a66;border-radius:16px;padding:22px 26px;margin-bottom:16px;flex-wrap:wrap}
.score{font-size:52px;font-weight:800;color:__COLOR__;line-height:1}
.status{font-size:18px;font-weight:800;color:__COLOR__}
.hint{color:#8aa0c0;font-size:12px;margin-top:3px}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}
.card{background:#11203f;border:1px solid #1f3a66;border-radius:12px;padding:14px}
.card .n{font-size:25px;font-weight:800;color:#BF8F00}
.card .l{font-size:12px;color:#8aa0c0;margin-top:2px}
.box{background:#11203f;border:1px solid #1f3a66;border-radius:14px;padding:16px 18px;margin-bottom:14px}
.box h2{font-size:14px;color:#BF8F00;margin-bottom:10px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th,td{text-align:left;padding:7px 8px;border-bottom:1px solid #1c3358;vertical-align:top}
.empty{color:#6f86a8}
.tag{display:inline-block;padding:1px 8px;border-radius:6px;font-size:11px;font-weight:800}
.tag.E{background:#3a1620;color:#ff7a90}.tag.W{background:#3a2e10;color:#ffcf6b}
svg{width:100%;height:135px;background:#0d1a36;border:1px solid #1f3a66;border-radius:12px;margin-bottom:16px}
.dims{display:flex;flex-direction:column;gap:7px}
.dim{display:flex;align-items:center;gap:10px}
.dim .dl{width:84px;font-size:12px;color:#cdd9ee}
.dim .bar{flex:1;height:10px;background:#0d1a36;border:1px solid #1f3a66;border-radius:6px;overflow:hidden}
.dim .bar i{display:block;height:100%}
.dim .dv{width:44px;text-align:right;font-size:12px;font-weight:800;color:#cdd9ee}
.alert{background:#3a1620;border:1px solid #7a2230;color:#ff9aa9;border-radius:10px;padding:11px 14px;margin-bottom:14px;font-size:13px;font-weight:700}
.foot{color:#6f86a8;font-size:11.5px;text-align:center;margin-top:6px}
</style></head><body><div class="wrap">
<h1>\U0001F916 单词大冒险 · 自主进化引擎看板</h1>
<div class="sub">本页每轮自动更新 —— 引擎在后台不断巡检、学习、积累经验。最后更新:__TIME__</div>
<div class="hero">
<div><div class="score">__SCORE__</div><div class="hint">健康分 / 100</div></div>
<div><div class="status">__STATUS__</div><div class="hint">__OPEN__ 项当前未解决 · 已累计 __GUARDS__ 条永久守卫(修过的 bug 永不复发)</div></div>
</div>
__ALERT__
<svg viewBox="0 0 600 135"><polyline fill="none" stroke="#BF8F00" stroke-width="2.2" points="__POLY__"/>__DOTS__</svg>
<div class="cards">
<div class="card"><div class="n">__ROUNDS__</div><div class="l">累计巡检轮次</div></div>
<div class="card"><div class="n">__KNOWN__</div><div class="l">累计发现问题</div></div>
<div class="card"><div class="n">__GUARDS__</div><div class="l">永久回归守卫</div></div>
<div class="card"><div class="n">__OPEN__</div><div class="l">当前未解决</div></div>
</div>
<div class="box"><h2>当前问题(本轮)</h2><table>__ISSUES__</table></div>
<div class="box"><h2>📊 六维度健康分</h2><div class="dims">__DIMS__</div></div>
<div class="box"><h2>💡 改进待办 — __BOPEN__ 项待办 · 本轮完成 __BDONE__(修好自动划掉)</h2><table>__BACKLOG__</table></div>
<div class="box"><h2>已固化的永久守卫 — 这些问题已修, 引擎保证永不复发</h2><table>__GUARDROWS__</table></div>
<div class="box"><h2>最近巡检记录</h2><table>__RUNS__</table></div>
<div class="foot">由 hansen_evolve.py 自动生成 · 绝不无监管改游戏逻辑, 只自动修安全可逆类、其余提案待你采纳</div>
</div></body></html>"""
    for k, v in {"__COLOR__": color, "__SCORE__": str(score), "__STATUS__": status, "__TIME__": now_ts(), "__OPEN__": str(open_n), "__GUARDS__": str(len(guards)), "__ROUNDS__": str(len(hist)), "__KNOWN__": str(len(known)), "__POLY__": poly, "__DOTS__": dots, "__ISSUES__": irows, "__GUARDROWS__": grows, "__RUNS__": rrows, "__DIMS__": dimrows, "__BACKLOG__": blrows, "__BOPEN__": str(bopen), "__BDONE__": str(bdone), "__ALERT__": alertbar}.items():
        html = html.replace(k, v)
    path = os.path.join(ROOT, "evolution_dashboard.html")
    open(path, "w", encoding="utf-8").write(html)
    return path

# =============================================================================
#  一轮 / 主循环
# =============================================================================
def one_cycle():
    t0 = time.time()
    print("\n" + "=" * 64)
    print("🤖 贾维斯 (JARVIS) · 自主进化引擎 v12.0 —— 开始一轮  %s" % now_ts())
    print("=" * 64)
    run = Run()
    selfnotes = self_check()
    if selfnotes:
        print("  ❌ 引擎自检: " + "; ".join(selfnotes))
        for index, note in enumerate(selfnotes):
            run.add(ERROR, "工具", "self_check_%d" % index, note)
    else: print("  🩺 引擎自检: 子工具/数据/环境就绪 ✅")
    mission = load_mission()
    disc = discover()
    print("\n[1/7] 静态主关(check_resources) ..."); run_check_resources(run)
    print("[2/7] 对齐使命的深查(崩溃/经济/一致/健康) + 四方一致性/退役守卫 ..."); mission_checks(run, disc); improvement_scan(run, disc); perf_sentinel(run); cache_stamp_checks(run); dangling_ref_checks(run); inline_drift_checks(run); kb_guard_sync_audit(run); retired_fx_guard_audit(run)
    print("[3/7] 集成监察官(%s) ..." % ("全部4层+真机浏览器" if DEEP else "静态A+B+KB; --deep 开启全部4层"))
    run_inspector(run, full=DEEP)
    if PROBE: print("[4/7] 真机崩溃压力测试 ..."); crash_fuzz(run)
    else: print("[4/7] 崩溃压测: 跳过(加 --probe 开启)")
    if DEEP: print("[5/7] 健康检查全量 ..."); run_health_full(run)
    else: print("[5/7] 健康检查全量: 跳过(加 --deep 开启)")
    if DEEP or CONTENT:
        print("[5b/7] 运行时内容体检(读真实词表查空释义/缺例句/重复词) ..."); content_check(run)
    else:
        print("[5b/7] 内容体检: 跳过(加 --content 或 --deep 开启)")
    print("[6/7] AI 深度推理 ...")
    if USE_AI: ai_reason(run, mission, disc); ai_content_audit(run)
    else: print("  ⏭  跳过(加 --ai 且设 ANTHROPIC_API_KEY 开启)")
    # 学习 + 处置 + 报告
    score = health_score(run)
    dims = score_by_dimension(run)
    kb = load_kb()
    changes = detect_changes(kb)
    kbinfo = kb_learn(kb, run, score)
    bk = load_backlog(); bkinfo = update_backlog(bk, run)
    alerts = regression_alert(kb, run, score)
    actions = ranked_actions(run, kb)
    autofixed = safe_autofix(run)
    prop = write_proposals(run, autofixed)
    rep = write_report(run, disc, score, kbinfo, autofixed, prop, kb, dims, bkinfo, alerts, selfnotes, changes, actions)
    dash = _write_dashboard(kb, run, score, dims, bkinfo, alerts)
    if RELEASE:
        run.add(ERROR, "工具", "legacy_release_disabled",
                "--release 旧打包路径已封死；只能运行 package_release.py/build.py 的唯一发布契约")
    _E, _W = run.by(ERROR), run.by(WARN)
    if _E:   _hd = "❌ %s/100 有阻断问题" % score
    elif _W: _hd = "⚠️ %s/100 有待办项" % score
    else:    _hd = "✅ %s/100 健康" % score
    _msg = ["🤖 单词大冒险·进化引擎 第 %d 轮" % len(kb["history"]), _hd, "ERROR×%d WARN×%d | 本轮 新%d 复发%d 已修%d | 累计永久守卫%d" % (len(_E), len(_W), kbinfo["new"], kbinfo["recurring"], kbinfo["resolved"], kbinfo["guards"])]
    if alerts: _msg.append("🚨 回归预警: " + "; ".join(alerts[:3]))
    _low = min(dims.items(), key=lambda kv: kv[1]["score"])
    _msg.append("维度最低: %s %s分 | 改进待办 %d 项(本轮完成%d)" % (_low[0], _low[1]["score"], bkinfo["open"], bkinfo["done"]))
    if changes and (changes.get("changed") or changes.get("added")):
        _msg.append("本轮变更 %d 文件" % (len(changes.get("changed", [])) + len(changes.get("added", []))))
    if actions:
        _msg.append("优先修: " + actions[0][1]["msg"][:60])
    for _f in (_E + _W)[:6]: _msg.append("· [%s] %s" % (_f["sev"], _f["msg"][:70]))
    _msg.append("看板 evolution_dashboard.html · " + now_ts())
    _notify("\n".join(_msg))
    print("\n[7/7] 处置 + 报告完成")
    print("-" * 64)
    print("健康分 %s/100 | ERROR×%d WARN×%d INFO×%d | 新问题%d 复发%d 已修%d | 守卫%d"
          % (score, len(run.by(ERROR)), len(run.by(WARN)), len(run.by(INFO)),
             kbinfo["new"], kbinfo["recurring"], kbinfo["resolved"], kbinfo["guards"]))
    print("报告: %s" % os.path.relpath(rep, ROOT))
    print("看板: %s  (随时打开看引擎在干啥/学到啥)" % os.path.relpath(dash, ROOT))
    if prop: print("待审提案: %s" % os.path.relpath(prop, ROOT))
    print("耗时 %.1fs" % (time.time() - t0))
    return 1 if (run.by(ERROR) or run.by(WARN)) else 0

def _reldir():
    d = os.path.join(ROOT, "releases"); os.makedirs(d, exist_ok=True); return d

def _rel_read_json(name, default):
    p = os.path.join(_reldir(), name)
    if os.path.exists(p):
        try: return json.loads(read(p))
        except Exception: pass
    return default

def _rel_write_json(name, obj):
    open(os.path.join(_reldir(), name), "w", encoding="utf-8").write(json.dumps(obj, ensure_ascii=False))

def _load_deployed():
    d = _rel_read_json(".deployed.json", [])
    return d if isinstance(d, list) else []

def _prune_snapshots():
    """自动保留策略: 已上线(deployed)包永久钉住; 未上线快照只留最近 KEEP_SNAPSHOTS 个, 多余的删。
       绝不动: 已上线包 / 最新可部署包 / 回滚包 / 发布说明.md / 各内部清单。"""
    rel = _reldir()
    deployed_zips = {e.get("zip") for e in _load_deployed()}
    versioned = []
    for p in glob.glob(os.path.join(rel, "单词大冒险_v*_发布*_*.zip")):
        m = re.search(r"_发布(\d+)_", os.path.basename(p))
        if m: versioned.append((int(m.group(1)), p))
    versioned.sort(key=lambda x: -x[0])  # 按发布序号 新→旧
    nondep = [p for s, p in versioned if os.path.basename(p) not in deployed_zips]
    removed = []
    for p in nondep[KEEP_SNAPSHOTS:]:    # 超出保留窗口的未上线旧快照 -> 删
        try: os.remove(p); removed.append(os.path.basename(p))
        except Exception: pass
    return removed

def mark_deployed():
    """把"最近一次发布"标记为已上线: 记入 .deployed.json(永久钉住, 不被自动清理) + 存其清单供后续
       '相比上次上线版'对比 + 在 发布说明.md 给该版本标 🚀 已上线。独立命令, 不跑检查。"""
    rel = _reldir()
    latest = _rel_read_json(".latest_release.json", None)
    if not latest:
        print("⚠️ 还没有任何发布。先跑: python3 hansen_evolve.py --release"); return 1
    tag = latest["tag"]
    deployed = _load_deployed()
    if deployed and deployed[-1].get("tag") == tag:
        print("ℹ️ 最近发布 %s 已标记为已上线, 无需重复。" % tag); return 0
    ts = now_ts()
    deployed.append({"tag": tag, "ver": latest.get("ver"), "seq": latest.get("seq"), "zip": latest.get("zip"), "deployed_ts": ts})
    _rel_write_json(".deployed.json", deployed)
    _rel_write_json(".deployed_manifest.json", latest.get("manifest", {}))  # 供下次发布算"相比上次上线版"差异
    notes_p = os.path.join(rel, "发布说明.md")
    if os.path.exists(notes_p):
        lines = read(notes_p).split("\n")
        for i, ln in enumerate(lines):
            if ln.startswith("## ") and (tag + " ·") in ln:
                if "🚀" not in ln:
                    lines[i] = ln + "  🚀已上线"
                    lines.insert(i + 1, "- 🚀 **已上线**: %s" % ts)
                break
        open(notes_p, "w", encoding="utf-8").write("\n".join(lines))
    pruned = _prune_snapshots()
    print("🚀 已标记 %s 为已上线(%s) —— 该版本将永久保留, 永不被自动清理。" % (tag, ts))
    print("   正式上线 = 把 releases/%s 的内容传到 CloudBase 静态托管。" % latest.get("zip"))
    if pruned: print("   🧹 顺带清理了 %d 个超窗口的未上线旧快照。" % len(pruned))
    print("   今后 --release 的发布说明会自动列出'相比本上线版的变更'。")
    return 0

def prepare_rollback():
    """一键准备回滚到'上一个已上线版本': 把那个版本的包复制成 回滚到上一稳定版.zip + 打印回滚清单。
       只准备不部署(部署始终人工确认)。独立命令。"""
    import shutil
    rel = _reldir()
    deployed = _load_deployed()
    if len(deployed) == 0:
        print("⚠️ 还没有标记过任何已上线版本。上线后请先: python3 hansen_evolve.py --mark-deployed"); return 1
    if len(deployed) < 2:
        print("⚠️ 目前只有一个已上线版本(%s), 没有更早的稳定版可回滚到。" % deployed[-1].get("tag")); return 1
    cur, target = deployed[-1], deployed[-2]   # 当前线上=最近上线; 回滚目标=上一个上线版
    src = os.path.join(rel, target.get("zip", ""))
    if not target.get("zip") or not os.path.exists(src):
        print("⚠️ 上一稳定版 %s 的包不在 releases/(可能被手动删过): %s" % (target.get("tag"), target.get("zip"))); return 1
    dst = "回滚到上一稳定版.zip"
    shutil.copy2(src, os.path.join(rel, dst))
    print("🔙 已准备回滚包: releases/%s" % dst)
    print("   ├ 当前线上版本: %s (上线于 %s)" % (cur.get("tag"), cur.get("deployed_ts")))
    print("   └ 回滚目标版本: %s (上线于 %s; 源包 %s)" % (target.get("tag"), target.get("deployed_ts"), target.get("zip")))
    print("   回滚步骤:")
    print("   1) 用 CloudBase CLI/控制台, 把 releases/%s 的内容传到静态托管(覆盖当前文件)" % dst)
    print("   2) 清一次 CDN 缓存(至少 index.html), 否则会继续吐问题版本的入口页")
    print("   3) 打开线上验证已恢复正常")
    print("   说明: 该版本缓存戳与问题版本不同, 客户端会自动取回正确旧资源, 回滚是干净的。")
    return 0

def _release_notes_header():
    return ("# 单词大冒险 · 发布说明(自主进化引擎自动维护)\n\n"
            "> 最新可部署包永远在: `releases/单词大冒险_最新可部署包.zip` —— 解压后 index.html 在根, 可直接传静态托管。\n"
            "> 每次 `--release`(或 --apply-safe 真正修复后)自动追加一条: 版本/时间/健康分/改了哪些文件/自动修复/已知问题。\n\n"
            "## ⚠️ 部署与维护铁律(每次发布前必看)\n"
            "- 部署包: index.html 必须在 zip **根目录**, 无包装文件夹; **不含** .py/.md/.txt\n"
            "- **三套缓存戳互不混淆**: 主 `?v=NNN`(build.py 自动管) / 单词音频 `?vNNN`(手动~22处) / 例句音频 `?vNNN`(手动)\n"
            "- 所有音频统一 **-16 LUFS**; 改过音频后必须跑 `hansen_loudness_audit.py`\n"
            "- 改 .js/.html 游戏文件后须 `python3 build.py NNN` 重打包; 改 .py 工具须同步 README/说明书的源码备份\n"
            "- 打包前先跑 `python3 hansen_health_check.py --quick`(铁律1.0)\n"
            "- 部署目标: CloudBase 静态托管(env `word-d6gf7rx2532903425`)\n\n")

def make_release(run, score, changes=None, autofixed=None):
    """打一个可直接静态部署的小程序包(index.html 在根; 排除 .py/.md/.txt 及引擎自身产物), 版本化存入 releases/,
       维护 releases/单词大冒险_最新可部署包.zip 始终指向最新, 并写/更新 releases/发布说明.md
       (每个版本记录: 版本号/时间/健康分/相比上次发布改了哪些文件/本轮自动修复/当前已知问题/部署铁律)。
       只快照当前状态, 不改游戏(守安全宪章)。由 --release 触发, 或 --apply-safe 真正应用了修复后自动触发。"""
    raise RuntimeError(
        "legacy release packager is disabled in v942; use package_release.py "
        "through build.py so deploy allow-list, secret scan, SHA256SUMS, and "
        "reproducible ZIP verification cannot be bypassed"
    )
    import hashlib, zipfile, shutil  # unreachable historical implementation
    rel = os.path.join(ROOT, "releases")
    os.makedirs(rel, exist_ok=True)
    ver = (read(os.path.join(ROOT, "VERSION")).strip() or "0")
    EXC_EXT = (".md", ".py", ".txt")
    EXC_FILE = {"audio_test.html", "spelling_bee_demo.html",
                "evolution_dashboard.html", "hansen_evolve_kb.json", "hansen_evolve_backlog.json"}
    SKIP_DIR = {"__pycache__", "releases", "evolution_reports"}
    files = []  # (绝对路径, zip内相对路径)
    for dp, dirs, fns in os.walk(ROOT):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in SKIP_DIR]
        for fn in fns:
            if fn.lower().endswith(EXC_EXT) or fn in EXC_FILE:
                continue
            full = os.path.join(dp, fn)
            files.append((full, os.path.relpath(full, ROOT).replace(os.sep, "/")))
    has_index = any(r == "index.html" for _, r in files)
    # 发布序号(每次发布 +1)
    seqp = os.path.join(rel, ".seq")
    try: seq = int(read(seqp).strip()) + 1
    except Exception: seq = 1
    # 相比"上次发布"改了哪些文件(发布专用清单, 与逐轮 detect_changes 互不影响)
    manifest = {}
    for full, r in files:
        try:
            with open(full, "rb") as fh: manifest[r] = hashlib.md5(fh.read()).hexdigest()
        except Exception: pass
    mfp = os.path.join(rel, ".release_manifest.json")
    prev = {}
    if os.path.exists(mfp):
        try: prev = json.loads(read(mfp))
        except Exception: prev = {}
    first = not prev
    added = sorted(set(manifest) - set(prev))
    removed = sorted(set(prev) - set(manifest))
    changed = sorted(k for k in manifest if k in prev and manifest[k] != prev[k])
    # 相比"上次上线版本"的差异(比快照差异更有意义: 用户上次更新以来到底变了什么)
    dep_mf = {}
    dmp = os.path.join(rel, ".deployed_manifest.json")
    if os.path.exists(dmp):
        try: dep_mf = json.loads(read(dmp))
        except Exception: dep_mf = {}
    _dep = _load_deployed()
    last_dep_tag = _dep[-1]["tag"] if _dep else None
    d_added = sorted(set(manifest) - set(dep_mf)) if dep_mf else []
    d_removed = sorted(set(dep_mf) - set(manifest)) if dep_mf else []
    d_changed = sorted(k for k in manifest if k in dep_mf and manifest[k] != dep_mf[k]) if dep_mf else []
    # 打可部署 zip
    tag = "v%s_发布%d" % (ver, seq)
    zname = "单词大冒险_%s_%s.zip" % (tag, datetime.datetime.now().strftime("%Y%m%d"))
    zpath = os.path.join(rel, zname)
    total = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for full, r in files:
            z.write(full, r)
            try: total += os.path.getsize(full)
            except Exception: pass
    shutil.copy2(zpath, os.path.join(rel, "单词大冒险_最新可部署包.zip"))
    open(mfp, "w", encoding="utf-8").write(json.dumps(manifest, ensure_ascii=False))
    open(seqp, "w", encoding="utf-8").write(str(seq))
    _rel_write_json(".latest_release.json", {"tag": tag, "ver": ver, "seq": seq, "zip": zname, "ts": now_ts(), "manifest": manifest})
    deploy_ok = has_index and not run.by(ERROR)  # 无 ERROR 且 index 在根 = 可直接部署
    # ---- 写/更新 发布说明.md(最新条目置顶) ----
    E, W = run.by(ERROR), run.by(WARN)
    def _fl(lst, n=30):
        if not lst: return "无"
        return ", ".join(lst[:n]) + (" …共%d个" % len(lst) if len(lst) > n else "")
    L = ["## 📦 %s · %s · 健康分 %s/100 %s" % (tag, now_ts(), score, "✅可直接部署" if deploy_ok else "⚠️部署校验未过(见下)")]
    L.append("- **部署包**: `releases/%s`(%d 文件, %.1f MB; index.html 在根, 可直接传 CloudBase 静态托管)" % (zname, len(files), total / 1048576))
    if first:
        L.append("- **变更**: 首个发布(基线已记录, 之后会列出每次相比上次发布的文件改动)")
    else:
        L.append("- **相比上次发布的文件变更**: 改动 %d · 新增 %d · 删除 %d" % (len(changed), len(added), len(removed)))
        if changed: L.append("  - 改动: %s" % _fl(changed))
        if added:   L.append("  - 新增: %s" % _fl(added))
        if removed: L.append("  - 删除: %s" % _fl(removed))
        if not (changed or added or removed): L.append("  - (与上次发布无文件差异; 本次仅刷新备份)")
    if last_dep_tag:
        L.append("- **相比上次上线版本(%s)的变更**(即用户上次更新以来): 改动 %d · 新增 %d · 删除 %d" % (last_dep_tag, len(d_changed), len(d_added), len(d_removed)))
        if d_changed: L.append("  - 改动: %s" % _fl(d_changed))
        if d_added:   L.append("  - 新增: %s" % _fl(d_added))
        if d_removed: L.append("  - 删除: %s" % _fl(d_removed))
        if not (d_changed or d_added or d_removed): L.append("  - (与上次上线版本无文件差异)")
    if autofixed:
        L.append("- **本轮引擎自动修复**: %s" % "; ".join(autofixed))
    if E or W:
        L.append("- **当前已知问题(下个版本待解)**:")
        for f in (E + W)[:12]:
            L.append("  - [%s] %s%s" % (f["sev"], f["msg"][:90], ("  —— %s" % f["where"]) if f.get("where") else ""))
    else:
        L.append("- **当前已知问题**: 无 ERROR/WARN ✅")
    if not deploy_ok:
        L.append("- ⚠️ **部署校验**: index.html 在根=%s, 存在阻断 ERROR=%s —— 部署前请先清掉 ERROR" % (has_index, bool(run.by(ERROR))))
    entry = "\n".join(L) + "\n\n"
    notes_p = os.path.join(rel, "发布说明.md")
    MARK = "<!--RELEASES-->"
    if os.path.exists(notes_p):
        doc = read(notes_p)
        if MARK in doc:
            head, tail = doc.split(MARK, 1)
            doc = head + MARK + "\n\n" + entry + tail.lstrip("\n")
        else:
            doc = doc.rstrip() + "\n\n" + entry
    else:
        doc = _release_notes_header() + MARK + "\n\n" + entry
    open(notes_p, "w", encoding="utf-8").write(doc)
    pruned = _prune_snapshots()
    print("  📦 发布 %s -> releases/%s (%d 文件, %.1fMB)%s" % (tag, zname, len(files), total / 1048576, "" if deploy_ok else "  ⚠️部署校验未过"))
    if pruned: print("  🧹 自动保留: 已删 %d 个超出保留窗口(留最近 %d 个)的未上线旧快照; 已上线版与发布说明永久保留" % (len(pruned), KEEP_SNAPSHOTS))
    return {"tag": tag, "zip": zpath, "files": len(files), "changed": changed, "added": added, "removed": removed, "deploy_ok": deploy_ok, "pruned": pruned}

def main():
    if RELEASE or MARK_DEPLOYED or ROLLBACK_PREP:
        print("❌ hansen_evolve 的旧发布/上线快照路径已在 v942 永久封死。")
        print("   请使用 build.py → package_release.py → GitHub Actions 不可变 Release。")
        sys.exit(2)
    if MARK_DEPLOYED:
        sys.exit(mark_deployed())
    if ROLLBACK_PREP:
        sys.exit(prepare_rollback())
    if WATCH:
        try: mins = max(1, int(WATCH))
        except ValueError: mins = 30
        print("🔁 无人值守模式: 每 %d 分钟自动跑一轮(Ctrl+C 退出)。建议挂 cron / 服务器 / 云函数定时触发更稳。" % mins)
        while True:
            try: one_cycle()
            except Exception as e: print("⚠️ 本轮异常(不中断守护): %s" % str(e)[:120])
            print("💤 休眠 %d 分钟 ...\n" % mins); time.sleep(mins * 60)
    else:
        sys.exit(one_cycle())

if __name__ == "__main__":
    main()
