var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import { AbstractSDKRequest, StorageType, formatUrl, } from './vendor_cloudbase_adapter_interface_v965.js';
import { ReadableStream } from './vendor_web_streams_polyfill_v965.js';
function isMatch() {
    if (typeof wx === "undefined") {
        return false;
    }
    if (typeof Page === "undefined") {
        return false;
    }
    if (!wx.getSystemInfoSync) {
        return false;
    }
    if (!wx.getStorageSync) {
        return false;
    }
    if (!wx.setStorageSync) {
        return false;
    }
    if (!wx.connectSocket) {
        return false;
    }
    if (!wx.request) {
        return false;
    }
    try {
        if (!wx.getSystemInfoSync()) {
            return false;
        }
        if (wx.getSystemInfoSync().AppPlatform === "qq") {
            return false;
        }
    }
    catch (e) {
        return false;
    }
    return true;
}
function isPlugin() {
    return (typeof App === "undefined" &&
        typeof getApp === "undefined" &&
        !wx.onAppHide &&
        !wx.offAppHide &&
        !wx.onAppShow &&
        !wx.offAppShow);
}
var TASK_ABORT_ERROR_MSG = "Error when aborting requestTask";
var WxRequest = (function (_super) {
    __extends(WxRequest, _super);
    function WxRequest(config) {
        if (config === void 0) { config = {}; }
        var _this = _super.call(this) || this;
        var timeout = config.timeout, timeoutMsg = config.timeoutMsg, restrictedMethods = config.restrictedMethods;
        _this._timeout = timeout || 0;
        _this._timeoutMsg = timeoutMsg || "请求超时";
        _this._restrictedMethods = restrictedMethods || [
            "get",
            "post",
            "upload",
            "download",
        ];
        return _this;
    }
    WxRequest.prototype.post = function (options) {
        var self = this;
        return new Promise(function (resolve, reject) {
            var url = options.url, data = options.data, headers = options.headers;
            var task = wx.request({
                url: formatUrl("https:", url),
                data: data,
                timeout: self._timeout,
                method: "POST",
                header: headers,
                success: function (res) {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        resolve({
                            statusCode: res.statusCode,
                            status: res.statusCode,
                            data: res.data,
                        });
                    }
                    else {
                        reject(res);
                    }
                },
                fail: function (err) {
                    reject(err);
                },
                complete: function (err) {
                    if (!err || !err.errMsg) {
                        return;
                    }
                    if (!self._timeout ||
                        self._restrictedMethods.indexOf("post") === -1) {
                        return;
                    }
                    var errMsg = err.errMsg;
                    if (errMsg === "request:fail timeout") {
                        console.warn(self._timeoutMsg);
                        try {
                            task.abort();
                        }
                        catch (e) { }
                    }
                },
            });
        });
    };
    WxRequest.prototype.get = function (options) {
        var self = this;
        return new Promise(function (resolve, reject) {
            var url = options.url, body = options.body, headers = options.headers;
            var finalUrl = formatUrl("https:", url);
            var task = wx.request({
                url: finalUrl,
                data: body,
                timeout: self._timeout,
                method: "GET",
                header: headers,
                success: function (res) {
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        resolve({
                            statusCode: res.statusCode,
                            status: res.statusCode,
                            data: res.data,
                        });
                    }
                    else {
                        reject(res);
                    }
                },
                fail: function (err) {
                    reject(err);
                },
                complete: function (err) {
                    if (!err || !err.errMsg) {
                        return;
                    }
                    if (!self._timeout || self._restrictedMethods.indexOf("get") === -1) {
                        return;
                    }
                    var errMsg = err.errMsg;
                    if (errMsg.includes("timeout")) {
                        console.warn(self._timeoutMsg);
                        try {
                            task.abort();
                        }
                        catch (e) {
                            console.warn(TASK_ABORT_ERROR_MSG, e);
                        }
                    }
                },
            });
        });
    };
    WxRequest.prototype.upload = function (options) {
        var _this = this;
        var self = this;
        return new Promise(function (resolve) { return __awaiter(_this, void 0, void 0, function () {
            var url, file, data, headers, onUploadProgress, task;
            return __generator(this, function (_a) {
                url = options.url, file = options.file, data = options.data, headers = options.headers, onUploadProgress = options.onUploadProgress;
                task = wx.uploadFile({
                    url: url,
                    filePath: file,
                    name: "file",
                    formData: __assign({}, data),
                    header: headers,
                    timeout: this._timeout,
                    success: function (res) {
                        var result = {
                            statusCode: res.statusCode,
                            data: res.data || {},
                        };
                        if (res.statusCode === 200 && data.success_action_status) {
                            result.statusCode = parseInt(data.success_action_status, 10);
                        }
                        resolve(result);
                    },
                    fail: function (err) {
                        resolve(err);
                    },
                    complete: function (err) {
                        if (!err || !err.errMsg) {
                            return;
                        }
                        if (!self._timeout ||
                            self._restrictedMethods.indexOf("upload") === -1) {
                            return;
                        }
                        var errMsg = err.errMsg;
                        if (errMsg === "request:fail timeout") {
                            console.warn(self._timeoutMsg);
                            try {
                                task.abort();
                            }
                            catch (e) { }
                        }
                    },
                });
                if (onUploadProgress) {
                    task.onProgressUpdate(function (res) {
                        onUploadProgress(res);
                    });
                }
                return [2];
            });
        }); });
    };
    WxRequest.prototype.download = function (options) {
        var _this = this;
        var self = this;
        return new Promise(function (resolve, reject) {
            var url = options.url, headers = options.headers;
            var task = wx.downloadFile({
                url: formatUrl("https:", url),
                header: headers,
                timeout: _this._timeout,
                success: function (res) {
                    if (res.statusCode === 200 && res.tempFilePath) {
                        resolve({
                            statusCode: 200,
                            tempFilePath: res.tempFilePath,
                        });
                    }
                    else {
                        resolve(res);
                    }
                },
                fail: function (err) {
                    reject(err);
                },
                complete: function (err) {
                    if (!err || !err.errMsg) {
                        return;
                    }
                    if (!self._timeout ||
                        self._restrictedMethods.indexOf("download") === -1) {
                        return;
                    }
                    var errMsg = err.errMsg;
                    if (errMsg === "request:fail timeout") {
                        console.warn(self._timeoutMsg);
                        try {
                            task.abort();
                        }
                        catch (e) { }
                    }
                },
            });
        });
    };
    WxRequest.prototype.fetch = function (options) {
        var url = options.url, body = options.body, enableAbort = options.enableAbort, headers = options.headers, method = options.method, _a = options.stream, shouldStream = _a === void 0 ? false : _a, signal = options.signal, _timeout = options.timeout;
        var self = this;
        var timeout = _timeout !== null && _timeout !== void 0 ? _timeout : this._timeout;
        var controller = null;
        var stream = new ReadableStream({
            start: function (c) {
                controller = c;
            },
            cancel: function () {
                controller = null;
            },
        });
        return new Promise(function (resolve, reject) {
            shouldStream && resolve({ data: stream });
            var task = wx.request({
                url: formatUrl("https:", url),
                data: body,
                timeout: timeout,
                method: method.toUpperCase(),
                header: headers,
                success: function (res) {
                    controller === null || controller === void 0 ? void 0 : controller.close();
                    !shouldStream && resolve(res);
                },
                fail: function (err) {
                    controller === null || controller === void 0 ? void 0 : controller.close();
                    reject(err);
                    if (shouldStream) {
                        throw err;
                    }
                },
                complete: function (err) {
                    if (!err || !err.errMsg) {
                        return;
                    }
                    if (!timeout ||
                        self._restrictedMethods.indexOf("post") === -1 ||
                        !enableAbort) {
                        return;
                    }
                    var errMsg = err.errMsg;
                    if (errMsg === "request:fail timeout") {
                        console.warn(self._timeoutMsg);
                        try {
                            task.abort();
                        }
                        catch (e) {
                            console.warn(TASK_ABORT_ERROR_MSG, e);
                        }
                    }
                },
                enableChunked: shouldStream,
            });
            task.onChunkReceived(function (buffer) {
                controller === null || controller === void 0 ? void 0 : controller.enqueue(new Uint8Array(buffer.data));
            });
            if (signal) {
                var abort_1 = function () {
                    try {
                        task.abort();
                    }
                    catch (e) {
                        console.warn(TASK_ABORT_ERROR_MSG, e);
                    }
                };
                if (signal.aborted) {
                    abort_1();
                }
                else {
                    signal.addEventListener("abort", function () { return abort_1(); });
                }
            }
        });
    };
    WxRequest.prototype.patch = function (options) {
        var method = options.method, headers = options.headers;
        var headersTemp = JSON.parse(JSON.stringify(headers || {}));
        if (method.toUpperCase() === "PATCH") {
            headersTemp["X-HTTP-Method-Override"] = "PATCH";
            method = "POST";
        }
        return this.post(__assign(__assign({}, options), { method: method, headers: headersTemp }));
    };
    return WxRequest;
}(AbstractSDKRequest));
export { WxRequest };
export var wxMpStorage = {
    setItem: function (key, value) {
        wx.setStorageSync(key, value);
    },
    getItem: function (key) {
        return wx.getStorageSync(key);
    },
    removeItem: function (key) {
        wx.removeStorageSync(key);
    },
    clear: function () {
        wx.clearStorageSync();
    },
};
var WxMpWebSocket = (function () {
    function WxMpWebSocket(url, options) {
        if (options === void 0) { options = {}; }
        var ws = wx.connectSocket(__assign({ url: url }, options));
        var socketTask = {
            set onopen(cb) {
                ws.onOpen(cb);
            },
            set onmessage(cb) {
                ws.onMessage(cb);
            },
            set onclose(cb) {
                ws.onClose(cb);
            },
            set onerror(cb) {
                ws.onError(cb);
            },
            send: function (data) { return ws.send({ data: data }); },
            close: function (code, reason) {
                return ws.close({
                    code: code,
                    reason: reason,
                });
            },
            get readyState() {
                return ws.readyState;
            },
            CONNECTING: 0,
            OPEN: 1,
            CLOSING: 2,
            CLOSED: 3,
        };
        return socketTask;
    }
    return WxMpWebSocket;
}());
export { WxMpWebSocket };
export function parseQueryString(search) {
    var params = {};
    var cleanSearch = search.replace(/^[?#]/, "");
    if (!cleanSearch) {
        return params;
    }
    var pairs = cleanSearch.split("&");
    pairs.forEach(function (item) {
        var _a = item.split("="), key = _a[0], value = _a[1];
        key = decodeURIComponent(key);
        value = decodeURIComponent(value);
        if (key) {
            if (params[key]) {
                if (Array.isArray(params[key])) {
                    params[key].push(value);
                }
                else {
                    params[key] = [params[key], value];
                }
            }
            else {
                params[key] = value;
            }
        }
    });
    return params;
}
function genAdapter(options) {
    var adapter = {
        root: { globalThis: {} },
        reqClass: WxRequest,
        wsClass: WxMpWebSocket,
        captchaOptions: {
            openURIWithCallback: function (_url) {
                var EventBus = options.EventBus;
                var queryObj = {};
                var url = _url;
                console.log("openURIWithCallback", _url);
                var matched = _url.match(/^(data:.*?)(\?[^#\s]*)?$/);
                if (matched) {
                    url = matched[1];
                    console.log("openURIWithCallback url", url);
                    var search = matched[2];
                    if (search) {
                        queryObj = parseQueryString(search);
                    }
                }
                console.log("openURIWithCallback queryObj", queryObj);
                var token = queryObj.token, restQueryObj = __rest(queryObj, ["token"]);
                if (/^data:/.test(url) && !token) {
                    return Promise.reject({
                        error: "invalid_argument",
                        error_description: "invalie captcha data: " + _url,
                    });
                }
                if (!token) {
                    return Promise.reject({
                        error: "unimplemented",
                        error_description: "need to impl captcha data",
                    });
                }
                return new Promise(function (resolve) {
                    console.log("wait for captcha...");
                    EventBus.$emit("CAPTCHA_DATA_CHANGE", __assign(__assign({}, restQueryObj), { token: token,
                        url: url }));
                    EventBus.$once("RESOLVE_CAPTCHA_DATA", function (res) {
                        resolve(res);
                    });
                });
            },
        },
        localStorage: wxMpStorage,
        primaryStorage: StorageType.local,
        getAppSign: function () {
            var info = wx.getAccountInfoSync();
            if (isPlugin()) {
                return info && info.plugin ? info.plugin.appId : "";
            }
            else {
                return info && info.miniProgram ? info.miniProgram.appId : "";
            }
        },
    };
    return adapter;
}
var adapter = {
    genAdapter: genAdapter,
    isMatch: isMatch,
    runtime: "wx_mp",
};
export default adapter;
