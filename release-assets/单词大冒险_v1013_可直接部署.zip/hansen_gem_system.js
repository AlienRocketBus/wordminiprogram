
(function(){
  'use strict';
  if(window.__hansenGemSystemLoaded) return; window.__hansenGemSystemLoaded = true;

  var GEM_WALLET_KEY = 'hansen_wallet_gems';
  var CLEAR_FLAG_KEY = 'hansen_gems_cleared_v1';
  var AWARD_KEY='hansen_gem_awards_v942',AWARD_PENDING_KEY='hansen_gem_award_pending_v942';
  var MAX_BALANCE=1000000000,MAX_AWARD=100000;

  function saveError(msg,e){try{if(typeof window.__hsnSaveNotice==='function')window.__hsnSaveNotice(msg,e);else window.dispatchEvent(new CustomEvent('hansen-save-error',{detail:{message:msg,error:String(e&&e.message||e||msg)}}));}catch(_e){}}
  function rawRestore(k,v){try{if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v);return localStorage.getItem(k)===(v===null?null:String(v));}catch(e){return false;}}
  function walletReady(){try{return localStorage.getItem(CLEAR_FLAG_KEY)==='1';}catch(e){return false;}}

  var ISLAND_SAVE_KEYS = [
    'wordIslandAnimal','wordIslandFood','wordIslandColorNum','wordIslandSchool',
    'wordIslandSports','wordIslandBody','wordIslandClothes','wordIslandHouse',
    'wordIslandCity','wordIslandFamily','wordIslandNature','wordIslandPeople',
    'wordIslandPronouns','wordIslandMisc','wordIslandAdj','wordIslandVerbs',
    'wordIslandTime','wordIslandTransport'

  ];

  function readGems(){try{var raw=localStorage.getItem(GEM_WALLET_KEY);if(raw===null)return 0;var v=Number(raw);return isFinite(v)&&Math.floor(v)===v&&v>=0&&v<=MAX_BALANCE?v:null;}catch(e){return null;}}
  function getGems(){var n=readGems();return n===null?0:n;}
  function setGems(n){
    try {var v=String(Math.max(0,Math.floor(n)));localStorage.setItem(GEM_WALLET_KEY,v);return localStorage.getItem(GEM_WALLET_KEY)===v;} catch(e){return false;}
  }
  function readAwards(){
    try{
      var raw=localStorage.getItem(AWARD_KEY);if(raw===null)return {};var o=JSON.parse(raw);
      if(!o||typeof o!=='object'||Array.isArray(o))return null;
      var keys=Object.keys(o);for(var i=0;i<keys.length;i++){
        var id=keys[i],r=o[id];if(!validId(id)||!r||typeof r!=='object'||Array.isArray(r)||!exactInt(r.amount,0,MAX_AWARD)||!exactInt(r.at,1,Number.MAX_SAFE_INTEGER))return null;
        if(Object.prototype.hasOwnProperty.call(r,'migrated')&&r.migrated!==true)return null;
      }
      return o;
    }catch(e){return null;}
  }
  function writeAwards(o){try{var raw=JSON.stringify(o);localStorage.setItem(AWARD_KEY,raw);return localStorage.getItem(AWARD_KEY)===raw;}catch(e){return false;}}
  function readPending(){try{var raw=localStorage.getItem(AWARD_PENDING_KEY);if(raw===null)return null;var p=JSON.parse(raw);return p&&typeof p==='object'&&!Array.isArray(p)?p:{__invalid:true};}catch(e){return {__invalid:true};}}
  function validId(id){return typeof id==='string'&&id.length>0&&id.length<=160&&!/[\u0000-\u001f\u007f]/.test(id)&&id!=='__proto__'&&id!=='prototype'&&id!=='constructor';}
  function exactInt(v,min,max){return typeof v==='number'&&isFinite(v)&&Math.floor(v)===v&&v>=min&&v<=max;}
  function validPending(p){return !!(p&&!p.__invalid&&validId(p.id)&&exactInt(p.amount,1,MAX_AWARD)&&exactInt(p.before,0,MAX_BALANCE)&&exactInt(p.target,0,MAX_BALANCE)&&p.target===p.before+p.amount&&exactInt(p.at,1,Number.MAX_SAFE_INTEGER));}
  function rejectPending(){try{localStorage.removeItem(AWARD_PENDING_KEY);return localStorage.getItem(AWARD_PENDING_KEY)===null;}catch(e){return false;}}
  function recoverAward(){
    var p=readPending();if(!p)return true;if(!validPending(p)){rejectPending();saveError('检测到损坏的钻石奖励事务，已拒绝恢复且未改动余额',new Error('invalid gem pending'));return false;}var ledger=readAwards();
    var current=readGems();if(!ledger||current===null)return false;
    if(Object.prototype.hasOwnProperty.call(ledger,p.id)){
      if(Number(ledger[p.id].amount)!==Number(p.amount))return false;
      try{localStorage.removeItem(AWARD_PENDING_KEY);return localStorage.getItem(AWARD_PENDING_KEY)===null;}catch(e){return false;}
    }
    var old=null;try{old=localStorage.getItem(GEM_WALLET_KEY);}catch(e){}
    try{
      if(current!==Number(p.before)&&current!==Number(p.target))throw new Error('钻石奖励现场与 before/target 均不一致');
      if(current===Number(p.before)&&!setGems(p.target))throw new Error('钻石奖励恢复失败');
      ledger[p.id]={amount:p.amount,at:p.at};if(!writeAwards(ledger))throw new Error('钻石奖励账本恢复失败');
      localStorage.removeItem(AWARD_PENDING_KEY);return localStorage.getItem(AWARD_PENDING_KEY)===null;
    }catch(e){rawRestore(GEM_WALLET_KEY,old);saveError('钻石奖励事务未完成，稍后会自动重试',e);return false;}
  }
  function award(id,n){
    id=String(id||'');n=Number(n);if(!walletReady()||!validId(id)||!isFinite(n)||(n=Math.floor(n))<=0||n>MAX_AWARD||!recoverAward())return false;
    var ledger=readAwards();if(!ledger)return false;if(Object.prototype.hasOwnProperty.call(ledger,id))return true;
    var before=readGems();if(before===null||before>MAX_BALANCE-n)return false;var p={id:id,amount:n,before:before,target:before+n,at:Date.now()};
    var committed=false;
    try{var raw=JSON.stringify(p);localStorage.setItem(AWARD_PENDING_KEY,raw);if(localStorage.getItem(AWARD_PENDING_KEY)!==raw)throw new Error('钻石奖励准备失败');
      if(!setGems(p.target))throw new Error('钻石奖励入账失败');
      ledger[id]={amount:n,at:p.at};if(!writeAwards(ledger))throw new Error('钻石奖励账本写入失败');
      committed=true;try{localStorage.removeItem(AWARD_PENDING_KEY);}catch(_cleanup){}reconcileGemAchievement();return true;
    }catch(e){
      if(committed)return true;
      var rolled=setGems(before);if(rolled)try{localStorage.removeItem(AWARD_PENDING_KEY);}catch(_e){}
      saveError('钻石奖励未能安全入账，稍后重试不会重复发放',e);return false;
    }
  }
  function seedAwards(ids){
    if(!recoverAward())return false;var ledger=readAwards(),changed=false;
    if(!ledger)return false;
    (ids||[]).forEach(function(id){id=String(id||'');if(validId(id)&&!Object.prototype.hasOwnProperty.call(ledger,id)){ledger[id]={amount:0,at:Date.now(),migrated:true};changed=true;}});
    return !changed||writeAwards(ledger);
  }

  function awardStates(requests){
    var out=Object.create(null),ledger=readAwards(),pending=readPending();
    var pendingValid=!!(pending&&validPending(pending));
    var pendingBroken=!!(pending&&!pendingValid);
    (Array.isArray(requests)?requests:[]).forEach(function(req){
      var id='',expected=null;
      if(typeof req==='string')id=req;
      else if(req&&typeof req==='object'&&!Array.isArray(req)){
        id=String(req.id||'');
        if(Object.prototype.hasOwnProperty.call(req,'amount'))expected=Number(req.amount);
      }
      if(!validId(id)){out[id]={state:'invalid',amount:null,at:null};return;}
      if(!ledger){out[id]={state:'blocked',amount:null,at:null};return;}
      var rec=Object.prototype.hasOwnProperty.call(ledger,id)?ledger[id]:null;
      if(rec){
        if(rec.migrated===true&&Number(rec.amount)===0){
          out[id]={state:'legacy',amount:0,at:Number(rec.at)||null};
        }else if(expected!==null&&(!isFinite(expected)||Math.floor(expected)!==expected||Number(rec.amount)!==expected)){
          out[id]={state:'mismatch',amount:Number(rec.amount),at:Number(rec.at)||null};
        }else{
          out[id]={state:'paid',amount:Number(rec.amount),at:Number(rec.at)||null};
        }
        return;
      }
      if(pendingValid&&pending.id===id){
        out[id]={state:(expected!==null&&Number(pending.amount)!==expected)?'mismatch':'pending',amount:Number(pending.amount),at:Number(pending.at)||null};
      }else if(pendingBroken){
        out[id]={state:'blocked',amount:null,at:null};
      }else{
        out[id]={state:'unpaid',amount:null,at:null};
      }
    });
    return out;
  }
  function awardState(id,amount){
    var key=String(id||''),map=awardStates([{id:key,amount:amount}]);
    return map[key]||{state:'invalid',amount:null,at:null};
  }

  function reconcileGemAchievement(){
    if(!walletReady()||getGems()<1)return false;
    try{ if(typeof window.checkAch==='function'){window.checkAch();return true;} }catch(e){}
    try{ if(window.HansenAch&&HansenAch.unlock){HansenAch.unlock('gem1');return true;} }catch(e){}
    return false;
  }

  window.HansenGems = {
    get: getGems,
    add: function(n){n=Number(n);if(!walletReady()||!isFinite(n)||n<=0)return getGems();if(!recoverAward())return getGems();var before=readGems();if(before===null)return getGems();var w=before+Math.floor(n);if(w>MAX_BALANCE||!setGems(w)){saveError('钻石未能保存，本次奖励未入账',new Error('gem wallet write failed'));return before;}reconcileGemAchievement();return w;},
    spend: function(n){n=Number(n);if(!walletReady()||!isFinite(n)||n<0||!recoverAward())return false;var w=readGems();if(w===null||w<n)return false;var old=null;try{old=localStorage.getItem(GEM_WALLET_KEY);}catch(e){return false;}var ok=setGems(w-n);if(!ok){rawRestore(GEM_WALLET_KEY,old);saveError('钻石扣款未保存，交易已取消',new Error('gem spend write failed'));}return ok;},
    award:award,
    seedAwards:seedAwards,
    awardState:awardState,
    awardStates:awardStates,
    recoverAwards:recoverAward,
    isReady:walletReady,
    reconcileAchievement: reconcileGemAchievement
  };
  recoverAward();

  function clearOldGemsOnce(){
    try {
      if(localStorage.getItem(CLEAR_FLAG_KEY) === '1') return;
    } catch(e){ return; }

    var clearedCount = 0,writes=[],oldWallet=null,oldFlag=null;
    try {
      oldWallet=localStorage.getItem(GEM_WALLET_KEY);oldFlag=localStorage.getItem(CLEAR_FLAG_KEY);
      for(var i = 0; i < localStorage.length; i++){
        var key = localStorage.key(i);
        if(!key) continue;

        if(/^wordIsland/.test(key)){
          try {
            var raw = localStorage.getItem(key);
            if(!raw) continue;
            var obj = JSON.parse(raw);
            if(obj && typeof obj === 'object' && typeof obj.gems !== 'undefined'){
              obj.gems = 0;
              writes.push([key,raw,JSON.stringify(obj)]);
              clearedCount++;
            }
          } catch(e){   }
        }
      }
      writes.forEach(function(x){localStorage.setItem(x[0],x[2]);if(localStorage.getItem(x[0])!==x[2])throw new Error('旧钻石清零校验失败');});
      if(!setGems(0))throw new Error('全局钻石钱包初始化失败');
      localStorage.setItem(CLEAR_FLAG_KEY,'1');if(localStorage.getItem(CLEAR_FLAG_KEY)!=='1')throw new Error('钻石迁移标记写入失败');
    } catch(e){
      writes.forEach(function(x){try{localStorage.setItem(x[0],x[1]);}catch(_e){}});rawRestore(GEM_WALLET_KEY,oldWallet);rawRestore(CLEAR_FLAG_KEY,oldFlag);
      saveError('旧钻石迁移未完成，已保留原数据并将在下次重试',e);
    }

  }

  clearOldGemsOnce();
  reconcileGemAchievement();

  function injectGemBadge(){
    try {

      var coinBadge = document.querySelector('.top-bar .stat-badge.coin');
      if(!coinBadge || !coinBadge.parentElement) return false;
      if(document.getElementById('__hs_gem_badge')) return true;

      var gemBadge = document.createElement('div');
      gemBadge.className = 'stat-badge gem';
      gemBadge.id = '__hs_gem_badge';
      gemBadge.style.cssText = 'color:#22d3ee;border:1px solid rgba(34,211,238,.4);display:flex;align-items:center;gap:3px';
      gemBadge.innerHTML = '💎<span id="__hs_gem_count">' + getGems() + '</span>';

      coinBadge.parentElement.insertBefore(gemBadge, coinBadge);
      return true;
    } catch(e){ return false; }
  }

  function refreshGemBadge(){
    try {
      var el = document.getElementById('__hs_gem_count');
      if(el) el.textContent = getGems();
    } catch(e){}
  }

  var _origAdd = window.HansenGems.add;
  window.HansenGems.add = function(n){ var r = _origAdd(n); refreshGemBadge(); return r; };
  var _origSpend = window.HansenGems.spend;
  window.HansenGems.spend = function(n){ var r = _origSpend(n); refreshGemBadge(); return r; };
  var _origAward=window.HansenGems.award;
  window.HansenGems.award=function(id,n){var r=_origAward(id,n);refreshGemBadge();return r;};

  var gemTries = 0;
  var gemTimer = setInterval(function(){
    gemTries++;
    var ok = injectGemBadge();
    if(ok){   }
    if(ok || gemTries >= 100){ clearInterval(gemTimer); }
  }, 100);

})();
