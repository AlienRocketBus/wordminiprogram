
(function(){
  try {
    if(localStorage.getItem('hansen_autoOpenReviewCenter') !== '1' &&
       localStorage.getItem('hansen_autoOpenRain') !== '1') return;

    localStorage.removeItem('hansen_autoOpenReviewCenter');
    localStorage.removeItem('hansen_autoOpenRain');

    const style = document.createElement('style');
    style.textContent = `
      #hwo_transition_mask{
        position:fixed;inset:0;z-index:99999;
        background:linear-gradient(180deg,#0f172a 0%,#1e1b4b 60%,#312e81 100%);
        display:flex;align-items:center;justify-content:center;
        color:#fbbf24;font-size:14px;font-weight:600;letter-spacing:1px;
      }
      /* 隐藏 body 内所有内容直到遮罩消失 */
      body.hansen-transitioning > *:not(#hwo_transition_mask):not(script):not(style){
        visibility:hidden !important;
      }
    `;

    function insertMask(){

      const mask = document.createElement('div');
      mask.id = 'hwo_transition_mask';
      mask.innerHTML = '<div style="text-align:center"><div style="font-size:36px;margin-bottom:10px">🎯</div><div>正在打开复习中心...</div></div>';

      if(document.head){
        document.head.appendChild(style);
      } else {
        document.documentElement.insertBefore(style, document.documentElement.firstChild);
      }

      if(document.body){
        document.body.classList.add('hansen-transitioning');
        document.body.appendChild(mask);
      } else {

        document.documentElement.appendChild(mask);
        document.addEventListener('DOMContentLoaded', () => {
          document.body.classList.add('hansen-transitioning');
          if(mask.parentNode !== document.body){
            document.body.appendChild(mask);
          }
        });
      }
    }
    insertMask();

    window._hansenAutoOpening = true;
  } catch(e){}
})();
