
(function(){
  if(window.__hansenAchWalletLoaded){ return; } window.__hansenAchWalletLoaded = true;

  var ACH_KEY        = 'hansen_wallet_ach';
  var MIGRATE_FLAG   = 'hansen_ach_migrated_v1';
  var RESET_AT_KEY   = 'hansen_ach_reset_at_v942';

  function _read(){
    try{
      var raw = localStorage.getItem(ACH_KEY);
      window.__hansenAchReadFailed=false;
      if(!raw) return {claimed:[],pending:[],newones:[]};
      var o = JSON.parse(raw);
      var out={
        claimed: Array.isArray(o.claimed)?o.claimed:[],
        pending: Array.isArray(o.pending)?o.pending:[],
        newones: Array.isArray(o.newones)?o.newones:[]
      };
      out.claimed=out.claimed.filter(function(x,i,a){return typeof x==='string'&&a.indexOf(x)===i;});
      out.pending=out.pending.filter(function(x,i,a){return typeof x==='string'&&out.claimed.indexOf(x)<0&&a.indexOf(x)===i;});
      out.newones=out.newones.filter(function(x,i,a){return typeof x==='string'&&out.claimed.indexOf(x)<0&&out.pending.indexOf(x)>=0&&a.indexOf(x)===i;});
      return out;
    }catch(e){window.__hansenAchReadFailed=true;return null;}
  }
  function _write(o){
    if(!o||window.__hansenAchReadFailed)return false;
    try{var raw=JSON.stringify({claimed:o.claimed||[],pending:o.pending||[],newones:o.newones||[]});localStorage.setItem(ACH_KEY,raw);return localStorage.getItem(ACH_KEY)===raw;}catch(e){return false;}
  }
  function _uniqPush(arr, id){ if(arr.indexOf(id)<0) arr.push(id); }
  function _remove(arr, id){ var i=arr.indexOf(id); if(i>=0) arr.splice(i,1); }

  window.HansenAch = {

    isClaimed: function(id){var o=_read();return !!(o&&o.claimed.indexOf(id)>=0);},
    isPending: function(id){var o=_read();return !!(o&&o.pending.indexOf(id)>=0);},
    isNew:     function(id){var o=_read();return !!(o&&o.newones.indexOf(id)>=0);},
    getClaimed:function(){var o=_read();return o?o.claimed:[];},
    getPending:function(){var o=_read();return o?o.pending:[];},
    getNew:    function(){var o=_read();return o?o.newones:[];},
    claimedCount: function(){var o=_read();return o?o.claimed.length:0;},
    pendingCount: function(){var o=_read();return o?o.pending.length:0;},

    unlock: function(id){
      var o=_read();
      if(!o)return false;
      if(o.claimed.indexOf(id)>=0) return false;
      if(o.pending.indexOf(id)>=0) return false;
      _uniqPush(o.pending, id);
      _uniqPush(o.newones, id);
      return _write(o);
    },

    claim: function(id){
      var o=_read();
      if(!o)return false;
      if(o.pending.indexOf(id)<0) return false;
      _remove(o.pending, id);
      _uniqPush(o.claimed, id);
      _remove(o.newones, id);
      return _write(o);
    },

    seen: function(id){var o=_read();if(!o)return false;_remove(o.newones,id);return _write(o);},

    reset: function(){
      var ts=Date.now(),entries=[],oldWallet=null,oldReset=null;
      try{
        oldWallet=localStorage.getItem(ACH_KEY);oldReset=localStorage.getItem(RESET_AT_KEY);
        var keys=[];for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k&&/^wordIsland/.test(k)&&!/_tmp$/i.test(k))keys.push(k);}
        keys.forEach(function(k){
          try{var s=JSON.parse(localStorage.getItem(k)||'null');if(!s||typeof s!=='object')return;
            s.achievements=[];s.achPending=[];s.achNew=[];s.lastSaveTime=Math.max(Number(s.lastSaveTime)||0,ts);
            entries.push([k,localStorage.getItem(k),JSON.stringify(s)]);
          }catch(e){}
        });
        if(!_write({claimed:[],pending:[],newones:[]}))throw new Error('全局成就钱包写入失败');
        localStorage.setItem(RESET_AT_KEY,String(ts));if(localStorage.getItem(RESET_AT_KEY)!==String(ts))throw new Error('成就清除水位写入失败');
        entries.forEach(function(x){localStorage.setItem(x[0],x[2]);if(localStorage.getItem(x[0])!==x[2])throw new Error('岛屿成就清理写入失败');});
        return true;
      }catch(e){
        entries.forEach(function(x){try{localStorage.setItem(x[0],x[1]);}catch(_e){}});
        try{if(oldWallet===null)localStorage.removeItem(ACH_KEY);else localStorage.setItem(ACH_KEY,oldWallet);}catch(_e){}
        try{if(oldReset===null)localStorage.removeItem(RESET_AT_KEY);else localStorage.setItem(RESET_AT_KEY,oldReset);}catch(_e){}
        return false;
      }
    }
  };

  function migrateOnce(){
    var o=_read();
    if(!o)return false;
    var resetAt=0;try{resetAt=Math.max(0,Number(localStorage.getItem(RESET_AT_KEY))||0);}catch(e){}
    try{
      for(var i=0;i<localStorage.length;i++){
        var key=localStorage.key(i);
        if(!key) continue;
        if(/^wordIsland/.test(key) && !/_tmp$|_backup$/i.test(key)){
          try{
            var s=JSON.parse(localStorage.getItem(key));
            if(s && typeof s==='object'){
              if(resetAt&&(Number(s.lastSaveTime)||0)<=resetAt)continue;
              if(Array.isArray(s.achievements)) s.achievements.forEach(function(id){ _uniqPush(o.claimed, id); });
              if(Array.isArray(s.achPending)) s.achPending.forEach(function(id){ if(o.claimed.indexOf(id)<0) _uniqPush(o.pending, id); });
              if(Array.isArray(s.achNew)) s.achNew.forEach(function(id){ if(o.claimed.indexOf(id)<0) _uniqPush(o.newones, id); });
            }
          }catch(e){}
        }
      }
    }catch(e){}
    if(_write(o)){try{ localStorage.setItem(MIGRATE_FLAG,'1'); }catch(e){}}
  }
  migrateOnce();
})();
