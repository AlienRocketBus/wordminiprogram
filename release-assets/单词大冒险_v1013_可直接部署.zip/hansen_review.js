
(function(){
  'use strict';
  if(window.HansenReview) return;

  var _hrBadgeTimers = [];
  try { window.addEventListener('pagehide', function(){ try{ _hrBadgeTimers.forEach(function(id){ clearInterval(id); }); _hrBadgeTimers=[]; }catch(e){} }); } catch(e){}

  function _beep(){
    try {
      if(typeof window.playBeep === 'function') window.playBeep(1200, 0.05);
    } catch(e){}
  }

  function esc(s){
    if(s == null) return '';
    return String(s).replace(/[&<>"']/g, function(m){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
    });
  }

  const MAX_WRONG_COUNT = 1000000;
  const MAX_SMART_WEIGHT = 20;
  const MAX_VOCAB_WORDS = 2000;
  function safeWrongCount(value){
    return typeof value === 'number' && Number.isInteger(value) &&
      value >= 1 && value <= MAX_WRONG_COUNT ? value : 0;
  }
  function safeWrongWeight(value){
    const count = safeWrongCount(value);
    return count ? Math.min(MAX_SMART_WEIGHT, count * 2) : 0;
  }
  function safeText(value, maxLength){
    if(typeof value !== 'string') return '';
    return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').slice(0, maxLength);
  }
  function safeEmoji(value){
    if(typeof value !== 'string' || !value || value.length > 32 || /[<>&]/.test(value)) return '📘';
    return safeText(value, 32) || '📘';
  }
  function normalizeWord(value){
    if(!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const en = safeText(value.en, 96).trim();
    if(!en) return null;
    return {
      en,
      cn: safeText(value.cn, 192),
      pn: safeText(value.pn, 128),
      ex: safeText(value.ex, 512),
      exCn: safeText(value.exCn, 512),
      emoji: safeEmoji(value.emoji),
    };
  }
  function canonicalWrongIndex(key, vocabLength){
    if(typeof key !== 'string' || !/^(?:0|[1-9]\d*)$/.test(key)) return -1;
    const index = Number(key);
    return Number.isSafeInteger(index) && index >= 0 && index < vocabLength ? index : -1;
  }
  function normalizeVocab(value, preserveIndexes){
    if(!Array.isArray(value)) return [];
    const length = Math.min(value.length, MAX_VOCAB_WORDS);
    const result = [];
    for(let index = 0; index < length; index++){
      const word = normalizeWord(value[index]);
      if(preserveIndexes) result[index] = word;
      else if(word) result.push(word);
    }
    return result;
  }
  function normalizeStoredWrongs(wrongs, rawVocab){
    const vocab = normalizeVocab(rawVocab, true);
    if(!wrongs || typeof wrongs !== 'object' || Array.isArray(wrongs)) return [];
    const result = [];
    for(let index = 0; index < vocab.length; index++){
      const key = String(index);
      if(!Object.prototype.hasOwnProperty.call(wrongs, key)) continue;
      const count = safeWrongCount(wrongs[key]);
      if(!count || !vocab[index]) continue;
      result.push({idx:index, count, weight:safeWrongWeight(count), word:vocab[index]});
    }
    return result;
  }
  function normalizeContextIndex(value, vocabLength){
    if(typeof value === 'string') return canonicalWrongIndex(value, vocabLength);
    return Number.isSafeInteger(value) && value >= 0 && value < vocabLength ? value : -1;
  }
  function safeColor(value){
    return typeof value === 'string' && /^#[0-9a-f]{3,8}$/i.test(value) ? value : '#fbbf24';
  }

  function showToast(text, color){
    color = safeColor(color);
    const old = document.getElementById('hr_toast');
    if(old) old.remove();
    const t = document.createElement('div');
    t.id = 'hr_toast';
    t.style.cssText = 'position:fixed;inset:0;z-index:999999;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:30px;cursor:pointer';
    t.innerHTML = '<div style="background:linear-gradient(135deg,#1e293b,#0f172a);border:2px solid ' + color + ';border-radius:18px;padding:30px 36px;text-align:center;color:#fff;font-size:18px;line-height:1.6;max-width:300px"><div style="font-size:48px;margin-bottom:10px">💡</div><div style="color:' + color + ';font-weight:800">' + esc(safeText(text, 240)) + '</div></div>';
    t.onclick = () => t.remove();
    document.body.appendChild(t);
    setTimeout(() => { if(t.parentNode) t.remove(); }, 2500);
  }

  function safeJSON(k){ try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } }
  function getCurrentIsland(){

    const m = location.pathname.match(/island_([a-z0-9]+)\.html/i);
    return m ? m[1] : null;
  }
  const islandKey = getCurrentIsland();
  if(!islandKey) return;

  function getWrongCount(){
    let total = 0;
    Object.keys(localStorage).forEach(k => {
      if(k.startsWith('wordIsland')){
        const d = safeJSON(k);
        total += normalizeStoredWrongs(d && d.wrongs, safeJSON('hansen_vocab_' + k)).length;
      }
    });
    return total;
  }

  function getCurrentIslandWrongs(){

    if(!window.STORAGE_KEY) return [];
    const data = safeJSON(window.STORAGE_KEY);
    if(!data || !data.wrongs) return [];
    return normalizeStoredWrongs(data.wrongs, window.allW);
  }

  function getContextWrongs(){
    const context = window._huReviewContext;
    if(context && Array.isArray(context.wrongsList)){
      const rawVocab = Array.isArray(context.vocabList) ? context.vocabList.slice(0, MAX_VOCAB_WORDS) : [];
      const result = [];
      context.wrongsList.slice(0, MAX_VOCAB_WORDS).forEach(entry => {
        if(!entry || typeof entry !== 'object' || Array.isArray(entry)) return;
        const index = normalizeContextIndex(entry.idx, rawVocab.length);
        const count = safeWrongCount(entry.count);
        const word = normalizeWord(entry.word) || (index >= 0 ? normalizeWord(rawVocab[index]) : null);
        if(index < 0 || !count || !word) return;
        result.push({idx:index, count, weight:safeWrongWeight(count), word});
      });
      return result;
    }
    return getCurrentIslandWrongs();
  }

  function getContextVocab(){
    if(window._huReviewContext && Array.isArray(window._huReviewContext.vocabList)){
      return normalizeVocab(window._huReviewContext.vocabList, false);
    }
    return normalizeVocab(window.allW, false);
  }

  function getContextTitle(){
    if(window._huReviewContext && window._huReviewContext.title){
      return safeText(window._huReviewContext.title, 80);
    }
    return null;
  }

  function sanitizeReviewContext(){
    const context = window._huReviewContext;
    if(!context || typeof context !== 'object' || Array.isArray(context)) return;
    const rawVocab = Array.isArray(context.vocabList) ? context.vocabList.slice(0, MAX_VOCAB_WORDS) : [];
    const vocabList = [], indexMap = new Map();
    rawVocab.forEach((value, oldIndex) => {
      const word = normalizeWord(value);
      if(!word) return;
      indexMap.set(oldIndex, vocabList.length);
      vocabList.push(word);
    });
    const wrongsList = [];
    if(Array.isArray(context.wrongsList)){
      context.wrongsList.slice(0, MAX_VOCAB_WORDS).forEach(entry => {
        if(!entry || typeof entry !== 'object' || Array.isArray(entry)) return;
        const oldIndex = normalizeContextIndex(entry.idx, rawVocab.length);
        const index = indexMap.get(oldIndex);
        const count = safeWrongCount(entry.count);
        const word = normalizeWord(entry.word) || (index !== undefined ? vocabList[index] : null);
        if(index === undefined || !count || !word) return;
        wrongsList.push({idx:index, count, weight:safeWrongWeight(count), word});
      });
    }
    window._huReviewContext = {
      title: safeText(context.title, 80),
      vocabList,
      wrongsList,
    };
  }

  function installSmartPoolGuard(){
    if(typeof window.getSmartPool !== 'function') return;
    window.getSmartPool = function(){
      const vocab = Array.isArray(window.allW) ? window.allW.slice(0, MAX_VOCAB_WORDS) : [];
      const wrongs = window.S && window.S.wrongs;
      const wrongPool = [];
      normalizeStoredWrongs(wrongs, vocab).forEach(entry => {
        for(let slot = 0; slot < entry.weight; slot++) wrongPool.push(entry.idx);
      });
      const normalPool = [];
      for(let index = 0; index < vocab.length; index++) if(normalizeWord(vocab[index])) normalPool.push(index);
      return wrongPool.concat(normalPool);
    };
  }
  installSmartPoolGuard();

  var SRS_GAP = [1, 2, 4, 7, 15];
  var SRS_GRAD = SRS_GAP.length;

  function _ymd(d){
    return d.getFullYear() + '-' +
           String(d.getMonth() + 1).padStart(2, '0') + '-' +
           String(d.getDate()).padStart(2, '0');
  }
  function _todayYMD(){ return _ymd(new Date()); }
  function _addDaysYMD(n){ var d = new Date(); d.setDate(d.getDate() + n); return _ymd(d); }

  function _ensureSrs(){
    if(!window.S) return null;

    try{if(window.HansenCanonical&&typeof HansenCanonical.syncCurrent==='function')HansenCanonical.syncCurrent();}catch(e){}
    if(!window.S.srs || typeof window.S.srs !== 'object') window.S.srs = {};
    var srs = window.S.srs, wr = window.S.wrongs || {}, changed = false, t = _todayYMD();
    Object.keys(srs).forEach(function(idx){
      var i=canonicalWrongIndex(idx,Array.isArray(window.allW)?window.allW.length:0);
      if(i<0||safeWrongCount(wr[i])===0){delete srs[idx];changed=true;}
    });
    normalizeStoredWrongs(wr, window.allW).forEach(function(entry){
      var idx = String(entry.idx);
      if(!srs[idx]){
        srs[idx] = { box: 0, due: t, last: '' };
        changed = true;
      }
    });
    if(changed && typeof save === 'function'){ try { save(); } catch(e){} }
    return srs;
  }

  function _dueList(){
    var srs = _ensureSrs();
    if(!srs) return [];
    var t = _todayYMD(), vocab = normalizeVocab(window.allW, true), wr = (window.S && window.S.wrongs) || {}, out = [];
    Object.keys(srs).forEach(function(idx){
      var i = canonicalWrongIndex(idx, vocab.length), e = srs[idx];
      var box = e && typeof e.box === 'number' && Number.isInteger(e.box) ? e.box : -1;
      var due = e && typeof e.due === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(e.due) ? e.due : '';
      var wrong=safeWrongCount(wr[i]);
      if(i >= 0 && wrong>0 && box >= 0 && box < SRS_GRAD && due && due <= t && vocab[i]){
        out.push({ idx: i, word: vocab[i], box: box, wrong: wrong });
      }
    });
    out.sort(function(a, b){ return (b.wrong - a.wrong) || (a.box - b.box); });
    return out;
  }

  function _grade(idx, ok){
    var srs = _ensureSrs();
    if(!srs) return false;
    var e = srs[idx] || { box: 0, due: _todayYMD(), last: '' };
    var graduated = false;
    if(ok){
      var nb = (e.box || 0) + 1;
      if(nb >= SRS_GRAD){

        if(!e.rp){
          srs[idx] = e;
          try{
            var _w = (Array.isArray(window.allW) && window.allW[canonicalWrongIndex(idx, window.allW.length)]) || null;
            var _en = _w && _w.en ? String(_w.en) : '这个词';
            if(typeof window.showToast === 'function') showToast('🎓 最后一关：去任意玩法里答对「'+_en+'」一次，即可正式毕业');
          }catch(_gateToast){}
          try{ if(window.HansenCanonical && typeof HansenCanonical.setCurrentSrs === 'function') HansenCanonical.setCurrentSrs(idx, e); }catch(_gateSync){}
          if(typeof save === 'function'){ try{ save(); }catch(_gateSave){} }
          return false;
        }
        delete srs[idx];
        if(window.S.wrongs) delete window.S.wrongs[idx];
        graduated = true;

        try{ if(window.HansenReviewRewardsV963 && typeof HansenReviewRewardsV963.onGraduated === 'function') HansenReviewRewardsV963.onGraduated(idx); }catch(_gradEvt){}
      } else {
        e.box = nb; e.due = _addDaysYMD(SRS_GAP[nb]); e.last = _todayYMD();
        srs[idx] = e;
      }
    } else {
      e.box = 0; e.due = _addDaysYMD(SRS_GAP[0]); e.last = _todayYMD();
      srs[idx] = e;
    }
    try{
      if(window.HansenCanonical){
        if(graduated&&typeof HansenCanonical.absorbAnswer==='function')HansenCanonical.absorbAnswer(idx);
        if(typeof HansenCanonical.setCurrentSrs==='function')HansenCanonical.setCurrentSrs(idx,graduated?null:e);
      }
    }catch(_canonicalError){}
    if(typeof save === 'function'){ try { save(); } catch(e){} }
    return graduated;
  }

  function _absorbRealAnswer(idx, correct){
    try{
      if(correct !== true) return null;
      if(!window.S || !Array.isArray(window.allW)) return null;
      var i = canonicalWrongIndex(idx, window.allW.length);
      if(i < 0) return null;
      var srs = _ensureSrs();
      if(!srs) return null;
      var key = String(i), t = _todayYMD();
      var wrong = safeWrongCount(window.S.wrongs ? window.S.wrongs[i] : 0);
      var e = srs[key];
      if(!e || typeof e !== 'object'){
        if(wrong <= 0) return null;
        e = { box: 0, due: t, last: '' };
      }

      if(wrong <= 0){
        delete srs[key];
        try{ if(window.HansenCanonical && typeof HansenCanonical.setCurrentSrs === 'function') HansenCanonical.setCurrentSrs(i, null); }catch(_zz){}
        if(typeof save === 'function'){ try{ save(); }catch(_zz2){} }
        return null;
      }
      var box = (typeof e.box === 'number' && e.box >= 0) ? e.box : 0;
      if(box >= SRS_GRAD) return null;
      if(e.last === t) return { advanced:false, reason:'daily-lock' };
      var due = (typeof e.due === 'string') ? e.due : t;
      if(due > t){
        if(box >= SRS_GRAD - 1 && !e.rp){
          e.rp = 1; srs[key] = e;
          try{ if(window.HansenCanonical && typeof HansenCanonical.setCurrentSrs === 'function') HansenCanonical.setCurrentSrs(i, e); }catch(_c){}
          if(typeof save === 'function'){ try{ save(); }catch(_s){} }
          return { advanced:false, reason:'not-due', proof:true };
        }
        return { advanced:false, reason:'not-due' };
      }
      var nb = box + 1;
      if(nb >= SRS_GRAD){
        delete srs[key];
        if(wrong > 0 && window.S.wrongs) delete window.S.wrongs[i];
        try{
          if(window.HansenCanonical){
            if(typeof HansenCanonical.absorbAnswer === 'function') HansenCanonical.absorbAnswer(i);
            if(typeof HansenCanonical.setCurrentSrs === 'function') HansenCanonical.setCurrentSrs(i, null);
          }
        }catch(_c2){}
        if(typeof save === 'function'){ try{ save(); }catch(_s2){} }
        return { advanced:true, graduated:true, box:SRS_GRAD, hadWrong: wrong > 0 };
      }
      e.box = nb; e.due = _addDaysYMD(SRS_GAP[nb]); e.last = t;
      srs[key] = e;
      try{ if(window.HansenCanonical && typeof HansenCanonical.setCurrentSrs === 'function') HansenCanonical.setCurrentSrs(i, e); }catch(_c3){}
      if(typeof save === 'function'){ try{ save(); }catch(_s3){} }
      return { advanced:true, graduated:false, box:nb, gapDays:SRS_GAP[nb] };
    }catch(_absorbError){ return null; }
  }

  function _todayBackToCenter(){
    window._huFromReview = false;

    var center = document.getElementById('hr_center');
    if(!center){ openReviewCenter(); center = document.getElementById('hr_center'); }
    if(center) center.style.zIndex = '99998';
    var el = document.getElementById('hr_today'); if(el) el.remove();
    requestAnimationFrame(function(){ var c = document.getElementById('hr_center'); if(c) c.style.zIndex = ''; });
  }

  function openTodayReview(){
    var due = _dueList();
    var overlay = document.createElement('div');
    overlay.id = 'hr_today';

    if(due.length === 0){
      overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;background:linear-gradient(180deg,#064e3b 0%,#0f172a 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;padding:30px;text-align:center';
      overlay.innerHTML =
        '<div style="font-size:72px;margin-bottom:16px">🎉</div>' +
        '<div style="font-size:23px;font-weight:900;color:#fbbf24;margin-bottom:10px">今天没有要复习的单词</div>' +
        '<div style="font-size:14px;color:#94a3b8;line-height:1.8;max-width:280px">大脑正在悄悄记牢它们 · 到期了会自动提醒你<br>先去学点新词, 或随便逛逛吧 💪</div>' +
        '<button id="hr_today_back" style="margin-top:28px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#000;border:0;padding:13px 32px;border-radius:14px;font-size:15px;font-weight:800;cursor:pointer">返回复习中心</button>';
      document.body.appendChild(overlay);
      document.getElementById('hr_today_back').onclick = _todayBackToCenter;

      try{ if(window.HansenReviewRewardsV963) HansenReviewRewardsV963.onTodayComplete({reviewed:0, graduated:0, total:0}); }catch(e){}
      return;
    }

    var i = 0, revealed = false, reviewed = 0, graduated = 0, total = due.length;
    var BOXNAME = ['新词', '第 2 阶', '第 3 阶', '第 4 阶', '冲刺阶'];

    overlay.innerHTML = [
      '<style>',
      '#hr_today{position:fixed;inset:0;z-index:9999;background:linear-gradient(180deg,#7c2d12 0%,#1f1b14 55%,#0f172a 100%);display:flex;flex-direction:column;padding:20px 16px}',
      '#hr_today .ht_top{display:flex;justify-content:space-between;align-items:center;color:#fff;margin-bottom:10px}',
      '#hr_today .ht_top button{background:rgba(255,255,255,.08);color:#cbd5e1;border:0;width:36px;height:36px;border-radius:10px;font-size:18px;cursor:pointer}',
      '#hr_today .ht_prog{font-size:14px;color:#fde68a;font-weight:800}',
      '#hr_today .ht_bar{height:6px;border-radius:6px;background:rgba(255,255,255,.12);overflow:hidden;margin-bottom:16px}',
      '#hr_today .ht_bar > i{display:block;height:100%;width:0;background:linear-gradient(90deg,#fbbf24,#f59e0b);transition:width .3s}',
      '#hr_today .ht_cardwrap{flex:1;display:flex;align-items:center;justify-content:center}',
      '#hr_today .ht_card{width:100%;max-width:340px;min-height:380px;background:linear-gradient(135deg,#b45309,#92400e);border-radius:24px;padding:28px;text-align:center;color:#fff;box-shadow:0 20px 60px rgba(0,0,0,.5);display:flex;flex-direction:column;justify-content:center;align-items:center;user-select:none;-webkit-user-select:none}',
      '#hr_today .ht_card.rev{background:linear-gradient(135deg,#047857,#065f46)}',
      '#hr_today .ht_emoji{font-size:72px;line-height:1;margin-bottom:14px}',
      '#hr_today .ht_en{font-size:44px;font-weight:900;letter-spacing:1px;margin-bottom:6px}',
      '#hr_today .ht_pn{font-size:16px;opacity:.75;margin-bottom:10px}',
      '#hr_today .ht_cn{font-size:34px;font-weight:900;color:#fde047;margin-bottom:12px}',
      '#hr_today .ht_ex{font-size:19px;line-height:1.6;font-weight:600;font-style:italic;opacity:.95;margin-bottom:8px;padding:0 4px}',
      '#hr_today .ht_excn{font-size:15px;opacity:.85;line-height:1.5;padding:0 4px}',
      '#hr_today .ht_box{margin-top:14px;font-size:11px;color:rgba(255,255,255,.6)}',
      '#hr_today .ht_hint{color:rgba(255,255,255,.55);font-size:12px;margin-top:16px}',
      '#hr_today .ht_btm{display:flex;gap:10px;margin-top:18px}',
      '#hr_today .ht_btm button{flex:1;border:0;padding:15px;border-radius:14px;font-size:15px;font-weight:800;cursor:pointer}',
      '#hr_today .ht_speak{background:linear-gradient(135deg,#10b981,#059669);color:#fff}',
      '#hr_today .ht_show{background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#000}',
      '#hr_today .ht_forgot{background:linear-gradient(135deg,#f87171,#dc2626);color:#fff}',
      '#hr_today .ht_got{background:linear-gradient(135deg,#34d399,#059669);color:#053}',
      '</style>',
      '<div class="ht_top">',
      '  <button id="ht_close">✕</button>',
      '  <div class="ht_prog" id="ht_prog"></div>',
      '  <div style="width:36px"></div>',
      '</div>',
      '<div class="ht_bar"><i id="ht_fill"></i></div>',
      '<div class="ht_cardwrap"><div class="ht_card" id="ht_card"></div></div>',
      '<div class="ht_btm" id="ht_btm"></div>'
    ].join('');
    document.body.appendChild(overlay);

    function render(){
      var it = due[i], w = it.word;
      var card = document.getElementById('ht_card'), btm = document.getElementById('ht_btm');
      document.getElementById('ht_prog').textContent = (i + 1) + ' / ' + total;
      document.getElementById('ht_fill').style.width = Math.round(i / total * 100) + '%';
      if(!revealed){
        card.className = 'ht_card';
        card.innerHTML =
          '<div class="ht_emoji">' + safeEmoji(w.emoji) + '</div>' +
          '<div class="ht_en">' + esc(w.en) + '</div>' +
          (w.pn ? '<div class="ht_pn">' + esc(w.pn) + '</div>' : '') +
          '<div class="ht_box">📦 ' + (BOXNAME[it.box] || '复习') + '</div>' +
          '<div class="ht_hint">先想想中文意思 👇</div>';
        btm.innerHTML =
          '<button class="ht_speak" id="ht_b_speak">🔊 听发音</button>' +
          '<button class="ht_show" id="ht_b_show">看答案 →</button>';
        document.getElementById('ht_b_speak').onclick = function(){ if(window.speak) try { window.speak(w.en); } catch(e){} };
        document.getElementById('ht_b_show').onclick = function(){
          revealed = true; render();
          if(window.speak) setTimeout(function(){ try { window.speak(w.en); } catch(e){} }, 150);
        };
      } else {
        card.className = 'ht_card rev';
        card.innerHTML =
          '<div class="ht_emoji">' + safeEmoji(w.emoji) + '</div>' +
          '<div class="ht_en" style="font-size:30px">' + esc(w.en) + '</div>' +
          '<div class="ht_cn">' + esc(w.cn) + '</div>' +
          (w.ex ? '<div class="ht_ex">"' + esc(w.ex) + '"</div>' : '') +
          (w.exCn ? '<div class="ht_excn">' + esc(w.exCn) + '</div>' : '');
        btm.innerHTML =
          '<button class="ht_forgot" id="ht_b_forgot">😅 没记住</button>' +
          '<button class="ht_got" id="ht_b_got">✅ 记住了</button>';
        document.getElementById('ht_b_forgot').onclick = function(){ grade(false); };
        document.getElementById('ht_b_got').onclick = function(){ grade(true); };
      }
    }

    function grade(ok){
      var it = due[i];
      if(_grade(it.idx, ok)) graduated++;
      reviewed++;
      i++;
      if(i >= total){ finish(); return; }
      revealed = false;
      render();
    }

    function finish(){

      try{ if(window.HansenReviewRewardsV963) HansenReviewRewardsV963.onTodayComplete({reviewed:reviewed, graduated:graduated, total:total}); }catch(e){}

      overlay.style.cssText = 'position:fixed;inset:0;z-index:9999;'
        + 'background:linear-gradient(180deg,#064e3b 0%,#0f172a 100%);'
        + 'display:flex;flex-direction:column;overflow-y:auto;-webkit-overflow-scrolling:touch';
      overlay.innerHTML =
        '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center;padding:30px">' +
          '<div style="font-size:72px;margin-bottom:14px">🎉</div>' +
          '<div style="font-size:24px;font-weight:900;color:#fbbf24;margin-bottom:12px">今日复习完成!</div>' +
          '<div style="font-size:15px;color:#cbd5e1;line-height:1.9">复习了 <b style="color:#fde047">' + reviewed + '</b> 个单词' +
            (graduated > 0 ? ('<br>其中 <b style="color:#34d399">' + graduated + '</b> 个已经记牢毕业 🎓') : '') +
          '</div>' +
          '<button id="hr_today_back2" style="margin-top:28px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#000;border:0;padding:13px 32px;border-radius:14px;font-size:15px;font-weight:800;cursor:pointer">返回复习中心</button>' +
        '</div>';
      var b = document.getElementById('hr_today_back2');
      if(b) b.onclick = _todayBackToCenter;
    }

    document.getElementById('ht_close').onclick = _todayBackToCenter;
    render();
  }

  function patchReviewBtn(){

    const utilCards = document.querySelectorAll('.util-card');
    let reviewCard = null;
    utilCards.forEach(card => {
      if(card.textContent.includes('复习')) reviewCard = card;
    });
    if(!reviewCard) return false;
    if(reviewCard.dataset.hrPatched) return true;
    reviewCard.dataset.hrPatched = '1';

    reviewCard.removeAttribute('onclick');
    reviewCard.style.position = 'relative';
    reviewCard.addEventListener('click', function(e){
      e.preventDefault();
      e.stopPropagation();
      openReviewCenter();
    });

    const badge = document.createElement('span');
    badge.className = 'hr_util_badge';
    badge.style.cssText = 'position:absolute;top:4px;right:4px;background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;font-size:10px;font-weight:800;padding:1px 5px;border-radius:8px;min-width:18px;text-align:center;box-shadow:0 1px 4px rgba(239,68,68,.5);border:1.5px solid #0f172a;line-height:1.3;display:none';
    reviewCard.appendChild(badge);

    function updateBadge(){
      const n = getCurrentIslandWrongs().length;
      badge.textContent = n > 99 ? '99+' : n;
      badge.style.display = n > 0 ? 'inline-block' : 'none';
    }
    updateBadge();
    _hrBadgeTimers.push(setInterval(updateBadge, 3000));

    return true;
  }

  function patchNavReviewBadge(){
    const nav = document.getElementById('navReview');
    if(!nav) return false;
    if(nav.dataset.hrBadge) return true;
    nav.dataset.hrBadge = '1';
    nav.style.position = 'relative';
    const badge = document.createElement('span');
    badge.className = 'hr_nav_badge';
    badge.style.cssText = 'position:absolute;top:2px;right:14px;background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;font-size:10px;font-weight:800;padding:1px 5px;border-radius:8px;min-width:16px;text-align:center;box-shadow:0 1px 4px rgba(239,68,68,.5);border:1.5px solid #0f172a;line-height:1.2;display:none';
    nav.appendChild(badge);
    function upd(){
      try {
        const n = getCurrentIslandWrongs().length;
        badge.textContent = n > 99 ? '99+' : n;
        badge.style.display = n > 0 ? 'inline-block' : 'none';
      } catch(e){}
    }
    upd();
    _hrBadgeTimers.push(setInterval(upd, 3000));
    return true;
  }

  function tryPatch(retries){
    var a = patchReviewBtn();
    var b = patchNavReviewBadge();
    if(a && b) return;
    if(retries > 0) setTimeout(() => tryPatch(retries - 1), 500);
  }
  if(document.body) tryPatch(10);
  else document.addEventListener('DOMContentLoaded', () => tryPatch(10));

  function openReviewCenter(){

    const old = document.getElementById('hr_center');
    if(old) old.remove();

    const wrongCount = getContextWrongs().length;
    const dueCount = window._huReviewContext ? 0 : _dueList().length;
    var _calNow = new Date();
    var _calMon = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'][_calNow.getMonth()];
    var _calDay = _calNow.getDate();
    const srsCard = window._huReviewContext ? '' : (
      '<div class="hr_section_title">\u23F0 \u95F4\u9694\u590D\u4E60 (\u6309\u8BB0\u5FC6\u66F2\u7EBF)</div>' +
      '<div class="hr_card" style="--c1:#b45309;--c2:#92400e" onclick="window.HansenReview._openToday()">' +

        '<span class="hr_cal"><span class="hr_cal_m">' + _calMon + '</span><span class="hr_cal_d">' + _calDay + '</span></span>' +
        '<span class="hr_badge ' + (dueCount > 0 ? 'hr_red_dot' : '') + '">' + (dueCount > 0 ? (dueCount + ' \u4E2A\u5230\u671F') : '\u5DF2\u6E05\u7A7A \uD83C\uDF89') + '</span>' +
        '<div class="hr_name">\u4ECA\u65E5\u590D\u4E60</div>' +
        '<div class="hr_desc">' + (dueCount > 0 ? ('\u4ECA\u5929\u6709 ' + dueCount + ' \u4E2A\u5355\u8BCD\u8BE5\u590D\u4E60\u4E86 \u00B7 \u8BB0\u7262\u4E00\u4E2A\u5C11\u4E00\u4E2A') : '\u4ECA\u5929\u7684\u590D\u4E60\u90FD\u5B8C\u6210\u5566 \u00B7 \u660E\u5929\u8BB0\u5FC6\u4F1A\u66F4\u7262\u56FA') + '</div>' +
      '</div>'
    );
    const allCount = getContextVocab().length;
    const learnedCount = (window.S?.learned || []).length;
    const customTitle = getContextTitle();

    const overlay = document.createElement('div');
    overlay.id = 'hr_center';
    overlay.innerHTML = `
      <style>
        @keyframes hr_slideUp{from{transform:translateY(100%);opacity:0}to{transform:translateY(0);opacity:1}}
        @keyframes hr_iconFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
        #hr_center{
          position:fixed;inset:0;z-index:9999;
          background:linear-gradient(180deg,#0f172a 0%,#1e1b4b 60%,#312e81 100%);
          overflow-y:auto;padding:20px 16px 100px;

        }
        #hr_center .hr_header{
          display:flex;align-items:center;gap:12px;margin-bottom:6px;padding-top:8px;
        }
        #hr_center .hr_back{
          background:rgba(255,255,255,.08);color:#cbd5e1;border:0;width:36px;height:36px;
          border-radius:10px;font-size:18px;cursor:pointer;flex-shrink:0;
        }
        #hr_center .hr_title{font-size:22px;font-weight:900;color:#fbbf24;letter-spacing:1px}
        #hr_center .hr_sub{color:#94a3b8;font-size:12px;margin-left:48px;margin-bottom:18px;line-height:1.5}
        #hr_center .hr_stat_row{
          display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:18px;
        }
        #hr_center .hr_stat{
          background:rgba(30,41,59,.6);border:1px solid #334155;border-radius:12px;
          padding:10px 6px;text-align:center;
        }
        #hr_center .hr_stat .num{font-size:22px;font-weight:900;color:#fbbf24;line-height:1}
        #hr_center .hr_stat .lbl{font-size:11px;color:#94a3b8;margin-top:4px}
        #hr_center .hr_section_title{
          color:#cbd5e1;font-size:13px;font-weight:700;margin:18px 4px 10px;
          display:flex;align-items:center;gap:6px;
        }
        #hr_center .hr_card{
          background:linear-gradient(135deg,var(--c1,#1e293b),var(--c2,#0f172a));
          border-radius:16px;padding:18px;margin-bottom:12px;
          cursor:pointer;color:#fff;position:relative;
          box-shadow:0 6px 20px rgba(0,0,0,.4);
          transition:transform .15s;
          border:1px solid rgba(255,255,255,.08);
        }
        #hr_center .hr_card:active{transform:scale(.97)}
        #hr_center .hr_card .hr_icon{font-size:36px;display:inline-block;animation:hr_iconFloat 3s ease-in-out infinite}
        .hr_cal{display:inline-flex;flex-direction:column;width:40px;border-radius:7px;overflow:hidden;background:#fff;box-shadow:0 2px 7px rgba(0,0,0,.28);animation:hr_iconFloat 3s ease-in-out infinite;line-height:1;vertical-align:middle}
        .hr_cal_m{background:#e23b2e;color:#fff;font-size:12px;font-weight:800;text-align:center;padding:2px 0;letter-spacing:.5px}
        .hr_cal_d{color:#1c1c1e;font-size:22px;font-weight:800;text-align:center;padding:3px 0 4px}
        #hr_center .hr_card .hr_name{font-size:17px;font-weight:800;margin-top:4px;letter-spacing:.5px}
        #hr_center .hr_card .hr_desc{font-size:12px;color:rgba(255,255,255,.75);margin-top:4px;line-height:1.5}
        #hr_center .hr_card .hr_badge{
          position:absolute;top:14px;right:14px;
          background:rgba(0,0,0,.3);color:#fff;padding:4px 10px;border-radius:10px;
          font-size:11px;font-weight:700;
        }
        #hr_center .hr_card .hr_red_dot{
          background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;font-weight:800;
        }
        #hr_center .hr_btm_hint{
          text-align:center;color:#475569;font-size:11px;margin-top:24px;line-height:1.6;
        }
      </style>

      <div class="hr_header">
        <button class="hr_back" onclick="window.HansenReview._close()">←</button>
        <div class="hr_title">🎯 ${esc(customTitle || '复习中心')}</div>
      </div>
      <div class="hr_sub">温柔记住每一个不熟的单词</div>

      <div class="hr_stat_row">
        <div class="hr_stat"><div class="num">${learnedCount}</div><div class="lbl">已认识</div></div>
        <div class="hr_stat"><div class="num">${wrongCount}</div><div class="lbl">待复习</div></div>
        <div class="hr_stat"><div class="num">${allCount}</div><div class="lbl">本岛单词</div></div>
      </div>

      ${srsCard}
      <div id="hr_rewards_slot"></div><!-- 🔴v963样机: 复习奖励状态卡插槽(模块填充·非试点岛为空) -->
      <div class="hr_section_title">🌧️ 温柔复习 (零压力)</div>

      <div class="hr_card" style="--c1:#1e1b4b;--c2:#312e81" onclick="window.HansenReview._openSpellByCn()">
        <span class="hr_icon">✍️</span>
        <span class="hr_badge ${wrongCount > 0 ? 'hr_red_dot' : ''}">${wrongCount > 0 ? wrongCount + ' 个错题' : '推荐'}</span>
        <div class="hr_name">看汉意拼单词</div>
        <div class="hr_desc">看中文意思 · 可点喇叭听读音 · 拼写单词 · 60 秒倒计时</div>
      </div>

      <div class="hr_card" style="--c1:#365314;--c2:#3f6212" onclick="window.HansenReview._openFlashcard()">
        <span class="hr_icon">🃏</span>
        <span class="hr_badge">${wrongCount > 0 ? wrongCount + ' 张错题卡' : '推荐'}</span>
        <div class="hr_name">闪卡复习</div>
        <div class="hr_desc">一张一张看 · 自己翻自己看 · 不打分不催</div>
      </div>

      <div class="hr_card" style="--c1:#0c4a6e;--c2:#075985" onclick="window.HansenReview._openSpellByListen()">
        <span class="hr_icon">🎧</span>
        <span class="hr_badge">${wrongCount > 0 ? wrongCount + ' 个' : '推荐'}</span>
        <div class="hr_name">听音拼词</div>
        <div class="hr_desc">自动播放读音 · 听到后拼出单词 · 60 秒倒计时</div>
      </div>

      <div class="hr_section_title">📚 主动学习</div>

      <div class="hr_card" style="--c1:#6366f1;--c2:#4338ca" onclick="window.HansenReview._openExplore()">
        <span class="hr_icon">📚</span>
        <span class="hr_badge">${allCount} 个</span>
        <div class="hr_name">浏览全部</div>
        <div class="hr_desc">查看所有单词卡 · 点击查看认识、宠物掌握与知识结晶状态</div>
      </div>

      <div class="hr_card" style="--c1:#a16207;--c2:#854d0e" onclick="window.HansenReview._openWrongOnly()">
        <span class="hr_icon">📕</span>
        <span class="hr_badge ${wrongCount > 0 ? 'hr_red_dot' : ''}">${wrongCount} 个</span>
        <div class="hr_name">错题本</div>
        <div class="hr_desc">只看错过的单词 · 一个一个攻克</div>
      </div>

      <div class="hr_btm_hint">
        🌟 不要逼自己 · 看到熟悉的脸<br>
        就是在记住它了
      </div>
    `;

    document.body.appendChild(overlay);

    try{ if(window.HansenReviewRewardsV963) HansenReviewRewardsV963.fillCenterSlot(); }catch(e){}
  }

  window.HansenReview = {

    absorbRealAnswer: _absorbRealAnswer,
    _srsMeta: { GAP: SRS_GAP.slice(), GRAD: SRS_GRAD },
    _open: function(){
      _beep();
      sanitizeReviewContext();
      openReviewCenter();
    },

    _closeAndBack: function(overlayId){
      _beep();
      const el = document.getElementById(overlayId);
      if(window._huFromReview){
        window._huFromReview = false;

        var center = document.getElementById('hr_center');
        if(!center){ openReviewCenter(); center = document.getElementById('hr_center'); }
        if(center) center.style.zIndex = '99998';
        if(el) el.remove();
        requestAnimationFrame(function(){ var c = document.getElementById('hr_center'); if(c) c.style.zIndex = ''; });
      } else {
        if(el) el.remove();
      }
    },
    _close: function(){
      _beep();
      const c = document.getElementById('hr_center');
      if(c) c.remove();

      if(!window._huReviewKeepContext){
        window._huReviewContext = null;
      }
      window._huReviewKeepContext = false;
    },

    _openSpellByCn: function(){
      _beep();
      sanitizeReviewContext();
      window._huFromReview = true;
      window._huReviewKeepContext = true;

      var _c=document.getElementById('hr_center'); if(_c) _c.style.zIndex='';

      if(window.HansenSpellPractice) window.HansenSpellPractice.openSpellByCn();
    },

    _openSpellByListen: function(){
      _beep();
      sanitizeReviewContext();
      window._huFromReview = true;
      window._huReviewKeepContext = true;

      var _c=document.getElementById('hr_center'); if(_c) _c.style.zIndex='';

      if(window.HansenSpellPractice) window.HansenSpellPractice.openSpellByListen();
    },

    _backFromSpell: function(){
      window._huFromReview = false;
      window._huReviewKeepContext = true;

      var center = document.getElementById('hr_center');
      if(!center){ openReviewCenter(); center = document.getElementById('hr_center'); }
      if(center) center.style.zIndex = '99998';
      requestAnimationFrame(function(){ var c = document.getElementById('hr_center'); if(c) c.style.zIndex = ''; });
    },
    _openFlashcard: function(){
      _beep();
      sanitizeReviewContext();
      window._huFromReview = true;
      window._huReviewKeepContext = true;
      var _c=document.getElementById('hr_center'); if(_c) _c.style.zIndex='';

      openFlashcard();
    },

    _openExplore: function(){
      _beep();
      sanitizeReviewContext();
      window._huFromReview = true;
      window._huReviewKeepContext = true;
      var _c=document.getElementById('hr_center'); if(_c) _c.style.zIndex='';

      if(window._huReviewContext && window._huReviewContext.vocabList){
        openBrowseAll();
        return;
      }

      const mask = document.createElement('div');
      mask.id = 'hr_to_sub_mask';
      mask.style.cssText = 'position:fixed;inset:0;z-index:9998;background:linear-gradient(180deg,#0f172a 0%,#1e1b4b 60%,#312e81 100%)';
      document.body.appendChild(mask);
      this._close();
      if(typeof window.showScreen === 'function'){
        window.showScreen('explore');
      }
      setTimeout(() => {
        const m = document.getElementById('hr_to_sub_mask');
        if(m) m.remove();
      }, 300);
    },
    _openToday: function(){
      _beep();
      window._huFromReview = true;
      window._huReviewKeepContext = true;
      var _c=document.getElementById('hr_center'); if(_c) _c.style.zIndex='';

      openTodayReview();
    },
    _dueCount: function(){ try { return _dueList().length; } catch(e){ return 0; } },
    _openWrongOnly: function(){
      _beep();
      sanitizeReviewContext();
      window._huFromReview = true;
      window._huReviewKeepContext = true;
      var _c=document.getElementById('hr_center'); if(_c) _c.style.zIndex='';

      openWrongBook();
    },
    _security: {
      safeWrongCount,
      safeWrongWeight,
      safeEmoji,
      normalizeWord,
      normalizeStoredWrongs,
    },
  };

  function openFlashcard(directPool){
    const wrongs = getContextWrongs();
    let pool;
    if(Array.isArray(directPool)){
      pool = normalizeVocab(directPool, false);
    } else if(wrongs.length > 0){
      pool = wrongs.map(w => w.word);
    } else {

      pool = getContextVocab().slice(0, 20);
    }
    if(pool.length === 0){
      showToast('暂无单词');
      return;
    }

    let idx = 0;
    let flipped = false;

    const overlay = document.createElement('div');
    overlay.id = 'hr_flashcard';
    overlay.innerHTML = `
      <style>
        @keyframes hr_cardFadeIn{from{opacity:0}to{opacity:1}}
        @keyframes hr_cardFlip{0%{transform:rotateY(0)}100%{transform:rotateY(180deg)}}
        #hr_flashcard{
          position:fixed;inset:0;z-index:9999;
          background:linear-gradient(180deg,#1e1b4b 0%,#0f172a 100%);
          display:flex;flex-direction:column;
          /* 🔴v1008: 底部按 Home 横条留安全区, 顶部收紧让内容整体上移 */
          padding:calc(env(safe-area-inset-top,0px) + 12px) 16px calc(env(safe-area-inset-bottom,0px) + 16px);

        }
        #hr_flashcard .hr_fc_top{
          display:flex;justify-content:space-between;align-items:center;color:#fff;margin-bottom:10px;
        }
        #hr_flashcard .hr_fc_top button{
          background:rgba(255,255,255,.08);color:#cbd5e1;border:0;
          width:36px;height:36px;border-radius:10px;font-size:18px;cursor:pointer;
        }
        #hr_flashcard .hr_fc_progress{font-size:14px;color:#94a3b8;font-weight:700}
        #hr_flashcard .hr_card_container{
          flex:1;display:flex;align-items:center;justify-content:center;
          perspective:1200px;
        }
        #hr_flashcard .hr_card_main{
          /* 🔴v1008: 原写死 height:420px, 在 680px 的可用空间里上下各空 130px,
             卡片显小且整体像被压到下半屏。改为随空间伸缩并设上下限。 */
          width:100%;max-width:352px;height:100%;max-height:540px;min-height:320px;
          background:linear-gradient(135deg,#6366f1,#4338ca);
          border-radius:24px;padding:30px;text-align:center;color:#fff;
          box-shadow:0 20px 60px rgba(0,0,0,.5);
          display:flex;flex-direction:column;justify-content:center;align-items:center;
          cursor:pointer;transition:all .3s;
          user-select:none;-webkit-user-select:none;
        }
        #hr_flashcard .hr_card_main.back{
          background:linear-gradient(135deg,#059669,#047857);
        }
        #hr_flashcard .hr_card_emoji{font-size:80px;line-height:1;margin-bottom:16px}
        #hr_flashcard .hr_card_en{font-size:48px;font-weight:900;letter-spacing:1px;margin-bottom:8px}
        #hr_flashcard .hr_card_pn{font-size:16px;opacity:.7;margin-bottom:14px}
        #hr_flashcard .hr_card_cn{font-size:36px;font-weight:900;color:#fde047;margin-bottom:14px}
        #hr_flashcard .hr_card_ex{font-size:20px;line-height:1.6;font-weight:600;font-style:italic;opacity:.95;margin-bottom:10px;padding:0 6px}
        #hr_flashcard .hr_card_excn{font-size:16px;opacity:.85;line-height:1.5;padding:0 6px}
        #hr_flashcard .hr_card_tap_hint{color:rgba(255,255,255,.5);font-size:12px;margin-top:18px}
        #hr_flashcard .hr_fc_btm{
          display:flex;gap:10px;margin-top:14px;
        }
        #hr_flashcard .hr_fc_btm button{
          flex:1;background:rgba(255,255,255,.08);color:#fff;border:0;
          padding:15px 12px;min-height:52px;border-radius:14px;font-size:14.5px;font-weight:800;cursor:pointer;
        }
        #hr_flashcard .hr_fc_btm .next{background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#000}
        #hr_flashcard .hr_fc_btm .speak{background:linear-gradient(135deg,#10b981,#059669)}
      </style>

      <div class="hr_fc_top">
        <button onclick="window.HansenReview._closeAndBack('hr_flashcard')">✕</button>
        <div class="hr_fc_progress" id="hr_fc_prog">1 / ${pool.length}</div>
        <div style="width:36px"></div>
      </div>

      <div class="hr_card_container">
        <div class="hr_card_main" id="hr_fc_card"></div>
      </div>

      <div class="hr_fc_btm">
        <button class="speak" id="hr_fc_speak">🔊 听单词</button>
        <button class="speak" id="hr_fc_speak_ex" style="display:none">📝 听例句</button>
        <button class="next" id="hr_fc_next">下一张 →</button>
      </div>
    `;
    document.body.appendChild(overlay);

    function renderCard(){
      const w = pool[idx];
      const card = document.getElementById('hr_fc_card');
      const prog = document.getElementById('hr_fc_prog');
      if(prog) prog.textContent = (idx + 1) + ' / ' + pool.length;

      const exBtn = document.getElementById('hr_fc_speak_ex');
      if(exBtn) exBtn.style.display = w.ex ? 'block' : 'none';

      if(!flipped){

        card.classList.remove('back');
        card.innerHTML = `
          <div class="hr_card_emoji">${safeEmoji(w.emoji)}</div>
          <div class="hr_card_en">${esc(w.en)}</div>
          ${w.pn ? `<div class="hr_card_pn">${esc(w.pn)}</div>` : ''}
          <div class="hr_card_tap_hint">👆 点卡片看答案</div>
        `;
      } else {

        card.classList.add('back');
        card.innerHTML = `
          <div class="hr_card_emoji">${safeEmoji(w.emoji)}</div>
          <div class="hr_card_cn">${esc(w.cn)}</div>
          ${w.ex ? `<div class="hr_card_ex">"${esc(w.ex)}"</div>` : ''}
          ${w.exCn ? `<div class="hr_card_excn">${esc(w.exCn)}</div>` : ''}
          <div class="hr_card_tap_hint">👆 再点看英文</div>
        `;
      }
    }
    renderCard();

    document.getElementById('hr_fc_card').onclick = function(){
      flipped = !flipped;
      renderCard();

      if(flipped && window.speak){
        setTimeout(() => { try { window.speak(pool[idx].en); } catch(e){} }, 200);
      }
    };

    document.getElementById('hr_fc_next').onclick = function(){
      idx = (idx + 1) % pool.length;
      flipped = false;
      renderCard();
    };

    document.getElementById('hr_fc_speak').onclick = function(){
      if(window.speak) try { window.speak(pool[idx].en); } catch(e){}
    };
    document.getElementById('hr_fc_speak_ex').onclick = function(){

      const w = pool[idx];
      if(w && w.ex && window.speak){
        try { window.speak(w.ex); } catch(e){}
      }
    };
  }

  function openBrowseAll(){
    const pool = getContextVocab();
    if(pool.length === 0){ showToast('暂无单词'); return; }
    openFlashcard(pool);
  }

  function openWrongBook(){
    const wrongs = getContextWrongs();
    if(wrongs.length === 0){
      const msg = document.createElement('div');
      msg.id = 'hr_empty_msg';
      msg.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:30px;cursor:pointer';
      msg.innerHTML = `<div style="background:linear-gradient(135deg,#1e293b,#0f172a);border:2px solid #22c55e;border-radius:18px;padding:30px;text-align:center;color:#fff;font-size:18px;line-height:1.6;max-width:300px">🌟 太棒了!<br>本岛暂无错题<br><br><button id="hr_empty_close" style="margin-top:14px;background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;border:0;padding:10px 24px;border-radius:10px;font-size:14px;font-weight:800;cursor:pointer">关闭</button></div>`;
      document.body.appendChild(msg);

      const closeMsg = () => { const el = document.getElementById('hr_empty_msg'); if(el) el.remove(); };
      document.getElementById('hr_empty_close').onclick = function(e){ e.stopPropagation(); closeMsg(); };
      msg.onclick = function(e){ if(e.target === msg) closeMsg(); };
      return;
    }

    wrongs.sort((a, b) => b.count - a.count);

    const overlay = document.createElement('div');
    overlay.id = 'hr_wrongbook';
    let listHtml = wrongs.map(w => `
      <div class="hr_wb_item" data-en="${esc(w.word.en || '')}">
        <span class="hr_wb_emoji">${safeEmoji(w.word.emoji)}</span>
        <div class="hr_wb_main">
          <div class="hr_wb_en">${esc(w.word.en)}</div>
          <div class="hr_wb_cn">${esc(w.word.cn) || ''}</div>
        </div>
        <div class="hr_wb_count">错 ${safeWrongCount(w.count)} 次</div>
      </div>
    `).join('');

    overlay.innerHTML = `
      <style>
        #hr_wrongbook{
          position:fixed;inset:0;z-index:9999;
          background:linear-gradient(180deg,#1f1b14 0%,#0f172a 100%);
          overflow-y:auto;padding:20px 16px 80px;
        }
        #hr_wrongbook .hr_wb_top{display:flex;align-items:center;gap:12px;margin-bottom:16px}
        #hr_wrongbook .hr_wb_back{
          background:rgba(255,255,255,.08);color:#cbd5e1;border:0;
          width:36px;height:36px;border-radius:10px;font-size:18px;cursor:pointer;
        }
        #hr_wrongbook .hr_wb_title{font-size:22px;font-weight:900;color:#fbbf24;letter-spacing:1px}
        #hr_wrongbook .hr_wb_intro{color:#94a3b8;font-size:12px;margin-bottom:16px;line-height:1.5}
        #hr_wrongbook .hr_wb_item{
          background:rgba(30,41,59,.6);border:1px solid #334155;border-radius:14px;
          padding:14px;margin-bottom:10px;display:flex;align-items:center;gap:14px;
          cursor:pointer;transition:transform .15s;color:#fff;
        }
        #hr_wrongbook .hr_wb_item:active{transform:scale(.98);background:rgba(99,102,241,.15)}
        #hr_wrongbook .hr_wb_emoji{font-size:36px;flex-shrink:0}
        #hr_wrongbook .hr_wb_main{flex:1}
        #hr_wrongbook .hr_wb_en{font-size:18px;font-weight:800}
        #hr_wrongbook .hr_wb_cn{font-size:14px;color:#fde047;margin-top:2px}
        #hr_wrongbook .hr_wb_count{
          background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;
          padding:4px 8px;border-radius:8px;font-size:11px;font-weight:800;
        }
      </style>
      <div class="hr_wb_top">
        <button class="hr_wb_back" onclick="window.HansenReview._closeAndBack('hr_wrongbook')">←</button>
        <div class="hr_wb_title">📕 错题本</div>
      </div>
      <div class="hr_wb_intro">点单词听发音 · 按错过次数排序<br>不要紧, 多看几次就记住了</div>
      ${listHtml}
    `;
    document.body.appendChild(overlay);

    overlay.querySelectorAll('.hr_wb_item').forEach(function(item){
      item.addEventListener('click', function(){
        const en = item.dataset.en;
        if(en && window.speak) try { window.speak(en); } catch(e){}
      });
    });
  }

  console.log('%c[HansenReview]%c 复习中心已就绪',
              'color:#06b6d4;font-weight:bold', 'color:#94a3b8');
})();
