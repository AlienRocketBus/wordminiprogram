
(function(){
  if(window.__hansenTotalsLoaded){ return; } window.__hansenTotalsLoaded = true;

  var KEY = 'hansen_wallet_totals';

  function _read(){
    try{
      var raw=localStorage.getItem(KEY);
      if(!raw) return {perIsland:{}};
      var o=JSON.parse(raw);
      if(!o.perIsland||typeof o.perIsland!=='object') o.perIsland={};
      return o;
    }catch(e){ return {perIsland:{}}; }
  }
  function _write(o){ try{ localStorage.setItem(KEY, JSON.stringify(o)); }catch(e){} }

  window.HansenTotals = {

    report: function(islandKey, data){
      if(!islandKey) return;
      var o=_read();
      var prev=o.perIsland[islandKey]||{};
      o.perIsland[islandKey]={
        learned: Math.max(prev.learned||0, (data&&data.learned)||0),
        maxCombo: Math.max(prev.maxCombo||0, (data&&data.maxCombo)||0),
        level: Math.max(prev.level||0, (data&&data.level)||0)
      };
      _write(o);
    },

    totalLearned: function(){
      try{
        if(window.HansenCanonical){HansenCanonical.absorbCurrent();return HansenCanonical.totalLearned();}
      }catch(e){}
      var o=_read(), sum=0;
      Object.keys(o.perIsland).forEach(function(k){ sum += (o.perIsland[k].learned||0); });
      return sum;
    },

    maxCombo: function(){
      var o=_read(), mx=0;
      Object.keys(o.perIsland).forEach(function(k){ if((o.perIsland[k].maxCombo||0)>mx) mx=o.perIsland[k].maxCombo; });
      return mx;
    },

    maxLevel: function(){
      var o=_read(), mx=0;
      Object.keys(o.perIsland).forEach(function(k){ if((o.perIsland[k].level||0)>mx) mx=o.perIsland[k].level; });
      return mx;
    },

    islandCount: function(){
      try{if(window.HansenCanonical){var c=HansenCanonical.counts(),n=0;Object.keys(c).forEach(function(k){if(c[k].learned>0)n++;});return n;}}catch(e){}
      return Object.keys(_read().perIsland).length;
    },

    _dump: function(){ return _read().perIsland; }
  };
})();
