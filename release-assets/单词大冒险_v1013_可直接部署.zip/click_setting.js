
(function(){
  'use strict';

  var TOGGLE_ID = '__click_sound_toggle';
  var STORAGE_KEY = 'clickSoundEnabled';

  function isSoundOn(){
    try {

      return localStorage.getItem(STORAGE_KEY) !== '0';
    } catch(e){ return true; }
  }

  function setSoundOn(on){
    try {
      localStorage.setItem(STORAGE_KEY, on ? '1' : '0');
    } catch(e){}
  }

  function buildToggleHTML(){
    var on = isSoundOn();
    return (
      '<div class="settings-section" id="' + TOGGLE_ID + '">' +
        '<h3>🔊 点击音效</h3>' +
        '<div class="desc">点击按钮时是否播放"咔嗒"声效。关闭后整个 app 都不会有点击音。</div>' +
        '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:10px">' +
          '<div style="flex:1;font-size:14px;color:#cbd5e1;font-weight:600">' +
            (on ? '当前: <span style="color:#22c55e;font-weight:900">已开启</span>'
                : '当前: <span style="color:#94a3b8;font-weight:900">已关闭</span>') +
          '</div>' +
          '<div id="' + TOGGLE_ID + '_switch" ' +
               'style="cursor:pointer;user-select:none;-webkit-user-select:none;' +
                      'width:60px;height:32px;border-radius:16px;position:relative;' +
                      'transition:background .25s;' +
                      'background:' + (on ? '#22c55e' : '#475569') + '">' +
            '<div style="position:absolute;top:3px;left:' + (on ? '31px' : '3px') + ';' +
                        'width:26px;height:26px;border-radius:50%;background:#fff;' +
                        'box-shadow:0 2px 6px rgba(0,0,0,.3);transition:left .25s"></div>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  function attachHandler(){
    var sw = document.getElementById(TOGGLE_ID + '_switch');
    if(!sw || sw.__clickSoundToggleBound) return;
    sw.__clickSoundToggleBound = true;

    sw.addEventListener('click', function(e){
      e.stopPropagation();
      var newState = !isSoundOn();
      setSoundOn(newState);

      var section = document.getElementById(TOGGLE_ID);
      if(section){
        section.outerHTML = buildToggleHTML();

        setTimeout(attachHandler, 0);
      }
    });
  }

  function inject(){
    var container = document.getElementById('settingsContent');
    if(!container) return false;
    if(document.getElementById(TOGGLE_ID)) {

      attachHandler();
      return true;
    }

    container.insertAdjacentHTML('afterbegin', buildToggleHTML());
    attachHandler();
    return true;
  }

  function observeSettings(){
    var container = document.getElementById('settingsContent');
    if(!container) return;
    var observer = new MutationObserver(function(){

      inject();
    });
    observer.observe(container, { childList: true });
  }

  function init(){
    inject();
    observeSettings();
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  window.addEventListener('load', function(){ setTimeout(init, 100); });

  window.__clickSettingDebug = function(){
    return {
      version: 'v1',
      soundOn: isSoundOn(),
      toggleInjected: !!document.getElementById(TOGGLE_ID),
      storedValue: (function(){ try { return localStorage.getItem(STORAGE_KEY); } catch(e){ return 'error'; } })()
    };
  };
})();
