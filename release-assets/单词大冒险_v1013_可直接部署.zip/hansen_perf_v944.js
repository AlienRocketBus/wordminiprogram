
(function(){
  try {
    if (window.top !== window.self) return;
    if (!window.innerWidth || window.innerWidth <= 520) return;
    var mm = typeof window.matchMedia === 'function' ? window.matchMedia.bind(window) : null;
    var fineHover = !!(mm && mm('(hover: hover) and (pointer: fine)').matches);
    var coarsePrimary = !!(mm && mm('(pointer: coarse)').matches);
    var hasTouch = !!((window.navigator && Number(window.navigator.maxTouchPoints) > 0) || ('ontouchstart' in window));
    var desktopLike = fineHover || (!hasTouch && !coarsePrimary);
    if (!desktopLike) return;
    var KEY = 'hsnViewMode', mode = null;
    try { mode = localStorage.getItem(KEY); } catch(e){}
    if (mode === 'desktop') { injectSwitch(); return; }

    var target = '_frame.html?u=' + encodeURIComponent(location.href);
    try { location.replace(target); } catch(e){ try { location.href = target; } catch(e2){} }
    return;

    function injectSwitch(){
      function go(){
        try {
          if (document.getElementById('hsnSwitchBtn')) return;
          var b = document.createElement('button');
          b.id = 'hsnSwitchBtn'; b.textContent = '📱 切手机版';
          b.style.cssText = 'position:fixed;top:10px;right:10px;z-index:2147483647;padding:7px 13px;'
            + 'border:1px solid rgba(0,0,0,.15);background:rgba(255,255,255,.94);color:#333;border-radius:18px;'
            + 'font-size:13px;font-family:"Microsoft YaHei",sans-serif;cursor:pointer;box-shadow:0 3px 12px rgba(0,0,0,.28)';
          b.onclick = function(){ try { localStorage.setItem('hsnViewMode','mobile'); } catch(e){} try { location.reload(); } catch(e){} };
          document.body.appendChild(b);
        } catch(e){}
      }
      if (document.body) go(); else document.addEventListener('DOMContentLoaded', go);
    }
  } catch(e){}
})();

(function(){
  'use strict';

  function hygiene(){
    try {
      var imgs = document.getElementsByTagName('img');
      var groups = new Map();
      var i, im;
      for(i = 0; i < imgs.length; i++){
        im = imgs[i];
        if(im.__hsnp) continue;
        im.__hsnp = 1;
        if(!im.getAttribute('decoding')) im.setAttribute('decoding','async');

        var up = im.parentElement, d = 0;
        while(up && d < 4){
          if(!groups.has(up)) groups.set(up,[]);
          groups.get(up).push(im);
          up = up.parentElement; d++;
        }
      }
      groups.forEach(function(list, host){

        var total = host.getElementsByTagName('img').length;
        if(total < 6) return;
        var all = host.getElementsByTagName('img');
        for(var k = 4; k < all.length; k++){
          var t = all[k];
          if(!t.getAttribute('loading') && !t.complete) t.setAttribute('loading','lazy');
        }
      });
    } catch(e){}
  }
  var pend = false;
  function schedule(){
    if(pend) return; pend = true;
    (window.requestAnimationFrame || setTimeout)(function(){ pend = false; hygiene(); }, 16);
  }
  try {
    new MutationObserver(schedule).observe(document.documentElement, { childList:true, subtree:true });
  } catch(e){}
  if(document.readyState !== 'loading') schedule();
  else document.addEventListener('DOMContentLoaded', schedule);
})();
