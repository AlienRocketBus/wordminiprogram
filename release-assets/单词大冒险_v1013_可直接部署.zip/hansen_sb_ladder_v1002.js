
(function () {
  'use strict';
  if (window.HansenSbLadder) return;

  var TIERS = [
    { key: 'egg',     name: '幼蜂',     icon: '🥚',   min: 0,    floor: 0    },
    { key: 'worker',  name: '工蜂',     icon: '🐝',   min: 1000, floor: 1000 },
    { key: 'scout',   name: '侦察蜂',   icon: '🔍',   min: 1200, floor: 1200 },
    { key: 'guard',   name: '守卫蜂',   icon: '🛡️',   min: 1400, floor: 1400 },
    { key: 'queen',   name: '蜂王',     icon: '👑',   min: 1600, floor: 1600 },
    { key: 'legend',  name: '传奇蜂王', icon: '🌟',   min: 1800, floor: 1800 }
  ];

  var RATING_MIN = 0;
  var RATING_MAX = 4000;
  var LOSS_DAMPING = 0.6;
  var PLACEMENT_GAMES = 3;

  function num(v, dflt) {
    var n = +v;
    return (typeof n === 'number' && isFinite(n)) ? n : dflt;
  }
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  function tierOf(rating) {
    var r = clamp(num(rating, 1000), RATING_MIN, RATING_MAX);
    var idx = 0;
    for (var i = 0; i < TIERS.length; i++) if (r >= TIERS[i].min) idx = i;
    var t = TIERS[idx];
    var next = TIERS[idx + 1] || null;
    var span = next ? (next.min - t.min) : 200;
    var into = r - t.min;
    return {
      key: t.key, name: t.name, icon: t.icon, index: idx,
      min: t.min, floor: t.floor,
      nextAt: next ? next.min : null,
      nextName: next ? next.name : null,
      progress: next ? clamp(into / span, 0, 1) : 1,
      isTop: !next
    };
  }

  function expectedScore(myRating, oppRating) {
    var a = num(myRating, 1000), b = num(oppRating, 1000);
    return 1 / (1 + Math.pow(10, (b - a) / 400));
  }

  function kFactor(gamesPlayed, placed) {
    var g = Math.max(0, Math.floor(num(gamesPlayed, 0)));
    if (!placed || g < PLACEMENT_GAMES) return 40;
    if (g < 20) return 32;
    return 24;
  }

  function nextRating(opts) {
    opts = opts || {};
    var my = clamp(num(opts.myRating, 1000), RATING_MIN, RATING_MAX);
    var opp = clamp(num(opts.oppRating, 1000), RATING_MIN, RATING_MAX);
    var won = !!opts.won;
    var K = kFactor(opts.gamesPlayed, opts.placed !== false);
    var E = expectedScore(my, opp);

    var raw = won ? (K * (1 - E)) : (K * (0 - E) * LOSS_DAMPING);

    var delta = raw >= 0 ? Math.max(1, Math.round(raw)) : Math.min(-1, Math.round(raw));

    var beforeTier = tierOf(my);
    var target = clamp(my + delta, RATING_MIN, RATING_MAX);

    var floorSaved = false;
    if (!won && target < beforeTier.floor) {
      target = beforeTier.floor;
      floorSaved = true;
    }
    var actualDelta = target - my;
    var afterTier = tierOf(target);

    return {
      rating: target,
      delta: actualDelta,
      tier: afterTier,
      tierChanged: afterTier.key !== beforeTier.key,
      promoted: afterTier.index > beforeTier.index,
      floorSaved: floorSaved,
      k: K,
      expected: E
    };
  }

  function placementEstimate(bestCpm) {
    var c = num(bestCpm, 0);
    if (c <= 0) return 1000;
    return clamp(Math.round(1000 + (c - 30) * 10), 800, 1600);
  }

  function seasonReset(rating) {
    var r = clamp(num(rating, 1000), RATING_MIN, RATING_MAX);
    return clamp(Math.round(1000 + (r - 1000) * 0.5), RATING_MIN, RATING_MAX);
  }

  function matchBand(waitedSeconds) {
    var s = Math.max(0, num(waitedSeconds, 0));
    return clamp(100 + Math.floor(s / 5) * 50, 100, 400);
  }

  window.HansenSbLadder = {
    TIERS: TIERS.slice(),
    PLACEMENT_GAMES: PLACEMENT_GAMES,
    LOSS_DAMPING: LOSS_DAMPING,
    tierOf: tierOf,
    expectedScore: expectedScore,
    kFactor: kFactor,
    nextRating: nextRating,
    placementEstimate: placementEstimate,
    seasonReset: seasonReset,
    matchBand: matchBand
  };
})();
