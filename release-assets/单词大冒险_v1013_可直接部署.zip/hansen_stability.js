
(function(){
  'use strict';
  if(window.__hsnStab){ return; } window.__hsnStab = true;

  var KEY = 'hansen_blackbox';
  function page(){ try{ return (location.pathname.split('/').pop()||'index.html'); }catch(e){ return '?'; } }
  function log(type, msg){
    try{
      var arr = [];
      try{ arr = JSON.parse(localStorage.getItem(KEY)||'[]'); }catch(e){ arr = []; }
      if(!Array.isArray(arr)) arr = [];
      arr.push({ t: Date.now(), p: page(), k: type, m: String(msg).slice(0, 300) });
      if(arr.length > 30) arr = arr.slice(-30);
      localStorage.setItem(KEY, JSON.stringify(arr));
    }catch(e){}
  }

  window.addEventListener('error', function(e){
    try{
      var f = (e.filename||'').split('/').pop();
      log('error', (e.message||'unknown') + ' @' + f + ':' + (e.lineno||0));
    }catch(err){}
  });
  window.addEventListener('unhandledrejection', function(e){
    try{
      var r = e.reason;
      log('promise', (r && r.message) ? r.message : String(r).slice(0, 200));
    }catch(err){}
  });

  setInterval(function(){
    try{
      var m = performance.memory;
      if(m && m.jsHeapSizeLimit && m.usedJSHeapSize > m.jsHeapSizeLimit * 0.85){
        log('memory', 'heap ' + Math.round(m.usedJSHeapSize/1048576) + 'MB / ' +
            Math.round(m.jsHeapSizeLimit/1048576) + 'MB (>85%, 内存吃紧)');
      }
    }catch(e){}
  }, 20000);

  window.HansenBlackbox = {
    read: function(){ try{ return JSON.parse(localStorage.getItem(KEY)||'[]'); }catch(e){ return []; } },
    clear: function(){ try{ localStorage.removeItem(KEY); }catch(e){} }
  };
})();
