
(function(){
  'use strict';

  var PAUSE_MS = 1500;
  var pausedUntil = 0;
  var _batches = [];
  function userActive(){
    pausedUntil = Date.now() + PAUSE_MS;
    try { window.__hansenUserActiveUntil = pausedUntil; } catch(e){}
    for(var i = _batches.length - 1; i >= 0; i--){ try { _batches[i](); } catch(e){} }
  }

  var audioBusyUntil = 0;
  function enterAudioBusy(){
    audioBusyUntil = Date.now() + 30000;
    try { window.__hansenAudioBusyUntil = audioBusyUntil; } catch(e){}
    for(var i = _batches.length - 1; i >= 0; i--){ try { _batches[i](); } catch(e){} }
  }
  function exitAudioBusy(){
    audioBusyUntil = 0;
    try { window.__hansenAudioBusyUntil = 0; } catch(e){}
  }
  (function(){
    try {
      var OrigAudio = window.Audio;
      if(!OrigAudio) return;
      var MEDIA = /(?:^|\/)(?:words|sentences)\/[^?]+\.mp3/i;
      function W(src){
        var a = (arguments.length && src !== undefined) ? new OrigAudio(src) : new OrigAudio();
        try {
          if(src && MEDIA.test(String(src))){
            enterAudioBusy();
            a.addEventListener('loadstart', enterAudioBusy);
            a.addEventListener('play',      enterAudioBusy);
            a.addEventListener('playing',   enterAudioBusy);
            a.addEventListener('waiting',   enterAudioBusy);
            a.addEventListener('ended',     exitAudioBusy);
            a.addEventListener('pause',     exitAudioBusy);
            a.addEventListener('error',     exitAudioBusy);
          }
        } catch(e){}
        return a;
      }
      try { W.prototype = OrigAudio.prototype; } catch(e){}
      window.Audio = W;
    } catch(e){}
  })();

  try {

    document.addEventListener('pointerdown', userActive, { capture: true, passive: true });
    document.addEventListener('touchstart',  userActive, { capture: true, passive: true });
  } catch(e){}

  var V = '';
  try {
    var mySrc = (document.currentScript && document.currentScript.src) || '';
    var m = mySrc.match(/[?&]v=(\d+)/);
    if(m) V = m[1];
  } catch(e){}
  if(!V){

    try {
      var ss = document.getElementsByTagName('script');
      for(var i=0;i<ss.length;i++){
        var mm = (ss[i].src||'').match(/[?&]v=(\d+)/);
        if(mm){ V = mm[1]; break; }
      }
    } catch(e){}
  }
  var BOSS_VER = V ? ('?v=' + V) : '';
  var WORD_VER = '?v215';
  var SENT_VER = '?v91';

  var _imgRefs = [];

  function maxBossUnlocked(){
    var mx = 1;
    try {
      for(var j = 0; j < localStorage.length; j++){
        var k = localStorage.key(j);
        if(!k || k.indexOf('wordIsland') !== 0) continue;
        try {
          var st = JSON.parse(localStorage.getItem(k) || 'null');
          if(st && typeof st.bossUnlocked === 'number' && st.bossUnlocked > mx) mx = st.bossUnlocked;
        } catch(e){}
      }
    } catch(e){}
    if(mx < 1) mx = 1; if(mx > 20) mx = 20;
    return mx;
  }

  function _holdUntil(){
    var u = (pausedUntil > audioBusyUntil ? pausedUntil : audioBusyUntil);
    try { var iu = window.__hsnIslandBusyUntil || 0; if(iu > u) u = iu; } catch(e){}
    return u;
  }

  function _hsnConnection(){
    try{ return navigator.connection || navigator.mozConnection || navigator.webkitConnection || null; }
    catch(e){ return null; }
  }
  function _hsnNetIsSlow(){
    try{
      var c = _hsnConnection();
      if(!c) return true;
      if(c.saveData) return true;
      var t = c.effectiveType || '';
      if(!t) return true;
      return t !== '4g';
    }catch(e){ return true; }
  }
  function _hsnPageVisible(){
    try{
      if(typeof document.visibilityState==='string') return document.visibilityState==='visible';
      return !document.hidden;
    }
    catch(e){ return true; }
  }
  function _hsnCanBackgroundDownload(){
    return !_hsnNetIsSlow() && navigator.onLine !== false && _hsnPageVisible();
  }
  var _backgroundWaiters=[];
  function _waitForBackgroundResume(fn){
    if(typeof fn!=='function')return;
    if(_hsnCanBackgroundDownload()){setTimeout(fn,0);return;}
    if(_backgroundWaiters.indexOf(fn)<0)_backgroundWaiters.push(fn);
  }
  function _wakeBackgroundWaiters(){
    if(!_hsnCanBackgroundDownload()||!_backgroundWaiters.length)return;
    var list=_backgroundWaiters.slice();_backgroundWaiters=[];
    list.forEach(function(fn){setTimeout(function(){try{fn();}catch(e){}},0);});
  }
  try{
    document.addEventListener('visibilitychange',_wakeBackgroundWaiters,{passive:true});
    window.addEventListener('online',_wakeBackgroundWaiters,{passive:true});
    var _conn=_hsnConnection();if(_conn&&typeof _conn.addEventListener==='function')_conn.addEventListener('change',_wakeBackgroundWaiters);
    window.addEventListener('pagehide',function(){_backgroundWaiters=[];},{once:true});
  }catch(e){}
  function _hsnShouldYieldBackground(){
    if(!_hsnCanBackgroundDownload()) return true;
    var until = _holdUntil();
    return Date.now() < until;
  }
  try {
    window.HansenPreloadPolicy = Object.freeze({
      version: 'v960',

      canBackgroundDownload: _hsnCanBackgroundDownload,

      shouldYield: _hsnShouldYieldBackground,
      connectionKnown: function(){ return !!_hsnConnection(); }
    });
  } catch(e){}
  function _hsnLowPrio(img){
    try{ img.fetchPriority = 'low'; }catch(e){}
    try{ img.decoding = 'async'; }catch(e){}
    return img;
  }

  function preloadBossImages(){
    var i = 1;

    if(!_hsnCanBackgroundDownload()){_waitForBackgroundResume(preloadBossImages);return;}
    var CAP = 8;
    try { CAP = Math.min(8, maxBossUnlocked() + 2); } catch(e){ CAP = 8; }
    function loadNextImg(){
      if(i > CAP) return;
      if(!_hsnCanBackgroundDownload()){_waitForBackgroundResume(loadNextImg);return;}

      var now = Date.now();
      var until = _holdUntil();
      if(now < until){ var d = (until - now) + 80; if(d > 500) d = 500; setTimeout(loadNextImg, d); return; }
      var num = i; i++;
      var n = (num < 10 ? '0' : '') + num;
      var img = _hsnLowPrio(new Image());
      _imgRefs.push(img);
      var go = function(){ setTimeout(loadNextImg, 220); };
      var rel = function(){
        var k = _imgRefs.indexOf(img);
        if(k >= 0) _imgRefs[k] = null;
        go();
      };
      img.onload = rel;
      img.onerror = rel;
      try { img.src = 'bosses/lv' + n + '.webp' + BOSS_VER; } catch(e){ go(); }
    }
    loadNextImg();
  }

  function preloadAudioBatch(urls, concurrency, onAllDone){
    var queue = urls.slice();
    var active = [];
    var pumpTimer = null, finished = false;
    if(!queue.length){ if(onAllDone) onAllDone(); return; }
    function unregister(){
      var ix = _batches.indexOf(yieldNow); if(ix >= 0) _batches.splice(ix, 1);
    }
    function maybeDone(){
      if(!finished && queue.length === 0 && active.length === 0){
        finished = true; unregister(); if(onAllDone) onAllDone();
      }
    }
    function abortActive(){
      for(var i=0;i<active.length;i++){
        var it = active[i];
        try { it.a.oncanplaythrough = null; it.a.onloadeddata = null; it.a.onerror = null; } catch(e){}
        try { it.a.src = ''; it.a.removeAttribute('src'); it.a.load(); } catch(e){}
        queue.unshift(it.url);
      }
      active = [];
    }
    function yieldNow(){
      abortActive();
      if(!pumpTimer){ pumpTimer = setTimeout(function(){ pumpTimer = null; pump(); }, PAUSE_MS + 60); }
    }
    function pump(){
      if(!_hsnCanBackgroundDownload()){
        if(active.length) abortActive();
        _waitForBackgroundResume(pump);
        return;
      }
      var now = Date.now();
      var until = _holdUntil();
      if(now < until){
        if(active.length) abortActive();
        var d = (until - now) + 60; if(d > 500) d = 500;
        if(!pumpTimer){ pumpTimer = setTimeout(function(){ pumpTimer = null; pump(); }, d); }
        return;
      }
      while(active.length < concurrency && queue.length){
        var url = queue.shift();
        (function(u){
          var a;
          try { a = new Audio(); } catch(e){ setTimeout(pump, 0); return; }
          a.preload = 'auto';
          var rec = { a: a, url: u };
          active.push(rec);
          var done = false;
          var fin = function(){
            if(done) return; done = true;
            var k = active.indexOf(rec); if(k >= 0) active.splice(k, 1);
            maybeDone(); pump();
          };
          a.addEventListener('canplaythrough', fin);
          a.addEventListener('loadeddata', fin);
          a.addEventListener('error', fin);
          try { a.src = u; a.load(); } catch(e){ fin(); }
        })(url);
      }
      maybeDone();
    }
    _batches.push(yieldNow);
    pump();
  }

  function getWordUrls(){
    var seen = {}, urls = [];
    function add(rel){
      if(rel && !seen[rel]){ seen[rel] = 1; urls.push(rel + WORD_VER); }
    }

    try {
      if(window.WORD_MAP){
        for(var k in window.WORD_MAP){
          if(Object.prototype.hasOwnProperty.call(window.WORD_MAP, k)) add(window.WORD_MAP[k]);
        }
      }
    } catch(e){}

    var fallback = [
      'words/word_01.mp3','words/word_02.mp3','words/word_03.mp3','words/word_04.mp3','words/word_05.mp3',
      'words/word_06.mp3','words/word_07.mp3','words/washing_machine.mp3','words/word_09.mp3','words/how_many.mp3',
      'words/how_much.mp3','words/how_old.mp3','words/how_long.mp3','words/how_far.mp3','words/word_15.mp3',
      'words/next_to.mp3','words/word_17.mp3','words/word_18.mp3','words/word_19.mp3','words/word_20.mp3',
      'words/word_21.mp3','words/word_23.mp3','words/word_24.mp3','words/word_25.mp3',
      'words/bed.mp3','words/have.mp3','words/do.mp3','words/cap.mp3','words/gloves.mp3'
    ];
    for(var j=0;j<fallback.length;j++) add(fallback[j]);
    return urls;
  }

  function getIslandWordUrls(){
    var seen = {}, urls = [];
    try {
      var tbl = window.__ISLAND_LOCAL_AUDIO || null;
      var wm  = window.WORD_MAP || null;
      if(window.allW){
        for(var i=0;i<window.allW.length;i++){
          var w = window.allW[i];
          if(!w || !w.en) continue;
          var lower = String(w.en).toLowerCase();
          var mp3 = (tbl && (tbl[lower] || tbl[w.en])) || (wm && (wm[lower] || wm[w.en]));
          if(mp3 && !seen[mp3]){ seen[mp3] = 1; urls.push(mp3 + WORD_VER); }
        }
      }
    } catch(e){}
    return urls;
  }

  function getSentenceUrls(){
    var urls = [];
    var max = 709;

    try {
      if(window.SENTENCE_MAP){
        var mx = 0;
        for(var k in window.SENTENCE_MAP){
          if(Object.prototype.hasOwnProperty.call(window.SENTENCE_MAP, k)){
            var v = window.SENTENCE_MAP[k];
            if(typeof v === 'number' && v > mx) mx = v;
          }
        }
        if(mx > 0) max = mx;
      }
    } catch(e){}
    for(var i=1;i<=max;i++){
      var s = '' + i;
      while(s.length < 4) s = '0' + s;
      urls.push('sentences/sentence_' + s + '.mp3' + SENT_VER);
    }
    return urls;
  }

  function preheatUrlBatch(urls, concurrency, onAllDone){
    var queue = urls.slice();
    var active = [];
    var pumpTimer = null, finished = false;
    if(!queue.length){ if(onAllDone) onAllDone(); return; }
    function unregister(){ var ix = _batches.indexOf(yieldNow); if(ix >= 0) _batches.splice(ix, 1); }
    function maybeDone(){ if(!finished && queue.length === 0 && active.length === 0){ finished = true; unregister(); if(onAllDone) onAllDone(); } }
    function abortActive(){
      for(var i=0;i<active.length;i++){ var it = active[i]; try { if(it.ctrl) it.ctrl.abort(); } catch(e){} if(it.url) queue.unshift(it.url); }
      active = [];
    }
    function yieldNow(){ abortActive(); if(!pumpTimer){ pumpTimer = setTimeout(function(){ pumpTimer = null; pump(); }, PAUSE_MS + 60); } }
    function pump(){
      if(!_hsnCanBackgroundDownload()){
        if(active.length) abortActive();
        _waitForBackgroundResume(pump);
        return;
      }
      var now = Date.now();
      var until = _holdUntil();
      if(now < until){ if(active.length) abortActive(); var d = (until - now) + 60; if(d > 500) d = 500; if(!pumpTimer){ pumpTimer = setTimeout(function(){ pumpTimer = null; pump(); }, d); } return; }
      while(active.length < concurrency && queue.length){
        var url = queue.shift();
        (function(u){
          var ctrl = null; try { ctrl = ('AbortController' in window) ? new AbortController() : null; } catch(e){ ctrl = null; }
          var rec = { ctrl: ctrl, url: u };
          active.push(rec);
          var done = false;
          var fin = function(){ if(done) return; done = true; var k = active.indexOf(rec); if(k >= 0) active.splice(k, 1); maybeDone(); pump(); };
          try {
            fetch(u, ctrl ? { priority:'low', signal: ctrl.signal, credentials: 'same-origin' } : { credentials: 'same-origin' })
              .then(function(r){ return r.blob(); })
              .then(function(){ fin(); })
              .catch(function(){ fin(); });
          } catch(e){ fin(); }
        })(url);
      }
      maybeDone();
    }
    _batches.push(yieldNow);
    pump();
  }

  function preheatIslandEntryResources(onAllDone){

    try { if(!document.getElementById('islandFrameWrap')){ if(onAllDone) onAllDone(); return; } } catch(e){ if(onAllDone) onAllDone(); return; }
    if(!_hsnCanBackgroundDownload()){ if(onAllDone) onAllDone(); return; }

    try {
      var _petImg = localStorage.getItem('hansen_pet_hero_img');
      if(_petImg){
        var _pu = new URL(_petImg, location.href);
        if(_pu.origin === location.origin && /\/pets\/[^/]+\.(?:webp|png)$/i.test(_pu.pathname)){
          var _pim = new Image(); try{ _pim.fetchPriority = 'low'; }catch(e){} _pim.src = _pu.href;
        }
      }
    } catch(e){}

    var target = '';
    try {
      var recent = document.getElementById('recentLearnStat');
      if(recent && recent._target) target = String(recent._target);
      if(!/^island_[a-z0-9]+\.html$/.test(target)){
        var first = document.querySelector('a.island[href^="island_"]');
        target = first ? String(first.getAttribute('href') || '') : '';
      }
    } catch(e){}
    if(!/^island_[a-z0-9]+\.html$/.test(target)){ if(onAllDone) onAllDone(); return; }
    var vq = V ? ('?v=' + V) : '';

    fetch(target + vq, { credentials: 'same-origin', priority:'low' }).then(function(r){ return r.text(); }).then(function(htmlText){
      var scripts = [], icons = [];
      try {
        var doc = new DOMParser().parseFromString(htmlText, 'text/html');
        var ss = doc.querySelectorAll('script[src]');
        for(var i=0;i<ss.length;i++){ var s = ss[i].getAttribute('src'); if(s && s.indexOf('.js') !== -1) scripts.push(s); }
        var ims = doc.querySelectorAll('img[src]'); var iseen = {};
        for(var j=0;j<ims.length;j++){ var im = ims[j].getAttribute('src'); if(im && im.indexOf('icons/') === 0 && !iseen[im]){ iseen[im] = 1; icons.push(im); } }
      } catch(e){}

      var _pending = 2;
      function _entryDone(){
        if(--_pending !== 0) return;
        if(onAllDone) onAllDone();
      }
      preheatUrlBatch(scripts, 4, _entryDone);
      preheatUrlBatch(icons, 3, _entryDone);
    }).catch(function(){ if(onAllDone) onAllDone(); });
  }

  var AUDIO_DONE_KEY = 'hansen_audio_preload_done';
  function audioAlreadyDone(){
    try { return sessionStorage.getItem(AUDIO_DONE_KEY) === '1'; } catch(e){ return false; }
  }
  function markAudioDone(){
    try { sessionStorage.setItem(AUDIO_DONE_KEY, '1'); } catch(e){}
  }

  function start(){

    var run = function(){
      try {

        if(!_hsnCanBackgroundDownload()){_waitForBackgroundResume(run);return;}
        var inHomeShell = false;
        try { inHomeShell = !!document.getElementById('islandFrameWrap'); } catch(e){}
        if(inHomeShell){

          preheatIslandEntryResources(function(){ try { preloadBossImages(); } catch(e){} });
          return;
        }

        var islandWords = getIslandWordUrls();
        var afterIsland = function(){ try { preloadBossImages(); } catch(e){} };
        if(islandWords.length){
          preloadAudioBatch(islandWords, 3, afterIsland);
        } else {
          afterIsland();
        }
      } catch(e){ try { preloadBossImages(); } catch(e2){} }
    };
    if('requestIdleCallback' in window){
      try { requestIdleCallback(run, {timeout: 2500}); } catch(e){ setTimeout(run, 1200); }
    } else {
      setTimeout(run, 1200);
    }
  }

  if(document.readyState === 'complete' || document.readyState === 'interactive'){
    setTimeout(start, 300);
  } else {
    window.addEventListener('load', function(){ setTimeout(start, 300); });
  }
})();

(function(){
  'use strict';
  if(window.__hsnExPrefetch) return; window.__hsnExPrefetch = true;
  var W2S = null;
  function buildMap(){
    if(W2S) return W2S;
    var src = null;
    try { src = allW; } catch(e){ try { src = window.allW; } catch(e2){} }
    if(!src || !src.length) return null;
    var m = {};
    try { for(var i=0;i<src.length;i++){ var w=src[i]; if(w && w.en && w.ex){ m[String(w.en).toLowerCase()] = w.ex; } } } catch(e){}
    W2S = m; return W2S;
  }
  var _warmed = {};
  function warmSentence(ex){
    try{
      if(!window.HansenPreloadPolicy || !window.HansenPreloadPolicy.canBackgroundDownload()) return;
      if(!ex || !window.SENTENCE_MAP) return;
      var idx = window.SENTENCE_MAP[ex];
      if(idx == null) return;
      var url = 'sentences/sentence_' + String(idx).padStart(4,'0') + '.mp3?v91';
      if(_warmed[url]) return; _warmed[url] = 1;
      fetch(url).then(function(r){ return r.blob(); }).catch(function(){});
    }catch(e){}
  }
  function tryHook(){
    if(typeof window.speak !== 'function' || window.speak.__hsnExWrapped) return false;
    var orig = window.speak;
    window.speak = function(t, r, cb){
      var ret = orig.apply(this, arguments);
      try{
        var text = (t==null) ? '' : String(t).trim().toLowerCase();
        if(text){
          var map = buildMap();
          var ex = map && map[text];
          if(ex){ setTimeout(function(){ warmSentence(ex); }, 300); }
        }
      }catch(e){}
      return ret;
    };
    window.speak.__hsnExWrapped = true;
    return true;
  }
  if(!tryHook()){
    var n=0, iv=setInterval(function(){ if(tryHook() || ++n>60) clearInterval(iv); }, 100);
  }
})();
