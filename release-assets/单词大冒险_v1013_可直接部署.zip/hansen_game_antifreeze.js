
(function () {
  'use strict';
  if (window.__hansenAntiFreezeV63) return;
  window.__hansenAntiFreezeV63 = true;

  function $(id) { return document.getElementById(id); }
  function scrActive(id) { var s = $(id); return !!(s && s.classList.contains('active')); }

  function G(name) {
    try {
      switch(name){
        case 'typeActive': return typeof typeActive !== 'undefined' ? typeActive : window.typeActive;
        case 'fishActive': return typeof fishActive !== 'undefined' ? fishActive : window.fishActive;
        case 'fishOnscreen': return typeof fishOnscreen !== 'undefined' ? fishOnscreen : window.fishOnscreen;
        case 'bubbleActive': return typeof bubbleActive !== 'undefined' ? bubbleActive : window.bubbleActive;
        case 'listenActive': return typeof listenActive !== 'undefined' ? listenActive : window.listenActive;
        case 'listenQ': return typeof listenQ !== 'undefined' ? listenQ : window.listenQ;
        case 'clozeActive': return typeof clozeActive !== 'undefined' ? clozeActive : window.clozeActive;
        case 'molesActive': return typeof molesActive !== 'undefined' ? molesActive : window.molesActive;
        case 'reviewState': return typeof reviewState !== 'undefined' ? reviewState : window.reviewState;
      }
    } catch(e){}
    return window[name];
  }

  var MODES = [
    {
      name: 'typing', screen: 'typingScreen', grace: 3000, verified: true,

      stuck: function () {
        if (!scrActive('typingScreen')) return false;
        if (G('typeActive') !== false) return false;
        if (!$('typeSlots')) return false;
        return true;
      },
      recover: function () { try { if(typeof typeActive !== 'undefined') typeActive = true; if(typeof nextTypeQ === 'function') nextTypeQ(); } catch(e){} }
    },
    {
      name: 'fish', screen: 'fishScreen', grace: 3000, verified: true,

      stuck: function () {
        if (!scrActive('fishScreen')) return false;
        if (G('fishActive') !== true) return false;
        var on = G('fishOnscreen');
        if (typeof on !== 'number') { var p = $('fishPond'); on = p ? p.children.length : 1; }
        return on <= 0;
      },
      recover: function () { try { if(typeof fishSpawnTimer !== 'undefined' && fishSpawnTimer){ clearTimeout(fishSpawnTimer); fishSpawnTimer = null; } if(typeof spawnFishLoop === 'function') spawnFishLoop(); } catch(e){} }
    },
    {
      name: 'bubble', screen: 'bubbleScreen', grace: 9000, verified: true,

      stuck: function () {
        if (!scrActive('bubbleScreen')) return false;
        if (G('bubbleActive') !== true) return false;
        return document.querySelectorAll('#bubbleScreen .bubble:not([data-done])').length === 0;
      },
      recover: function () { try { window.bubbleLocked=false; if(typeof nextBubble === 'function') nextBubble(); } catch(e){} }
    },
    {
      name: 'listen', screen: 'listenScreen', grace: 9000, verified: true,

      stuck: function () {
        if (!scrActive('listenScreen')) return false;
        if (G('listenActive') !== true) return false;
        var lq = G('listenQ'); if (!lq) return false;
        if (document.querySelectorAll('#listenScreen .boss-opt').length === 0) return false;
        return lq.answered === true;
      },
      recover: function () { try { if(typeof nextListenQ === 'function') nextListenQ(); } catch(e){} }
    },
    {
      name: 'cloze', screen: 'clozeScreen', grace: 9000, verified: true,

      stuck: function () {
        if (!scrActive('clozeScreen')) return false;
        if (G('clozeActive') !== true) return false;
        if (document.querySelectorAll('#clozeScreen .cloze-opt').length === 0) return false;
        return document.querySelectorAll('#clozeScreen .cloze-opt:not([data-done])').length === 0;
      },
      recover: function () { try { if(typeof nextClozeQ === 'function') nextClozeQ(); } catch(e){} }
    },
    {
      name: 'moles', screen: 'molesScreen', grace: 3000, verified: true,

      stuck: function () {
        if (!scrActive('molesScreen')) return false;
        if (G('molesActive') !== true) return false;
        var slots = document.querySelectorAll('#molesScreen [id^="moleSlot"]');
        if (slots.length === 0) return false;
        for (var i = 0; i < slots.length; i++) { if (slots[i].dataset && slots[i].dataset.locked) return true; }
        return false;
      },
      recover: function () { try { if(typeof startMolesWave === 'function') startMolesWave(); } catch(e){} }
    },
    {
      name: 'review', screen: 'reviewScreen', grace: 3000, verified: true,

      stuck: function () {
        if (!scrActive('reviewScreen')) return false;
        var rs = G('reviewState'); if (!rs || !rs.currentQ) return false;
        if (rs.idx >= (rs.pool ? rs.pool.length : 0)) return false;
        return rs.currentQ.answered === true;
      },
      recover: function () { try { if(typeof reviewState !== 'undefined' && reviewState){ reviewState.idx++; if(typeof reviewNext === 'function') reviewNext(); } } catch(e){} }
    }

  ];

  function activeMode() {
    for (var i = 0; i < MODES.length; i++) {
      if (!MODES[i].verified) continue;
      if (scrActive(MODES[i].screen)) return MODES[i];
    }
    return null;
  }

  var _pending = null;

  function onForeground() {
    var m = activeMode();
    if (!m || !m.stuck()) return;
    if (_pending) { clearTimeout(_pending); _pending = null; }
    _pending = setTimeout(function () {
      _pending = null;
      var mm = activeMode();
      if (!mm || mm.name !== m.name || !mm.stuck()) return;
      try { console.warn('[Antifreeze] 🔴 BUG#63 小游戏看门狗: 【' + mm.name + '】回前台后卡死, 强制恢复'); } catch (e) {}
      try { mm.recover(); } catch (e) { try { console.warn('[Antifreeze] BUG#63 恢复失败(' + mm.name + '):', e); } catch (_e) {} }
    }, m.grace);
  }

  try {
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') onForeground(); });
    window.addEventListener('pageshow', function () { if (document.visibilityState !== 'hidden') onForeground(); });
  } catch (e) {}

  window.HansenAntiFreeze = {
    version: 'v511',
    activeMode: function () { var m = activeMode(); return m ? m.name : null; },
    isStuck: function () { var m = activeMode(); return !!(m && m.stuck()); },
    _kick: function () { onForeground(); },
    _modes: MODES
  };
})();
