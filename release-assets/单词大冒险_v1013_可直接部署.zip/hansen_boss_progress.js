
(function(){
  'use strict';

  function getRequiredWins(bossLv){
    if(bossLv <= 0) return 1;
    if(bossLv === 1) return 1;
    if(bossLv === 2) return 2;
    return 3;
  }

  function getS(){
    return window.S || null;
  }

  function ensureFields(){
    var S = getS();
    if(!S) return false;
    if(!S.bossWins || typeof S.bossWins !== 'object'){
      S.bossWins = {};
    }

    if(!S.__bossUnlockFixedV319){
      S.__bossUnlockFixedV319 = true;
      var realUnlocked = 1;
      for(var lv = 1; lv < 20; lv++){
        var winsAtLv = (S.bossWins && S.bossWins[lv]) || 0;
        if(winsAtLv >= getRequiredWins(lv)) realUnlocked = lv + 1;
        else break;
      }
      S.bossUnlocked = realUnlocked;
      if(typeof S.bossCurrentLv === 'number' && S.bossCurrentLv > realUnlocked){
        S.bossCurrentLv = realUnlocked;
      }
      try { if(typeof window.save === 'function') window.save(); } catch(e){}
    }

    if(!S.__PER_ISLAND_RESET_V330){
      S.__PER_ISLAND_RESET_V330 = true;

      S.bossUnlocked = 1;
      S.bossCurrentLv = 1;
      S.bossWins = {};
      try { delete S.bossSelected; } catch(e){ S.bossSelected = undefined; }
      try { delete S.bossBeaten; } catch(e){}
      if(S.stats && typeof S.stats === 'object'){ S.stats.bossBeaten = 0; }

      try {
        localStorage.removeItem('hansen_card_data');
        localStorage.removeItem('hansen_card_data_bak');
        localStorage.removeItem('hansen_card_temp_unlock_until');
      } catch(e){}
      try { if(typeof window.save === 'function') window.save(); } catch(e){}
      try { console.log('[HBP] 🔴 v330 每岛独立迁移完成: 已删除旧全局卡牌存档, 本岛 boss 进度从第1关独立重新开始'); } catch(e){}
    }

    if(!S.__bossUnlockResetV327){
      S.__bossUnlockResetV327 = true;
      S.bossUnlocked = 1;
      S.bossCurrentLv = 1;
      S.bossWins = {};
      try { if(typeof window.save === 'function') window.save(); } catch(e){}
    }

    if(typeof S.bossUnlocked !== 'number' || !isFinite(S.bossUnlocked) || S.bossUnlocked < 1){

      S.bossUnlocked = 1;
    }
    S.bossUnlocked = Math.max(1, Math.min(20, S.bossUnlocked));

    if('bossSelected' in S){
      try { delete S.bossSelected; } catch(e){ S.bossSelected = undefined; }
    }

    if(typeof S.bossCurrentLv !== 'number' || !isFinite(S.bossCurrentLv) || S.bossCurrentLv < 1){
      S.bossCurrentLv = 1;
    }

    S.bossCurrentLv = Math.max(1, Math.min(20, Math.min(S.bossUnlocked, S.bossCurrentLv)));
    return true;
  }

  function getUnlockedBossLv(){
    var S = getS();
    if(!ensureFields()) return 1;
    return Math.min(20, Math.max(1, S.bossUnlocked || 1));
  }

  function recordBossWin(bossLv){
    var S = getS();
    if(!ensureFields()) return;
    bossLv = Math.max(1, Math.min(20, bossLv | 0));

    var curUnlocked = Math.max(1, Math.min(20, S.bossUnlocked || 1));
    if(bossLv > curUnlocked){
      try { console.warn('[HBP] 拒绝记录未解锁关 Lv' + bossLv + ' 的胜利 (当前只解锁到 Lv' + curUnlocked + '), 防跳关'); } catch(e){}
      return;
    }

    S.bossWins[bossLv] = (S.bossWins[bossLv] || 0) + 1;

    var needed = getRequiredWins(bossLv);
    if(S.bossWins[bossLv] >= needed && bossLv >= curUnlocked && bossLv < 20){
      S.bossUnlocked = bossLv + 1;

      showUnlockBanner(bossLv + 1);
    }

    try { if(typeof window.save === 'function') window.save(); } catch(e){}
  }

  function showUnlockBanner(newLv){
    var mask = document.createElement('div');
    mask.style.cssText = 'position:fixed;inset:0;z-index:99997;background:rgba(0,0,0,0.85);display:flex;align-items:center;justify-content:center;padding:30px;animation:hbpFade 0.3s';
    mask.innerHTML = '<div style="background:linear-gradient(135deg,#7c3aed,#1e1b4b);border:3px solid #fbbf24;border-radius:20px;padding:30px;text-align:center;color:#fff;max-width:340px;box-shadow:0 0 60px rgba(251,191,36,0.6)">' +
      '<div style="font-size:80px;line-height:1;margin-bottom:14px">🔓</div>' +
      '<div style="font-size:22px;font-weight:900;color:#fbbf24;margin-bottom:10px">新 Boss 解锁!</div>' +
      '<div style="font-size:16px;color:#fde047;margin-bottom:20px;line-height:1.6">Lv ' + newLv + ' 已开放, 准备好挑战了吗?</div>' +
      '<button id="hbpUnlockOk" style="background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#000;border:0;padding:12px 32px;border-radius:12px;font-size:16px;font-weight:900;cursor:pointer">收下!</button>' +
    '</div>';
    document.body.appendChild(mask);

    var btn = mask.querySelector('#hbpUnlockOk');
    if(btn) btn.addEventListener('click', function(){ try{ mask.remove(); }catch(e){} });
    setTimeout(function(){
      mask.addEventListener('click', function(e){
        if(e.target === mask){ try{ mask.remove(); }catch(e2){} }
      });
    }, 500);
    var esc = function(e){
      if(e.key === 'Escape' || e.keyCode === 27){
        try{ mask.remove(); }catch(e2){}
        document.removeEventListener('keydown', esc);
      }
    };
    document.addEventListener('keydown', esc);
    try { if(window.playLevelUp) window.playLevelUp(); } catch(e){}
  }

  function hookBossVictory(){
    if(typeof window.bossVictory !== 'function') return false;
    if(window.__hbpVictoryHooked) return true;
    window.__hbpVictoryHooked = true;

    var origVictory = window.bossVictory;
    window.bossVictory = function(){

      try {
        ensureFields();
        var S = getS();
        var curBossLv;
        if(window._hansenRebattleLv != null){
          curBossLv = Math.max(1, Math.min(20, window._hansenRebattleLv | 0));
        } else {

          curBossLv = Math.max(1, Math.min(20, (S.bossCurrentLv || S.level || 1) | 0));
        }
        recordBossWin(curBossLv);
      } catch(e){ console.warn('[HBP] recordBossWin 失败:', e); }

      return origVictory.apply(this, arguments);
    };
    return true;
  }

  function init(){
    if(!getS()){ setTimeout(init, 200); return; }
    ensureFields();
    var ok2 = hookBossVictory();
    if(!ok2){ setTimeout(init, 200); return; }
    console.log('[HBP] BUG #17 修复模块已挂载 (只 hook bossVictory 记次数, 不动 startBoss). 解锁 Lv:', getS().bossUnlocked);
  }

  if(typeof document !== 'undefined'){
    var st = document.createElement('style');
    st.textContent = '@keyframes hbpFade{from{opacity:0}to{opacity:1}}';
    if(document.head) document.head.appendChild(st);
  }

  if(typeof document !== 'undefined' && document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 300);
  }

  window.HansenBossProgress = {
    getUnlockedBossLv: getUnlockedBossLv,
    getRequiredWins: getRequiredWins,
    recordBossWin: recordBossWin,
    getWins: function(bossLv){
      var S = getS();
      return (S && S.bossWins && S.bossWins[bossLv]) || 0;
    },

    _reset: function(){
      var S = getS();
      if(!S) return;
      S.bossWins = {};
      S.bossUnlocked = 1;
      S.bossSelected = 1;
      try { if(typeof window.save === 'function') window.save(); } catch(e){}
      console.log('[HBP] 已重置 boss 进度');
    }
  };
})();
