
(function(){
  'use strict';
  var OV_ID = 'hsnSbOverlay';
  var activeFrame = null;
  var activeFocus = null;

  function lockScroll(on){
    try{ document.body.style.overflow = on ? 'hidden' : ''; }catch(e){}
  }

  function onPop(){

    doClose(true);
  }

  function doClose(fromPop){
    var ov = document.getElementById(OV_ID);
    if(!ov){ activeFrame = null; activeFocus = null; return; }

    try{ if(typeof window.playNavClick === 'function') window.playNavClick(); }catch(e){}

    var focusChanged=!!(activeFocus&&activeFocus.consumed);
    activeFrame = null;activeFocus = null;
    if(ov.parentNode) ov.parentNode.removeChild(ov);
    lockScroll(false);
    window.removeEventListener('popstate', onPop);
    if(!fromPop){

      try{ history.back(); }catch(e){}
    }
    if(focusChanged){
      try{window.dispatchEvent(new CustomEvent('hansen-progress-changed',{detail:{source:'focused-spelling-bee',channel:'crystal'}}));}catch(e){}
      try{if(window.HansenExploreProgress&&typeof HansenExploreProgress.refresh==='function')HansenExploreProgress.refresh();}catch(e2){}
    }
  }

  function currentIslandKey(){
    try{var file=(location.pathname.split('/').pop()||'').toLowerCase(),m=file.match(/^island_(action|adjective|animal|body|city|clothes|color|family|food|home|job|land[1-8]|nature|question|school|season|sports|time|traffic|treasure)\.html$/);return m?m[1]:'';}catch(e){return '';}
  }
  function focusSessionId(){
    try{if(!window.crypto||typeof crypto.getRandomValues!=='function')return '';var a=new Uint8Array(16);crypto.getRandomValues(a);var h='';for(var i=0;i<a.length;i++)h+=('0'+a[i].toString(16)).slice(-2);return 'sbf_'+h;}catch(e){return '';}
  }
  function focusAllowed(index){
    try{
      var gate=window.HansenSpellingProgressV946;if(gate&&typeof gate.allows==='function')return gate.allows('crystal',index)===true;
      var crystal=window.HansenCrystal;if(!crystal||typeof crystal.sliceProgress!=='function')return false;
      var snap=crystal.sliceProgress(),item=snap&&snap.ok&&snap.items&&snap.items[index];
      return !!(item&&!item.done&&!item.lockedToday);
    }catch(e){return false;}
  }
  function openFrame(islandKey,focus){
      if(document.getElementById(OV_ID)) return;
      var ov = document.createElement('div');
      ov.id = OV_ID;
      ov.setAttribute('role', 'dialog');
      ov.setAttribute('aria-label', '拼写对战');

      ov.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;'
        + 'z-index:2147483600;background:#0a0f24;overflow:hidden;';
      var ifr = document.createElement('iframe');
      ifr.title = '拼写对战';
      ifr.src = 'spelling_bee.html?v=1013&island=' + encodeURIComponent(islandKey || '') + '&embed=1'
        +(focus?'&focus=crystal&index='+encodeURIComponent(focus.index)+'&session='+encodeURIComponent(focus.sessionId):'');
      ifr.style.cssText = 'display:block;width:100%;height:100%;border:0;margin:0;padding:0;background:#0a0f24;';
      ifr.setAttribute('allow', 'autoplay');
      ifr.setAttribute('scrolling', 'no');
      ov.appendChild(ifr);
      document.body.appendChild(ov);
      activeFrame = ifr;activeFocus=focus||null;
      lockScroll(true);

      try{ history.pushState({ hsnSb: 1 }, ''); }catch(e){}
      window.addEventListener('popstate', onPop);
      return true;
  }
  function openFocused(index){
    index=Number(index);var island=currentIslandKey(),word=null,api=window.HansenSpellingProgressV946;
    if(!island||!isFinite(index)||Math.floor(index)!==index||index<0||!window.allW||index>=allW.length)return false;
    word=String((allW[index]||{}).en||'').trim().toLowerCase();if(!word||word.length>120)return false;
    if(!api||typeof api.run!=='function'||!focusAllowed(index)){try{if(typeof showToast==='function')showToast('这个词今天已完成结晶加固，请明天再来');}catch(e){}return false;}
    var session=focusSessionId();if(!session)return false;
    return openFrame(island,{sessionId:session,channel:'crystal',island:island,index:index,word:word,openedAt:Date.now(),consumed:false});
  }

  window.HansenSpellBee = {

    open: function(islandKey){
      return openFrame(islandKey,null);
    },

    openFocused:openFocused,
    openFocus:openFocused,
    close: function(){ doClose(false); }
  };

  var SB_REWARD_PENDING_KEY = 'hansen_sb_reward_pending_v942';
  function sbObject(key){
    try{var o=JSON.parse(localStorage.getItem(key)||'{}');return o&&typeof o==='object'&&!Array.isArray(o)?o:null;}catch(e){return null;}
  }
  function sbExactKeys(o,names){return !!o&&typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).sort().join(',')===names.slice().sort().join(',');}
  function sbRewardReceipt(d){
    var id=String(d&&d.rewardId||'');
    if(!/^sb:\d{4}-\d{1,2}-\d{1,2}:\d{1,12}$/.test(id))return null;
    var pending=sbObject(SB_REWARD_PENDING_KEY);if(!pending)return null;
    var r=pending[id];if(!r||r.schema!==1||r.rewardId!==id)return null;
    var c=+r.coins,x=+r.xp,kind=String(r.kind||''),day=String(r.day||''),createdAt=+r.createdAt;
    if(id.indexOf('sb:'+day+':')!==0||!/^\d{4}-\d{1,2}-\d{1,2}$/.test(day))return null;
    if(!isFinite(createdAt)||Math.floor(createdAt)!==createdAt||createdAt<=0)return null;
    if(kind==='mastery'){
      if(!sbExactKeys(r,['schema','rewardId','day','coins','xp','kind','word','index','createdAt'])||c!==0||x!==0)return null;
      var word=String(r.word||''),idx=+r.index;
      if(!word||word!==word.trim().toLowerCase()||word.length>120||!isFinite(idx)||Math.floor(idx)!==idx||idx<0||idx>9999)return null;
      if(!d||d.type!=='hsn_sb_mastery'||d.coins!==0||d.xp!==0||String(d.kind||'')!=='mastery'||
         String(d.word||'')!==word||d.index!==idx||d.createdAt!==createdAt)return null;
      return {schema:1,rewardId:id,day:day,coins:0,xp:0,kind:'mastery',word:word,index:idx,createdAt:createdAt};
    }
    if(!sbExactKeys(r,['schema','rewardId','day','coins','xp','kind','createdAt']))return null;
    if(!isFinite(c)||Math.floor(c)!==c||c<1 || c>20||!isFinite(x)||Math.floor(x)!==x||x<0 || x>6)return null;
    if((kind==='word'&&!(x===2||x===4||x===6))||(kind==='match'&&(x!==0||c>15))||(kind!=='word'&&kind!=='match'))return null;

    if(!d||d.type!=='hsn_sb_reward'||d.coins!==c||d.xp!==x||String(d.kind||'')!==kind||d.createdAt!==createdAt)return null;
    return {schema:1,rewardId:id,day:day,coins:c,xp:x,kind:kind,createdAt:createdAt};
  }
  function sbAwardReward(r){
    var base='spellbee:'+r.rewardId;
    try{
      if(!window.HansenCoins||typeof HansenCoins.award!=='function'||HansenCoins.award(base+':coin',r.coins)!==true)return false;
      if(r.xp>0){
        if(!window.HansenRewardEffectsV942||typeof HansenRewardEffectsV942.xpAward!=='function'||
           HansenRewardEffectsV942.xpAward(base+':xp',r.xp)!==true)return false;
      }
      return true;
    }catch(e){return false;}
  }
  function sbAck(target,id){
    try{if(target&&typeof target.postMessage==='function')target.postMessage({type:'hsn_sb_reward_ack',rewardId:id},'*');}catch(e){}
  }

  var SB_FOCUS_PENDING_KEY='hansen_sb_focus_pending_v946';
  function focusRule(cpm){cpm=Math.floor(Number(cpm));return cpm>=80?{tier:'advanced',required:5}:(cpm>=50?{tier:'intermediate',required:7}:{tier:'beginner',required:10});}
  function sameFocusProof(a,b){
    var keys=['schema','sessionId','focused','channel','island','index','word','cpm','tier','required','wins','attempts','createdAt'];
    if(!sbExactKeys(a,keys))return false;for(var i=0;i<keys.length;i++)if(a[keys[i]]!==b[keys[i]])return false;return true;
  }
  function focusReceipt(d){
    var msgKeys=['type','schema','sessionId','focused','channel','island','index','word','cpm','tier','required','wins','attempts','createdAt'];
    if(!activeFocus||!sbExactKeys(d,msgKeys)||d.type!=='hsn_sb_focus_complete'||d.schema!==1||d.focused!==true||d.channel!=='crystal'||
       d.sessionId!==activeFocus.sessionId||d.island!==activeFocus.island||d.index!==activeFocus.index||d.word!==activeFocus.word||
       !/^sbf_[a-f0-9]{32}$/.test(String(d.sessionId||''))||!isFinite(d.cpm)||Math.floor(d.cpm)!==d.cpm||d.cpm<10||d.cpm>200||
       !isFinite(d.required)||Math.floor(d.required)!==d.required||!isFinite(d.wins)||Math.floor(d.wins)!==d.wins||
       !isFinite(d.attempts)||Math.floor(d.attempts)!==d.attempts||d.attempts<d.wins||d.attempts>100000||
       !isFinite(d.createdAt)||Math.floor(d.createdAt)!==d.createdAt||d.createdAt<activeFocus.openedAt||d.createdAt>Date.now()+60000)return null;
    var rule=focusRule(d.cpm);if(d.tier!==rule.tier||d.required!==rule.required||d.wins!==d.required)return null;
    if(!window.allW||d.index<0||d.index>=allW.length||String((allW[d.index]||{}).en||'').trim().toLowerCase()!==d.word)return null;
    var pending=sbObject(SB_FOCUS_PENDING_KEY),stored=pending&&pending[d.sessionId];if(!stored||!sameFocusProof(stored,d))return null;
    return stored;
  }
  function settleFocus(r,target){
    var api=window.HansenSpellingProgressV946;if(!api||typeof api.run!=='function'||!activeFocus)return false;
    var meta={mode:'spelling-bee',focused:true,complete:true,exact:true,sessionId:r.sessionId,cpm:r.cpm,botCpm:r.cpm,required:r.required,wins:r.wins,correct:r.wins,attempts:r.attempts};
    var out=null;
    try{out=api.run('crystal',r.index,meta,function(){return typeof window.markAnswer==='function'?window.markAnswer(r.index,true):false;});}catch(e){out=null;}
    if(!out||out.ok!==true||out.consumed!==true)return false;
    activeFocus.consumed=true;
    try{if(target&&typeof target.postMessage==='function')target.postMessage({type:'hsn_sb_focus_ack',sessionId:r.sessionId},'*');}catch(e2){return false;}
    return true;
  }

  window.addEventListener('message', function(e){

    if(!activeFrame || !activeFrame.contentWindow || !e || e.source !== activeFrame.contentWindow) return;
    var d = e && e.data;
    if(d&&d.type==='hsn_sb_focus_complete'){
      var focused=focusReceipt(d);if(focused)settleFocus(focused,e.source);return;
    }
    if(d && d.type === 'hsn_sb_mastery'){

      var masteryReceipt=sbRewardReceipt(d);
      if(masteryReceipt&&masteryReceipt.kind==='mastery'&&window.allW&&masteryReceipt.index>=0&&masteryReceipt.index<allW.length&&
         String((allW[masteryReceipt.index]||{}).en||'').trim().toLowerCase()===masteryReceipt.word)sbAck(e.source,masteryReceipt.rewardId);
      return;
    }
    if(!d || d.type !== 'hsn_sb_reward') return;
    var receipt=sbRewardReceipt(d);if(!receipt)return;
    if(receipt.kind==='mastery')return;
    if(sbAwardReward(receipt))sbAck(e.source,receipt.rewardId);
  });
})();
