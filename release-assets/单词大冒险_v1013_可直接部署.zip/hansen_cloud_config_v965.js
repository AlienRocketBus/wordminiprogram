
window.HANSEN_CLOUD_CONFIG = {
  envId: 'ambitious-d0g1d26xm740dc3d6',
  region: ''
};
