
(function(){
  'use strict';
  if(window.__hansenMuteLoaded) return; window.__hansenMuteLoaded = true;

  var MUTE_KEY = 'hansen_muted';

  function isMuted(){
    try { return localStorage.getItem(MUTE_KEY) === '1'; } catch(e){ return false; }
  }
  function setMuted(on){
    try { localStorage.setItem(MUTE_KEY, on ? '1' : '0'); } catch(e){}
  }

  var allowUntil = 0;
  function openAllowWindow(){ allowUntil = Date.now() + 120; }
  function inAllowWindow(){ return Date.now() < allowUntil; }

  document.addEventListener('click', function(e){

    openAllowWindow();
  }, true);

  document.addEventListener('touchstart', function(e){
    openAllowWindow();
  }, true);

  function hookSoundFns(){
    var hookedAny = false;

    if(typeof window.speak === 'function' && !window.speak.__hansenMuteHooked){
      var origSpeak = window.speak;
      window.speak = function(){

        if(isMuted() && !inAllowWindow()){

          var cb = arguments[2];
          if(typeof cb === 'function'){ try { cb(); } catch(e){} }
          return;
        }
        return origSpeak.apply(this, arguments);
      };
      window.speak.__hansenMuteHooked = true;
      hookedAny = true;
    }

    if(typeof window.playBeep === 'function' && !window.playBeep.__hansenMuteHooked){
      var origBeep = window.playBeep;
      window.playBeep = function(){

        if(isMuted()) return;
        return origBeep.apply(this, arguments);
      };
      window.playBeep.__hansenMuteHooked = true;
      hookedAny = true;
    }

    return hookedAny;
  }

  var tries = 0;
  var hookTimer = setInterval(function(){
    tries++;
    hookSoundFns();

    var speakDone = (typeof window.speak !== 'function') || window.speak.__hansenMuteHooked;
    var beepDone = (typeof window.playBeep !== 'function') || window.playBeep.__hansenMuteHooked;
    if((speakDone && beepDone && (window.speak || window.playBeep)) || tries >= 100){
      clearInterval(hookTimer);
    }
  }, 100);

  function injectToggle(){
    var container = document.getElementById('settingsContent');
    if(!container) return;
    if(document.getElementById('__hansen_mute_toggle')) return;

    var wrap = document.createElement('div');
    wrap.id = '__hansen_mute_toggle';
    wrap.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:12px;background:linear-gradient(135deg,#1e293b,#0f172a);border:2px solid #334155;border-radius:14px;padding:14px 16px;margin:10px 8px;font-family:"Microsoft YaHei",sans-serif';

    var left = document.createElement('div');
    left.style.cssText = 'flex:1;min-width:0';
    left.innerHTML = '<div style="font-size:16px;font-weight:800;color:#fff;display:flex;align-items:center;gap:8px"><span id="__hm_icon" style="font-size:20px">🔊</span><span>一键静音</span></div>' +
      '<div style="font-size:12px;color:#94a3b8;margin-top:4px;line-height:1.5">开启后关闭所有自动声音(朗读/音效)。听力题点喇叭🔊仍可手动听发音。</div>';

    var sw = document.createElement('div');
    sw.id = '__hm_switch';
    sw.style.cssText = 'flex-shrink:0;width:52px;height:30px;border-radius:15px;cursor:pointer;position:relative;transition:background .2s';
    var knob = document.createElement('div');
    knob.style.cssText = 'position:absolute;top:3px;width:24px;height:24px;border-radius:50%;background:#fff;transition:left .2s;box-shadow:0 2px 4px rgba(0,0,0,.3)';
    sw.appendChild(knob);

    function render(){
      var muted = isMuted();
      sw.style.background = muted ? '#22c55e' : '#475569';
      knob.style.left = muted ? '25px' : '3px';
      var icon = document.getElementById('__hm_icon');
      if(icon) icon.textContent = muted ? '🔇' : '🔊';
    }
    sw.addEventListener('click', function(){
      var next = !isMuted();
      setMuted(next);
      render();

      if(!next && typeof window.playBeep === 'function'){

        try { window.playBeep(880, .08); } catch(e){}
      }
      if(typeof window.showToast === 'function'){
        window.showToast(next ? '🔇 已静音 (听力题点喇叭仍可听)' : '🔊 已恢复声音');
      }
    });

    wrap.appendChild(left);
    wrap.appendChild(sw);

    container.insertBefore(wrap, container.firstChild);
    render();
  }

  function watchSettings(){
    var target = document.getElementById('settingsContent');
    if(target){
      injectToggle();
      try {
        var obs = new MutationObserver(function(){ injectToggle(); });
        obs.observe(target, { childList: true, subtree: false });
      } catch(e){}
    }

    try {
      var bodyObs = new MutationObserver(function(){
        if(document.getElementById('settingsContent')) injectToggle();
      });
      bodyObs.observe(document.body, { childList: true, subtree: true });
    } catch(e){}
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', watchSettings);
  } else {
    watchSettings();
  }
})();
