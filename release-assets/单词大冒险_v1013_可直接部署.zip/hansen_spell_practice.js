
(function(){
  'use strict';

  var TIMER_SECONDS = 60;
  var sessionToken = 0;
  var curMask = null;
  var curTimerInterval = null;
  var curWords = [];
  var curIdx = 0;
  var curMode = 'cn';
  var curKeyHandler = null;
  var stats = { correct: 0, assisted: 0, wrong: 0, total: 0 };

  var _hspPrevHtmlOverflow = '';
  var _hspPrevBodyOverflow = '';
  function _hspBlockScroll(e){ if(e && e.cancelable) e.preventDefault(); }

  window.HansenFitSlots = function(el){
    if(!el) return;
    try {

      var inner = el.querySelector('.typing-slots-inner');
      if(!inner) return;
      inner.style.transform = 'none';
      var content = inner.scrollWidth || inner.offsetWidth;
      var vw = window.innerWidth || document.documentElement.clientWidth || 360;
      var avail = el.clientWidth;
      if(!avail || avail < 40 || avail > vw) avail = vw;
      if(content > avail - 2){
        inner.style.transform = 'scale(' + ((avail - 8) / content).toFixed(4) + ')';
      }
    } catch(e){}
  };

  (function(){
    if(window.__hsnKbdTouchSetup) return;
    window.__hsnKbdTouchSetup = true;
    var _lastKey = null;
    function keyAt(t){
      var el = document.elementFromPoint(t.clientX, t.clientY);
      if(!el || !el.closest) return null;
      var k = el.closest('.key');
      if(!k || !k.closest('.keyboard')) return null;
      return k;
    }
    function isLetter(k){ return /^[a-z]$/.test((k.textContent || '').trim()); }
    function fire(k){
      if(!k || k === _lastKey) return;
      _lastKey = k;
      try { k.click(); } catch(e){}
    }
    document.addEventListener('touchstart', function(e){
      var t = e.touches && e.touches[0]; if(!t) return;
      var k = keyAt(t);
      if(k){ _lastKey = null; fire(k); if(e.cancelable) e.preventDefault(); }
    }, { passive: false });
    document.addEventListener('touchmove', function(e){
      var t = e.touches && e.touches[0]; if(!t) return;
      var k = keyAt(t);
      if(k && isLetter(k)){ fire(k); if(e.cancelable) e.preventDefault(); }
    }, { passive: false });
    document.addEventListener('touchend', function(){ _lastKey = null; }, { passive: true });
    document.addEventListener('touchcancel', function(){ _lastKey = null; }, { passive: true });
  })();

  function getWordList(){
    var rawList = null;
    if(window._huReviewContext && window._huReviewContext.wrongsList){
      rawList = window._huReviewContext.wrongsList;
    } else if(typeof window.getCurrentIslandWrongs === 'function'){
      rawList = window.getCurrentIslandWrongs();
    } else {
      var wrongs = (window.S && window.S.wrongs) || {};
      var allW = window.allW || [];
      var arr = [];
      Object.keys(wrongs).forEach(function(idxKey){
        var idx = Number(idxKey);
        var word = allW[idx];
        if(word && wrongs[idxKey] > 0) arr.push(word);
      });
      return arr;
    }
    if(!rawList || !rawList.length) return [];
    return rawList.map(function(item){
      if(item && typeof item === 'object' && item.word && typeof item.word.en === 'string'){
        return item.word;
      }
      return item;
    }).filter(function(w){
      return w && typeof w.en === 'string' && w.en.length > 0;
    });
  }

  function close(){
    sessionToken++;
    if(curTimerInterval){ clearInterval(curTimerInterval); curTimerInterval = null; }
    if(curKeyHandler){ document.removeEventListener('keydown', curKeyHandler); curKeyHandler = null; }

    try {
      if(curMask){ curMask.removeEventListener('touchmove', _hspBlockScroll, { passive: false }); }
      document.documentElement.style.overflow = _hspPrevHtmlOverflow;
      document.body.style.overflow = _hspPrevBodyOverflow;
    } catch(e){}

    var _backToReview = (window._huFromReview && window.HansenReview && typeof window.HansenReview._backFromSpell === 'function');
    try { if(_backToReview){ window.HansenReview._backFromSpell(); } } catch(e){}
    if(curMask && curMask.parentNode){ curMask.remove(); }
    curMask = null;
    curWords = [];
    curIdx = 0;
    stats = { correct: 0, assisted: 0, wrong: 0, total: 0 };

  }

  function esc(s){
    return String(s || '').replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function trySpeak(word){
    try { if(typeof window.speak === 'function'){ window.speak(word); } } catch(e){}
  }

  function renderHspKeyboard(){
    var rows = [['q','w','e','r','t','y','u','i','o','p'],['a','s','d','f','g','h','j','k','l'],['z','x','c','v','b','n','m']];
    var k = '<div class="keyboard" id="hspKbd">';
    k += '<div class="keyboard-row">'; rows[0].forEach(function(l){ k += '<button class="key" data-k="'+l+'" type="button">'+l+'</button>'; }); k += '</div>';
    k += '<div class="keyboard-row indent">'; rows[1].forEach(function(l){ k += '<button class="key" data-k="'+l+'" type="button">'+l+'</button>'; }); k += '</div>';
    k += '<div class="keyboard-row">'; rows[2].forEach(function(l){ k += '<button class="key" data-k="'+l+'" type="button">'+l+'</button>'; }); k += '<button class="key delete" data-act="del" type="button">⌫</button></div>';
    k += '<div class="keyboard-row"><button class="key hint" data-act="hint" type="button">💡</button><button class="key space" data-act="space" type="button">space</button></div>';
    k += '</div>';
    return k;
  }

  function renderQuestion(){
    if(!curMask) return;
    var myToken = sessionToken;

    if(curIdx >= curWords.length){ renderDone(); return; }
    var w = curWords[curIdx];
    if(!w || !w.en){ curIdx++; renderQuestion(); return; }

    var modeIcon  = curMode === 'listen' ? '🎧' : '✍️';
    var modeTitle = curMode === 'listen' ? '听音拼词' : '看汉意拼单词';
    var wordEmoji = w.emoji || (curMode === 'listen' ? '🎧' : '📝');
    var target = (w.en || '').toLowerCase();
    var targetLetters = target.replace(/ /g, '').length;
    var typed = '';
    var hintUsed = false;

    var prompt = curMode === 'listen'
      ? '<div style="font-size:13px;color:#94a3b8">听发音, 拼写单词:</div>'
      : '<div style="font-size:13px;color:#94a3b8">看汉语意思, 拼写单词:</div>';
    var cnDisplay = curMode === 'listen'
      ? '<div style="font-size:15px;color:#cbd5e1;margin-top:4px">提示: '+esc(w.cn || '')+'</div>'
      : '<div class="typing-cn" style="margin:4px 0 2px">'+esc(w.cn || '')+'</div>';
    var speakerBtn = '<button id="hspSpeakBtn" class="listen-btn" type="button">🔊 '+(curMode === 'listen' ? '再听一次' : '点击发音')+'</button>';

    var slotsHtml = '';
    target.split('').forEach(function(ch, i){
      if(ch === ' ') slotsHtml += '<div class="typing-slot space" id="hspSlot'+i+'"></div>';
      else slotsHtml += '<div class="typing-slot" id="hspSlot'+i+'"></div>';
    });

    curMask.innerHTML =

      '<div style="flex-shrink:0;padding:12px 18px 0">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;color:#cbd5e1;font-size:14px;font-weight:700">' +
          '<div>'+ modeIcon +' '+ modeTitle +' '+ (curIdx+1) +' / '+ curWords.length +'</div>' +
          '<button id="hspCloseBtn" type="button" style="background:rgba(255,255,255,0.12);border:0;color:#fff;width:30px;height:30px;border-radius:50%;cursor:pointer;font-size:17px;line-height:1">✕</button>' +
        '</div>' +
        '<div style="margin-top:9px;height:7px;background:rgba(15,23,42,0.6);border-radius:4px;overflow:hidden"><div id="hspTimerFill" style="height:100%;width:100%;background:linear-gradient(90deg,#ef4444 0%,#f59e0b 25%,#eab308 50%,#22c55e 75%,#06b6d4 100%);transition:width 1s linear;border-radius:4px"></div></div>' +
      '</div>' +

      '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:6px 14px;min-height:0">' +
        prompt +
        '<div class="typing-emoji">'+ wordEmoji +'</div>' +
        cnDisplay +
        '<div style="margin:8px 0 2px">'+ speakerBtn +'</div>' +
        '<div class="typing-slots" id="hspSlots"><div class="typing-slots-inner">'+ slotsHtml +'</div></div>' +
        '<div id="hspHint" style="font-size:12px;color:#94a3b8;min-height:16px;margin-top:2px"></div>' +
        '<div style="display:flex;gap:12px;align-items:center;margin-top:5px"><button id="hspSkipBtn" type="button" style="background:rgba(148,163,184,0.2);color:#cbd5e1;border:0;padding:7px 18px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer">跳过</button><span style="font-size:12px;color:#64748b">✓ '+stats.correct+'　✗ '+stats.wrong+'　· 60秒</span></div>' +
      '</div>' +

      renderHspKeyboard();

    var hintEl   = document.getElementById('hspHint');
    var fillEl   = document.getElementById('hspTimerFill');
    var speakBtn = document.getElementById('hspSpeakBtn');
    var closeBtn = document.getElementById('hspCloseBtn');
    var skipBtn  = document.getElementById('hspSkipBtn');
    var kbd      = document.getElementById('hspKbd');

    try { window.HansenFitSlots(document.getElementById('hspSlots')); } catch(e){}

    var answered = false;

    function fillSlots(){
      var idx = 0;
      for(var i = 0; i < target.length; i++){
        var el = document.getElementById('hspSlot'+i);
        if(!el) continue;
        if(target[i] === ' '){ el.textContent = ' '; continue; }
        if(idx < typed.length){ el.textContent = typed[idx]; el.classList.add('filled'); }
        else { el.textContent = ''; el.classList.remove('filled'); }
        idx++;
      }
    }

    function stopTimer(){ if(curTimerInterval){ clearInterval(curTimerInterval); curTimerInterval = null; } }

    function colorSlots(color){
      for(var i = 0; i < target.length; i++){
        var el = document.getElementById('hspSlot'+i);
        if(el && target[i] !== ' '){ el.style.borderBottomColor = color; el.style.color = color; }
      }
    }

    function checkAnswer(){
      if(answered || myToken !== sessionToken) return;
      answered = true;
      stopTimer();
      var isRight = typed.toLowerCase() === target.replace(/ /g, '');
      colorSlots(isRight ? '#22c55e' : '#ef4444');
      if(isRight){
        if(hintUsed){
          stats.assisted++;
          if(hintEl) hintEl.innerHTML = '<span style="color:#fbbf24;font-weight:900">✓ 练习完成</span> <span style="color:#cbd5e1">· 使用了提示，不计独立答对</span>';
        }else{
          stats.correct++;
          if(hintEl) hintEl.innerHTML = '<span style="color:#22c55e;font-weight:900">✓ 独立正确!</span>';
        }
        try { if(window.playCorrect) window.playCorrect(); } catch(e){}
      } else {
        stats.wrong++;
        if(hintEl) hintEl.innerHTML = '<span style="color:#ef4444;font-weight:900">✗</span> 正确: <span style="color:#22c55e;font-family:Consolas,monospace;font-weight:900">'+esc(w.en)+'</span>';
        try { if(window.playWrong) window.playWrong(); } catch(e){}
      }
      setTimeout(function(){ if(myToken !== sessionToken) return; curIdx++; renderQuestion(); }, 1500);
    }

    function skipQuestion(){
      if(answered || myToken !== sessionToken) return;
      answered = true;
      stopTimer();
      stats.wrong++;
      if(hintEl) hintEl.innerHTML = '<span style="color:#94a3b8">已跳过.</span> 答案: <span style="color:#22c55e;font-family:Consolas,monospace;font-weight:900">'+esc(w.en)+'</span>';
      setTimeout(function(){ if(myToken !== sessionToken) return; curIdx++; renderQuestion(); }, 1500);
    }

    function timeUp(){
      if(answered || myToken !== sessionToken) return;
      answered = true;
      stats.wrong++;
      colorSlots('#ef4444');
      if(hintEl) hintEl.innerHTML = '<span style="color:#ef4444;font-weight:900">⏰ 超时!</span> 正确: <span style="color:#22c55e;font-family:Consolas,monospace;font-weight:900">'+esc(w.en)+'</span>';
      try { if(window.playWrong) window.playWrong(); } catch(e){}
      setTimeout(function(){ if(myToken !== sessionToken) return; curIdx++; renderQuestion(); }, 2000);
    }

    function hspKey(l){
      if(answered || myToken !== sessionToken) return;
      if(typed.length >= targetLetters) return;
      typed += l;
      fillSlots();
      try { if(window.playBeep) window.playBeep(700 + typed.length * 40, 0.04); } catch(e){}
      if(typed.length >= targetLetters){ setTimeout(function(){ if(myToken === sessionToken) checkAnswer(); }, 200); }
    }
    function hspDel(){
      if(answered || myToken !== sessionToken) return;
      if(typed.length === 0) return;
      typed = typed.slice(0, -1);
      fillSlots();
    }
    function hspHint(){
      if(answered || myToken !== sessionToken) return;
      hintUsed = true;
      var nonSpace = target.replace(/ /g, '');
      if(typed.length < nonSpace.length){
        typed += nonSpace[typed.length];
        fillSlots();
        if(hintEl){ hintEl.textContent = '💡 已填入一个字母'; setTimeout(function(){ if(hintEl && myToken === sessionToken) hintEl.textContent = ''; }, 1200); }
        if(typed.length >= targetLetters){ setTimeout(function(){ if(myToken === sessionToken) checkAnswer(); }, 200); }
      }
    }

    var startTime = Date.now();
    if(curTimerInterval){ clearInterval(curTimerInterval); }
    curTimerInterval = setInterval(function(){
      if(myToken !== sessionToken){ stopTimer(); return; }
      var elapsed = (Date.now() - startTime) / 1000;
      var remain = Math.max(0, TIMER_SECONDS - elapsed);
      if(fillEl) fillEl.style.width = (remain / TIMER_SECONDS * 100) + '%';
      if(remain <= 0){ stopTimer(); timeUp(); }
    }, 200);

    if(speakBtn) speakBtn.addEventListener('click', function(){ trySpeak(w.en); });
    if(closeBtn) closeBtn.addEventListener('click', close);
    if(skipBtn)  skipBtn.addEventListener('click', skipQuestion);
    if(kbd){
      kbd.addEventListener('click', function(e){
        var btn = e.target;
        if(!btn || !btn.classList || !btn.classList.contains('key')) return;
        if(btn.dataset.k) hspKey(btn.dataset.k);
        else if(btn.dataset.act === 'del') hspDel();
        else if(btn.dataset.act === 'hint') hspHint();

      });
    }

    if(curKeyHandler){ document.removeEventListener('keydown', curKeyHandler); curKeyHandler = null; }
    curKeyHandler = function(e){
      if(myToken !== sessionToken) return;
      if(e.key === 'Backspace'){ e.preventDefault(); hspDel(); }
      else if(e.key === 'Enter'){ e.preventDefault(); if(typed.length >= targetLetters) checkAnswer(); }
      else if(/^[a-zA-Z]$/.test(e.key)){ hspKey(e.key.toLowerCase()); }
    };
    document.addEventListener('keydown', curKeyHandler);

    if(curMode === 'listen'){
      setTimeout(function(){ if(myToken !== sessionToken) return; trySpeak(w.en); }, 400);
    }
  }

  function renderDone(){
    if(!curMask) return;
    if(curKeyHandler){ document.removeEventListener('keydown', curKeyHandler); curKeyHandler = null; }
    var rate = stats.total > 0 ? Math.round(stats.correct / stats.total * 100) : 0;
    var emoji = rate >= 80 ? '🏆' : rate >= 60 ? '👍' : '💪';
    var msg = rate >= 80 ? '出色!' : rate >= 60 ? '不错!' : '继续加油!';
    stopTimerBar();
    curMask.innerHTML =
      '<div style="flex:1;display:flex;align-items:center;justify-content:center;padding:20px">' +
      '<div style="background:linear-gradient(135deg,#1e293b,#0f172a);border:2px solid rgba(251,191,36,0.4);border-radius:20px;padding:36px 28px;max-width:380px;width:calc(100% - 40px);text-align:center;color:#fff">' +
      '<div style="font-size:72px;line-height:1;margin-bottom:14px">'+emoji+'</div>' +
      '<div style="font-size:24px;font-weight:900;color:#fbbf24;margin-bottom:8px">'+msg+'</div>' +
      '<div style="font-size:14px;color:#cbd5e1;margin-bottom:24px">本次练习完成</div>' +
      '<div style="display:flex;justify-content:space-around;background:rgba(15,23,42,0.5);border-radius:14px;padding:18px 0;margin-bottom:24px">' +
      '<div><div style="font-size:28px;font-weight:900;color:#22c55e">'+stats.correct+'</div><div style="font-size:12px;color:#94a3b8;margin-top:4px">独立答对</div></div>' +
      '<div><div style="font-size:28px;font-weight:900;color:#fbbf24">'+stats.assisted+'</div><div style="font-size:12px;color:#94a3b8;margin-top:4px">提示完成</div></div>' +
      '<div><div style="font-size:28px;font-weight:900;color:#ef4444">'+stats.wrong+'</div><div style="font-size:12px;color:#94a3b8;margin-top:4px">答错</div></div>' +
      '<div><div style="font-size:28px;font-weight:900;color:#fbbf24">'+rate+'%</div><div style="font-size:12px;color:#94a3b8;margin-top:4px">正确率</div></div>' +
      '</div>' +
      '<button id="hspDoneBtn" type="button" style="background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#1e293b;border:0;padding:13px 40px;border-radius:12px;font-size:16px;font-weight:900;cursor:pointer;box-shadow:0 4px 14px rgba(251,191,36,0.4)">返回</button>' +
      '</div></div>';
    var doneBtn = document.getElementById('hspDoneBtn');
    if(doneBtn) doneBtn.addEventListener('click', close);
  }

  function stopTimerBar(){
    if(curTimerInterval){ clearInterval(curTimerInterval); curTimerInterval = null; }
  }

  function start(mode){
    var words;
    try { words = getWordList(); }
    catch(e){ console.error('[HansenSpellPractice] 获取词列表失败:', e); words = []; }
    if(!words || words.length === 0){
      if(window.HansenReview && typeof window.HansenReview._toast === 'function'){
        window.HansenReview._toast('暂时没有错题哦, 先去打 boss 吧!');
      } else { alert('暂时没有错题, 先去打 boss 攒错题吧!'); }
      return;
    }
    words = words.filter(function(w){ return w && typeof w.en === 'string' && w.en.length > 0; });
    if(words.length === 0){ alert('错题数据有问题, 请重新打 boss 攒错题'); return; }

    sessionToken++;
    curMode = mode;
    curWords = words.slice();
    curIdx = 0;
    stats = { correct: 0, assisted: 0, wrong: 0, total: words.length };

    curMask = document.createElement('div');
    curMask.id = 'hsp_mask';
    curMask.style.cssText = 'position:fixed;inset:0;z-index:99996;background:linear-gradient(180deg,#0f172a 0%,#1e1b4b 50%,#312e81 100%);display:flex;flex-direction:column;overflow:hidden;overscroll-behavior:none;touch-action:none;font-family:"Microsoft YaHei","PingFang SC",sans-serif';
    document.body.appendChild(curMask);

    try {
      _hspPrevHtmlOverflow = document.documentElement.style.overflow;
      _hspPrevBodyOverflow = document.body.style.overflow;
      document.documentElement.style.overflow = 'hidden';
      document.body.style.overflow = 'hidden';
      curMask.addEventListener('touchmove', _hspBlockScroll, { passive: false });
    } catch(e){}

    var myToken = sessionToken;
    var escHandler = function(e){
      if(e.key === 'Escape' || e.keyCode === 27){
        if(myToken === sessionToken) close();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);

    if(!document.getElementById('hspGlobalCss')){
      var st = document.createElement('style');
      st.id = 'hspGlobalCss';
      st.textContent = '@keyframes hspToastIn{from{opacity:0;transform:translate(-50%,-50%) scale(0.85)}to{opacity:1;transform:translate(-50%,-50%) scale(1)}}';
      document.head.appendChild(st);
    }

    renderQuestion();
  }

  window.HansenSpellPractice = {
    openSpellByCn: function(){ start('cn'); },
    openSpellByListen: function(){ start('listen'); },
    close: close
  };
})();
