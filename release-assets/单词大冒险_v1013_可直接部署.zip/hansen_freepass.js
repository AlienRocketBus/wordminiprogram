
(function(){
  'use strict';
  if(window.__hansenFreepassLoaded){ return; } window.__hansenFreepassLoaded = true;

  var FP_KEY   = 'hansen_freepass_until';
  var TEMP_KEY = 'hansen_card_temp_unlock_until';
  var GEAR_KEY = 'hansen_gear';
  var DAY      = 86400000;

  function now(){ return Date.now(); }
  function getUntil(){ try{ return parseInt(localStorage.getItem(FP_KEY) || '0', 10) || 0; }catch(e){ return 0; } }
  function active(){ return getUntil() > now(); }

  var TRIAL = 3 * DAY;
  var VER_KEY = 'hansen_freepass_ver';
  function ensureStarted(){
    var u = getUntil();
    var ver = ''; try{ ver = localStorage.getItem(VER_KEY) || ''; }catch(e){}
    if(ver !== '72'){
      u = now() + TRIAL;
      try{ localStorage.setItem(FP_KEY, String(u)); localStorage.setItem(VER_KEY, '72'); }catch(e){}
    } else if(u === 0){
      u = now() + TRIAL;
      try{ localStorage.setItem(FP_KEY, String(u)); }catch(e){}
    }
    return u;
  }

  function syncOn(until){

    try{
      if(parseInt(localStorage.getItem(TEMP_KEY) || '0', 10) !== until){
        localStorage.setItem(TEMP_KEY, String(until));
      }
    }catch(e){}

    try{
      var g = JSON.parse(localStorage.getItem(GEAR_KEY) || '{}') || {};
      if(g.trialUntil !== until){
        g.trialUntil = until;
        if(g.trialWeapon == null) g.trialWeapon = (g.weaponLvl | 0) || 0;
        localStorage.setItem(GEAR_KEY, JSON.stringify(g));
      }
    }catch(e){}
  }

  function syncOff(){
    try{
      if(parseInt(localStorage.getItem(TEMP_KEY) || '0', 10) <= now()){
        localStorage.removeItem(TEMP_KEY);
      }
    }catch(e){}
    try{
      var g = JSON.parse(localStorage.getItem(GEAR_KEY) || '{}') || {};
      if(g.trialUntil && g.trialUntil <= now()){
        g.trialUntil = 0; g.trialWeapon = null;
        localStorage.setItem(GEAR_KEY, JSON.stringify(g));
      }
    }catch(e){}
  }

  function hookBoss(){
    var P = window.HansenBossProgress;
    if(P && typeof P.getUnlockedBossLv === 'function' && !P.__fpHooked){
      var orig = P.getUnlockedBossLv;
      P.getUnlockedBossLv = function(){ if(active()) return 20; return orig.apply(this, arguments); };
      P.__fpHooked = true;
    }
    return !!(P && P.__fpHooked);
  }

  function apply(){
    var until = ensureStarted();
    if(active()){ syncOn(until); hookBoss(); }
    else { syncOff(); }
  }

  apply();

  var tries = 0;
  var timer = setInterval(function(){ tries++; if(hookBoss() || tries > 40) clearInterval(timer); }, 150);

  if(typeof document !== 'undefined'){
    document.addEventListener('visibilitychange', function(){ if(!document.hidden) apply(); });
  }

  window.HansenFreepass = {
    active: active,
    remainMs: function(){ return Math.max(0, getUntil() - now()); },
    _end: function(){ try{ localStorage.setItem(FP_KEY, '1'); }catch(e){} syncOff(); }
  };

  window.HansenFreepass = { active: active, until: getUntil };
})();
