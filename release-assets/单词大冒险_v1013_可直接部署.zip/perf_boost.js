
(function(){
  'use strict';

  var OrigAC = window.AudioContext || window.webkitAudioContext;
  var allContexts = [];
  var sharedCtx = null;

  if(OrigAC){
    function HookedAC(){
      try {

        if(sharedCtx && sharedCtx.state !== 'closed') return sharedCtx;
        var ctx = arguments.length ?
          new OrigAC(arguments[0]) :
          new OrigAC();
        sharedCtx = ctx;
        allContexts.push(ctx);
        return ctx;
      } catch(e){
        throw e;
      }
    }
    HookedAC.prototype = OrigAC.prototype;

    try { window.AudioContext = HookedAC; } catch(e){}
    try { window.webkitAudioContext = HookedAC; } catch(e){}
  }

  function resumeAllContexts(){
    for(var i = 0; i < allContexts.length; i++){
      var ctx = allContexts[i];
      try {
        if(ctx && ctx.state && ctx.state !== 'running' && ctx.state !== 'closed'){
          ctx.resume();
        }
      } catch(e){}
    }
  }

  function gcClosedContexts(){
    for(var i = allContexts.length - 1; i >= 0; i--){
      if(allContexts[i].state === 'closed'){
        allContexts.splice(i, 1);
      }
    }
  }

  var firstGestureDone = false;
  function onFirstGesture(){
    if(firstGestureDone) return;
    firstGestureDone = true;
    resumeAllContexts();
  }
  document.addEventListener('touchstart', onFirstGesture, { capture: true, passive: true });
  document.addEventListener('click', onFirstGesture, true);

  var DEBOUNCE_MS = 500;
  var saveTimer = null;
  var origSave = null;
  var saveCallCount = 0;
  var actualWriteCount = 0;
  var hookActive = false;

  function flush(){
    if(saveTimer){
      clearTimeout(saveTimer);
      saveTimer = null;
      if(origSave){
        actualWriteCount++;
        try { origSave.call(window); } catch(e){}
      }
    }
  }

  function debouncedSave(){
    saveCallCount++;
    if(saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(function(){
      saveTimer = null;
      actualWriteCount++;
      try { origSave.call(window); } catch(e){}
    }, DEBOUNCE_MS);
  }

  function tryHook(){
    if(hookActive) return true;
    if(typeof window.save !== 'function') return false;
    if(window.save.__perfBoosted) { hookActive = true; return true; }
    origSave = window.save;
    debouncedSave.__perfBoosted = true;
    window.save = debouncedSave;
    hookActive = true;
    return true;
  }

  if(!tryHook()){
    if(document.readyState === 'loading'){
      document.addEventListener('DOMContentLoaded', tryHook);
    }
    window.addEventListener('load', tryHook);
    var tries = 0;
    var poll = setInterval(function(){
      if(tryHook() || ++tries >= 20){ clearInterval(poll); }
    }, 50);
  }

  window.addEventListener('pagehide', flush);

  window.addEventListener('pageshow', function(e){
    if(e.persisted){
      if(!hookActive || !window.save || !window.save.__perfBoosted){
        hookActive = false;
        tryHook();
      }
    }
  });

  function injectPerfCSS(){
    if(document.getElementById('__perf_boost_style')) return;
    var style = document.createElement('style');
    style.id = '__perf_boost_style';
    style.textContent =

      'body.__perf_paused *, body.__perf_paused *::before, body.__perf_paused *::after {' +
        'animation-play-state: paused !important;' +
      '}' +

      'html, body {' +
        '-webkit-overflow-scrolling: touch !important;' +
      '}' +

      '.screen, .modal-content, [style*="overflow-y"] {' +
        '-webkit-overflow-scrolling: touch !important;' +
        'touch-action: pan-y;' +
      '}' +

      '.island, .stat, .util-card, .daily-card, .modal-content {' +
        'contain: layout style;' +
      '}';
    (document.head || document.documentElement).appendChild(style);

    var TTS_HOSTS = [
      'https://ssl.gstatic.com',
      'https://fanyi.baidu.com',
      'https://dict.youdao.com'
    ];
    for(var i = 0; i < TTS_HOSTS.length; i++){
      try {
        var link = document.createElement('link');
        link.rel = 'preconnect';
        link.href = TTS_HOSTS[i];
        link.crossOrigin = 'anonymous';
        (document.head || document.documentElement).appendChild(link);
      } catch(e){}
    }
  }
  if(document.head){
    injectPerfCSS();
  } else {
    document.addEventListener('DOMContentLoaded', injectPerfCSS);
  }

  document.addEventListener('visibilitychange', function(){
    try {
      if(document.visibilityState === 'hidden'){
        flush();
        if(document.body) document.body.classList.add('__perf_paused');
      } else {
        resumeAllContexts();
        gcClosedContexts();
        if(document.body) document.body.classList.remove('__perf_paused');
      }
    } catch(e){}
  });

  window.addEventListener('pageshow', function(e){
    try {
      if(e.persisted){
        resumeAllContexts();
      }
      if(document.body) document.body.classList.remove('__perf_paused');
    } catch(_){}
  });

  var allIntervals = [];
  var origSetInterval = window.setInterval;
  var origClearInterval = window.clearInterval;
  function reportIntervalError(error){

    try{
      if(typeof window.reportError === 'function'){
        window.reportError(error);
        return;
      }
    }catch(_reportErrorFailure){}
    try{
      var event;
      if(typeof ErrorEvent === 'function'){
        event = new ErrorEvent('error', {
          message: String(error && error.message || error),
          error: error,
          filename: 'perf_boost.js'
        });
      }else{
        event = new Event('error');
        event.error = error;
      }
      window.dispatchEvent(event);
    }catch(_dispatchFailure){
      try{ console.error('[perf_boost interval]', error); }catch(_consoleFailure){}
    }
  }
  window.setInterval = function(fn, ms){

    var actualMs = ms;
    if(ms === 200) actualMs = 1000;

    var wrapped = function(){

      if(document.visibilityState === 'hidden') return;
      try { fn.apply(this, arguments); } catch(e){ reportIntervalError(e); }
    };
    var id = origSetInterval.call(window, wrapped, actualMs);
    allIntervals.push(id);
    return id;
  };
  window.clearInterval = function(id){
    var idx = allIntervals.indexOf(id);
    if(idx >= 0) allIntervals.splice(idx, 1);
    return origClearInterval.call(window, id);
  };

  if(typeof Audio !== 'undefined'){
    var OrigAudio = Audio;
    var activeAudios = [];
    function HookedAudio(src){

      for(var i = 0; i < activeAudios.length; i++){
        try {
          var old = activeAudios[i];
          if(old && !old.paused && !old.ended){
            old.pause();

          }
        } catch(e){}
      }

      activeAudios = activeAudios.filter(function(a){
        if(!a) return false;
        if(a.ended) return false;
        if(!a.src || a.src === '') return false;
        return true;
      });

      var a = new OrigAudio(src);
      activeAudios.push(a);

      a.addEventListener('ended', function(){
        var idx = activeAudios.indexOf(a);
        if(idx >= 0) activeAudios.splice(idx, 1);
      });
      a.addEventListener('error', function(){
        var idx = activeAudios.indexOf(a);
        if(idx >= 0) activeAudios.splice(idx, 1);
      });
      return a;
    }
    HookedAudio.prototype = OrigAudio.prototype;
    try { window.Audio = HookedAudio; } catch(e){}
  }

  function hookSpeak(){
    if(typeof window.speak !== 'function') return false;
    if(window.speak.__cbSafe) return true;
    var origSpeak = window.speak;
    var safeSpeak = function(t, r, cb){

      var invalid = !t || (typeof t === 'string' && !t.trim());
      if(invalid){
        if(typeof cb === 'function'){
          try { cb(); } catch(e){}
        }
        return;
      }

      return origSpeak.call(this, t, r, cb);
    };
    safeSpeak.__cbSafe = true;
    window.speak = safeSpeak;
    return true;
  }

  if(!hookSpeak()){
    if(document.readyState === 'loading'){
      document.addEventListener('DOMContentLoaded', hookSpeak);
    }
    window.addEventListener('load', hookSpeak);
    var st = 0;
    var sp = setInterval(function(){
      if(hookSpeak() || ++st >= 20){ clearInterval(sp); }
    }, 50);
  }

  window.__perfDebug = function(){
    return {
      version: 'v11',
      hookActive: hookActive,
      saveCallCount: saveCallCount,
      actualWriteCount: actualWriteCount,
      compressionRatio: saveCallCount > 0 ? (actualWriteCount / saveCallCount).toFixed(3) : 'N/A',
      pendingWrite: !!saveTimer,
      debounceMs: DEBOUNCE_MS,
      trackedAudioContexts: allContexts.length,
      audioContextStates: allContexts.map(function(c){ return c.state; }),
      perfCssInjected: !!document.getElementById('__perf_boost_style'),
      currentlyPaused: document.body ? document.body.classList.contains('__perf_paused') : false,
      speakHooked: !!(window.speak && window.speak.__cbSafe)
    };
  };
})();
