
(function () {
  'use strict';

  var NOTICE = '单词大冒险 © 2026 Hansen。请尊重作者版权；学习摘录与辅助功能保持可用。';

  try {
    document.documentElement.setAttribute('data-hansen-copyright', '2026 Hansen');
  } catch (e) {}

  window.HansenCopyright = Object.freeze({
    version: 'v3',
    notice: NOTICE,
    blocksCopy: false,
    blocksSelection: false,
    blocksContextMenu: false,
    blocksPrint: false
  });

  window.__copyProtectDebug = function () {
    return {
      version: 'v3',
      accessibleMode: true,
      blocksNativeBrowserFeatures: false
    };
  };
})();
