
(function(){
  'use strict';
  var state = window.__hansenSwUpgradeGateV944 = {
    version: 1017,
    ready: false,
    controller: 'checking'
  };
  try {
    if (!('serviceWorker' in navigator) || location.protocol === 'file:') {
      state.ready = true;
      state.controller = 'unsupported';
      return;
    }

    var current = navigator.serviceWorker.controller;
    if (!current) {

      state.ready = true;
      state.controller = 'none';
      navigator.serviceWorker.register('./sw_v944.js', {
        scope: './',
        updateViaCache: 'none'
      }).catch(function(error){
        try { console.warn('[v960升级门] Service Worker 注册失败:', error && error.message); } catch (_) {}
      });
      return;
    }

    var controllerPath = '';
    try { controllerPath = new URL(current.scriptURL, location.href).pathname; } catch (_) {}
    if (/\/sw_v944\.js$/.test(controllerPath)) {
      state.ready = true;
      state.controller = 'sw_v944.js';
      return;
    }

    state.controller = 'legacy';
    var gate = new URL('_sw_upgrade_v944.html', location.href);
    gate.searchParams.set('return', location.href);
    try { window.stop(); } catch (_) {}
    try { location.replace(gate.href); } catch (_) { location.href = gate.href; }

    try {
      document.open();
      var safeRoot = document.createElement('html');
      safeRoot.innerHTML = '<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>正在安全升级</title><style>html,body{height:100%;margin:0;background:#0c1538;color:#fff;font:16px system-ui,sans-serif}body{display:grid;place-items:center;text-align:center;padding:24px;box-sizing:border-box}</style></head><body><main>正在安全升级到 v960，请稍候…</main></body>';
      if (document.documentElement) document.replaceChild(safeRoot, document.documentElement);
      else document.appendChild(safeRoot);
      document.close();
    } catch (_) {}
  } catch (error) {

    try {
      if (navigator.serviceWorker && navigator.serviceWorker.controller) {
        var fallback = new URL('_sw_upgrade_v944.html', location.href);
        fallback.searchParams.set('return', location.href);
        location.replace(fallback.href);
      } else {
        state.ready = true;
        state.controller = 'unavailable';
      }
    } catch (_) {
      state.ready = !navigator.serviceWorker || !navigator.serviceWorker.controller;
      state.controller = state.ready ? 'unavailable' : 'blocked';
    }
  }
})();
