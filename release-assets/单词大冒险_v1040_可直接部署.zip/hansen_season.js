
(function(){
  'use strict';
  if(window.__hansenSeasonLoaded) return; window.__hansenSeasonLoaded = true;

  var SEASONS = [
    {
      id: 'S1',
      name: '第一赛季 · 星海觉醒',
      start: '2026-05-01',
      end:   '2026-12-31',
      card: {
        name: '星海女帝·赛尔娅',
        img:  'bosses/saelya_hd.webp',
        rarity: 'legend',
        desc: '星海创世之初降临的女帝，只在第一赛季出现，绝版后不再获得。'
      },
      mechanic: {
        name: '星海连击',
        desc: '本赛季新玩法（示范版：连续答对触发星海加成）。正式机制由开发接入。',
        key: 'star_combo'
      },
      pointMilestones: [
        { points: 200,  reward: '🪙 +80 金币 · ⚡加速30分钟', type:'coinboost', coin:80,  boost:30 },
        { points: 500,  reward: '🪙 +150 金币 · ⚡加速60分钟', type:'coinboost', coin:150, boost:60 },
        { points: 1000, reward: '🎴 赛季限定卡',     type:'card',  value:'S1' },
        { points: 1500, reward: '👑 赛季称号',       type:'title', value:'星海征服者' }
      ],

      bossCards: [
        { id:'S1B1', name:'铸星者·原初匠人',       img:'bosses/starmaker.webp',  rarity:'legend', bg:'radial-gradient(circle at 50% 30%,#3a2a16,#0d0a05)', bgImg:'bosses_bg/starmaker.webp', desc:'星海创世的第一锤。万千星辰皆出自他的熔炉，原初的造物之力从未止息。' },
        { id:'S1B2', name:'统御天使·圣光之翼',     img:'bosses/lightangel.webp', rarity:'legend', bg:'radial-gradient(circle at 50% 30%,#3a3420,#0d0c06)', bgImg:'bosses_bg/lightangel.webp', desc:'展开圣光之翼降下裁决。万道光柱即是他的旨意，无人能在审判之光下隐藏。' },
        { id:'S1B3', name:'无光之渊·暗噬君主',     img:'bosses/abysslord.webp',  rarity:'legend', bg:'radial-gradient(circle at 50% 30%,#281a3a,#08060d)', bgImg:'bosses_bg/abysslord.webp', desc:'渊狱深处的吞噬者。被暗链拖入的灵魂，永坠无光之渊再难回返。' },
        { id:'S1B4', name:'时之君主·克罗诺斯之影', img:'bosses/timelord.webp',   rarity:'legend', bg:'radial-gradient(circle at 50% 30%,#16332e,#06100d)', bgImg:'bosses_bg/timelord.webp', desc:'十二时钟为他疯转。时间在他面前停滞、倒流、又终结，是为终焉时刻。' },
        { id:'S1B5', name:'终末观测者·边界守夜人', img:'bosses/observer.webp',   rarity:'legend', bg:'radial-gradient(circle at 50% 30%,#16333e,#060e10)', bgImg:'bosses_bg/observer.webp', desc:'守望宇宙边界的观测者。星图烙印连起命运的回响，终末的目光从不闭合。' }
      ]
    }

  ];

  var DATA_KEY = 'hansen_season_data';

  var MAX_SEASON_POINTS = 1000000;
  var FORMS = {
    S1: [
      'bosses/saelya.webp',
      'bosses/saelya2.webp',
      'bosses/saelya3.webp'
    ]
  };
  var BGS = [
    'radial-gradient(circle at 50% 26%,#3a2c66,#150f2c 72%)',
    'radial-gradient(circle at 50% 26%,#1c2140,#06060f 72%)',
    'radial-gradient(circle at 50% 24%,#5c3d18,#241405 74%)',
    'linear-gradient(165deg,#0c423c,#0a2740 55%,#1a0d3a)',
    'radial-gradient(circle at 50% 26%,#4a1f74,#1a0a30 72%)',
    'radial-gradient(circle at 50% 26%,#163a6e,#08152f 72%)',
    'radial-gradient(circle at 50% 26%,#5e1d2c,#250a13 72%)',
    'radial-gradient(circle at 50% 26%,#dcd8ec,#9a96bc 74%)'
  ];
  var SEASON_BY_ID = Object.create(null);
  var CARD_ID_OK = Object.create(null);
  var MILESTONE_OK = Object.create(null);
  for(var _si=0;_si<SEASONS.length;_si++){
    var _season = SEASONS[_si];
    SEASON_BY_ID[_season.id] = _season;
    CARD_ID_OK[_season.id] = true;
    MILESTONE_OK[_season.id] = Object.create(null);
    var _milestones = Array.isArray(_season.pointMilestones) ? _season.pointMilestones : [];
    for(var _mi=0;_mi<_milestones.length;_mi++) MILESTONE_OK[_season.id][_milestones[_mi].points] = true;
    var _bossCards = Array.isArray(_season.bossCards) ? _season.bossCards : [];
    for(var _bi=0;_bi<_bossCards.length;_bi++) CARD_ID_OK[_bossCards[_bi].id] = true;
  }

  function isExactIntInRange(v, min, max){
    return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= min && v <= max;
  }
  function safeStoredIndex(v, length){
    return isExactIntInRange(v, 0, length - 1) ? v : 0;
  }

  function loadData(){
    try {
      var raw = localStorage.getItem(DATA_KEY);
      if(raw){ var d = JSON.parse(raw); if(d && typeof d==='object') return normalize(d); }
    } catch(e){}
    return normalize({});
  }
  function normalize(d){
    d = (d && typeof d === 'object' && !Array.isArray(d)) ? d : {};
    var out = { points:{}, unlockedCards:[], claimedMilestones:{} };
    var rawPoints = (d.points && typeof d.points === 'object' && !Array.isArray(d.points)) ? d.points : {};
    var rawClaimed = (d.claimedMilestones && typeof d.claimedMilestones === 'object' && !Array.isArray(d.claimedMilestones)) ? d.claimedMilestones : {};

    for(var i=0;i<SEASONS.length;i++){
      var sid = SEASONS[i].id;
      var pointValue = rawPoints[sid];
      out.points[sid] = isExactIntInRange(pointValue, 0, MAX_SEASON_POINTS) ? pointValue : 0;

      var srcMilestones = Array.isArray(rawClaimed[sid]) ? rawClaimed[sid] : [];
      var seenMilestones = Object.create(null);
      var allowedMilestones = MILESTONE_OK[sid];
      out.claimedMilestones[sid] = [];
      for(var m=0;m<srcMilestones.length;m++){
        var milestone = srcMilestones[m];
        if(isExactIntInRange(milestone, 0, MAX_SEASON_POINTS) && allowedMilestones[milestone] && !seenMilestones[milestone]){
          seenMilestones[milestone] = true;
          out.claimedMilestones[sid].push(milestone);
        }
      }
    }

    var rawCards = Array.isArray(d.unlockedCards) ? d.unlockedCards : [];
    var seenCards = Object.create(null);
    for(var c=0;c<rawCards.length;c++){
      var cardId = rawCards[c];
      if(typeof cardId === 'string' && CARD_ID_OK[cardId] && !seenCards[cardId]){
        seenCards[cardId] = true;
        out.unlockedCards.push(cardId);
      }
    }
    return out;
  }
  function saveData(d){
    try { localStorage.setItem(DATA_KEY, JSON.stringify(normalize(d))); } catch(e){}
  }

  function todayStr(){
    var d = new Date();
    var m = (d.getMonth()+1), day = d.getDate();
    return d.getFullYear() + '-' + (m<10?'0':'')+m + '-' + (day<10?'0':'')+day;
  }
  function getCurrentSeason(){
    var t = todayStr();
    for(var i=0;i<SEASONS.length;i++){
      if(t >= SEASONS[i].start && t <= SEASONS[i].end) return SEASONS[i];
    }
    return null;
  }
  function getSeasonById(id){
    return (typeof id === 'string' && SEASON_BY_ID[id]) ? SEASON_BY_ID[id] : null;
  }

  function getPastSeasons(){
    var t = todayStr();
    var d = loadData();
    var out = [];
    for(var i=0;i<SEASONS.length;i++){
      var s = SEASONS[i];
      if(t > s.end){
        out.push({
          id: s.id,
          name: s.name,
          card: s.card,
          owned: d.unlockedCards.indexOf(s.id) >= 0
        });
      }
    }
    return out;
  }

  function daysLeft(season){
    if(!season) return 0;
    try {
      var end = new Date(season.end + 'T23:59:59');
      var now = new Date();
      var diff = Math.ceil((end - now) / 86400000);
      return diff > 0 ? diff : 0;
    } catch(e){ return 0; }
  }

  function addSeasonPoints(){ return false; }

  function unlockCardInData(d, seasonId){
    if(typeof seasonId !== 'string' || !CARD_ID_OK[seasonId]) return false;
    if(d.unlockedCards.indexOf(seasonId) < 0){
      d.unlockedCards.push(seasonId);
      return true;
    }
    return false;
  }

  function unlockCard(seasonId){
    var d = loadData();
    unlockCardInData(d, seasonId);
    saveData(d);
  }
  function hasCard(seasonId){
    return typeof seasonId === 'string' && !!CARD_ID_OK[seasonId] && loadData().unlockedCards.indexOf(seasonId) >= 0;
  }

  function tempUnlockAll(){
    try{
      if(parseInt(localStorage.getItem('hansen_card_temp_unlock_until')||'0',10) > Date.now()) return true;
      if(localStorage.getItem('hansen_admin_clearall_on')==='1') return true;
      return false;
    }catch(e){ return false; }
  }

  function totalCardCount(){ var n=0; for(var i=0;i<SEASONS.length;i++){ n += 1 + (Array.isArray(SEASONS[i].bossCards)?SEASONS[i].bossCards.length:0); } return n; }
  function ownedCardCount(){ if(tempUnlockAll()) return totalCardCount(); var d=loadData(),n=0; for(var i=0;i<SEASONS.length;i++){ var s=SEASONS[i]; if(d.unlockedCards.indexOf(s.id)>=0)n++; if(Array.isArray(s.bossCards)){ for(var j=0;j<s.bossCards.length;j++){ if(d.unlockedCards.indexOf(s.bossCards[j].id)>=0)n++; } } } return n; }
  function findBossCard(id){ for(var i=0;i<SEASONS.length;i++){ var bc=SEASONS[i].bossCards; if(Array.isArray(bc)){ for(var j=0;j<bc.length;j++){ if(bc[j].id===id) return bc[j]; } } } return null; }

  function hookScoreEvents(){
    var done = true;

    if(typeof window.bossVictory === 'function' && !window.bossVictory.__seasonHooked){
      var origBV = window.bossVictory;
      var lastVictoryAt = 0;
      window.bossVictory = function(){
        var now = Date.now();

        if(now - lastVictoryAt < 3000){
          return;
        }
        lastVictoryAt = now;
        return origBV.apply(this, arguments);
      };
      window.bossVictory.__seasonHooked = true;
    } else if(typeof window.bossVictory !== 'function'){ done = false; }

    return done;
  }

  window.HansenSeason = {
    current: getCurrentSeason,
    daysLeft: function(){ return daysLeft(getCurrentSeason()); },
    getPoints: function(){ var s=getCurrentSeason(); return s ? (loadData().points[s.id]||0) : 0; },
    hasCard: hasCard,
    unlockCard: unlockCard,
    allSeasons: function(){ return SEASONS.slice(); },
    pastSeasons: getPastSeasons,
    addPoints: addSeasonPoints,
    pointsReadOnly: true,
    nextMilestone: function(){ return null; },
    data: loadData
  };

  function isHomePage(){
    try {
      var path = (location.pathname || '').toLowerCase();
      return !/island_\w+\.html/.test(path);
    } catch(e){ return false; }
  }
  var RARITY_STYLE = {
    legend: { name:'传说', color:'#fbbf24', glow:'rgba(251,191,36,.6)' },
    epic:   { name:'史诗', color:'#c084fc', glow:'rgba(192,132,252,.5)' },
    rare:   { name:'稀有', color:'#60a5fa', glow:'rgba(96,165,250,.5)' }
  };

  function buildEntryButton(){
    try{
      if(document.getElementById('hsnSeasonEntry')) return;
      var anyCard=document.querySelector('.util-card'); if(!anyCard||!anyCard.parentElement) return;
      var entry=document.createElement('div');
      entry.className='util-card'; entry.id='hsnSeasonEntry';
      entry.setAttribute('onclick','__hsnOpenSeason()');
      entry.innerHTML='<span class="u-icon">🏆</span><div class="u-label">赛季</div>';
      anyCard.parentElement.insertBefore(entry, anyCard);
    }catch(e){}
  }

  function buildHallEntry(){
    try{ var old=document.getElementById('hsnHallCard'); if(old&&old.parentNode) old.parentNode.removeChild(old); }catch(e){}
  }

  function canAutoWarmLandMap(){
    try{
      if(window.HansenPreloadPolicy && typeof window.HansenPreloadPolicy.canBackgroundDownload==='function'){
        return !!window.HansenPreloadPolicy.canBackgroundDownload();
      }
      var c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;
      return !!c && !c.saveData && c.effectiveType==='4g' && navigator.onLine!==false &&
        (!document.visibilityState || document.visibilityState==='visible') && !document.hidden;
    }catch(e){ return false; }
  }
  function warmLandMap(userIntent){
    try{
      if(window.__hansenLandMapWarmAttempted) return window.__hansenLandMapWarmPromise||null;
      if(!userIntent && !canAutoWarmLandMap()) return null;
      if(navigator.onLine===false || document.visibilityState==='hidden' || document.visibilityState==='prerender' || document.hidden) return null;
      window.__hansenLandMapWarmAttempted=true;
      var p=fetch('land_map.html',{cache:'force-cache',credentials:'same-origin'}).catch(function(){ return null; });
      window.__hansenLandMapWarmPromise=p;
      return p;
    }catch(e){ return null; }
  }
  function armLandMapWarm(bar){
    if(!bar || bar.__hansenLandMapWarmArmed) return;
    bar.__hansenLandMapWarmArmed=true;
    var intent=function(){ warmLandMap(true); };
    try{ bar.addEventListener('pointerdown',intent,{passive:true,once:true}); }catch(e){}
    try{ bar.addEventListener('touchstart',intent,{passive:true,once:true}); }catch(e){}
    try{ bar.addEventListener('focus',intent,{once:true}); }catch(e){}
    if(!window.__hansenLandMapWarmScheduled){
      window.__hansenLandMapWarmScheduled=true;
      var auto=function(){ warmLandMap(false); };
      try{
        if(window.requestIdleCallback) window.requestIdleCallback(auto,{timeout:5000});
        else setTimeout(auto,2500);
      }catch(e){ setTimeout(auto,2500); }
    }
  }

  function buildProgressBar(){
    try{
      var season=getCurrentSeason(); if(!season) return;
      var anchor=document.querySelector('.islands'); if(!anchor||!anchor.parentElement) return;
      var d=loadData();
      var hasCard=(d.unlockedCards||[]).indexOf(season.id)>=0;

      var statusLine = hasCard
        ? '<span style="color:#fcd34d">👑 已征服 · 星海限定卡已收入卡册</span>'
        : '<span style="color:#c4b5fd">通关副本 · 赢取星海限定收藏卡 →</span>';
      var inner=
        '<div class="hsn-ex-glow"></div>'+
        '<div style="position:relative;z-index:2;display:flex;align-items:center;gap:14px">'+
          '<div class="hsn-ex-orb">🌌</div>'+
          '<div style="flex:1;min-width:0">'+
            '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">'+
              '<span class="hsn-ex-tag">✦ 番外篇 EXTRA</span>'+
              '<span style="font-size:11px;color:#94a3b8">第 19 座秘境</span>'+
            '</div>'+
            '<div style="font-size:19px;font-weight:900;color:#fff;margin:5px 0 3px;letter-spacing:.5px;text-shadow:0 2px 10px rgba(124,58,237,.6)">星海觉醒</div>'+
            '<div style="font-size:12.5px;line-height:1.4">'+statusLine+'</div>'+
          '</div>'+
          '<div class="hsn-ex-enter">进入<div style="font-size:9px;margin-top:1px;opacity:.85">副本</div></div>'+
        '</div>';
      var bar=document.getElementById('hsnSeasonBar');
      if(bar){ bar.innerHTML=inner; armLandMapWarm(bar); return; }

      if(!document.getElementById('hsnExtraCss')){
        var st=document.createElement('style'); st.id='hsnExtraCss';
        st.textContent=
          '#hsnSeasonBar{position:relative;max-width:640px;margin:22px auto 16px;'+
            'background:linear-gradient(135deg,#1e1b4b 0%,#3b0764 45%,#0c1538 100%);'+
            'border:1.5px solid rgba(196,181,253,.45);border-radius:18px;padding:16px 18px;cursor:pointer;'+
            'font-family:-apple-system,"Microsoft YaHei",sans-serif;overflow:hidden;'+
            'box-shadow:0 8px 30px rgba(59,7,100,.5),inset 0 1px 0 rgba(255,255,255,.08);'+
            'transition:transform .18s,box-shadow .18s}'+
          '#hsnSeasonBar:active{transform:scale(.985)}'+
          '.hsn-ex-glow{position:absolute;top:-40%;right:-10%;width:220px;height:220px;'+
            'background:radial-gradient(circle,rgba(168,85,247,.45),transparent 65%);pointer-events:none;z-index:1}'+
          '.hsn-ex-orb{flex-shrink:0;width:52px;height:52px;border-radius:14px;'+
            'background:radial-gradient(circle at 40% 30%,#7c3aed,#2e1065);'+
            'display:flex;align-items:center;justify-content:center;font-size:28px;'+
            'box-shadow:0 4px 16px rgba(124,58,237,.55),inset 0 2px 6px rgba(255,255,255,.2)}'+
          '.hsn-ex-tag{font-size:11px;font-weight:900;color:#0c1538;background:linear-gradient(90deg,#fcd34d,#f59e0b);'+
            'padding:2px 9px;border-radius:8px;letter-spacing:1px}'+
          '.hsn-ex-enter{flex-shrink:0;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#3b0764;'+
            'font-weight:900;font-size:14px;text-align:center;padding:9px 14px;border-radius:12px;'+
            'box-shadow:0 4px 12px rgba(251,191,36,.4);line-height:1.1}';
        (document.head||document.documentElement).appendChild(st);
      }
      bar=document.createElement('div');
      bar.id='hsnSeasonBar';
      bar.setAttribute('onclick',"(typeof openIsland==='function'?openIsland('land_map.html'):(window.(function(){ if(window.HansenRoom){ HansenRoom.open('land'); return; } location.href='land_map.html'; })()))");
      bar.innerHTML=inner;
      anchor.parentElement.insertBefore(bar, anchor);
      armLandMapWarm(bar);
    }catch(e){}
  }
  window.__hsnOpenSeason = openPanel;
  window.__hsnOpenHall = openHall;

  function openPanel(){
    var season = getCurrentSeason();
    var d = loadData();

    var islandBtn =
      '<div id="__hs_island_entry" style="background:linear-gradient(135deg,#1e1b4b,#4c1d95);border:2px solid #fbbf24;border-radius:16px;padding:15px 16px;margin-bottom:14px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;box-shadow:0 0 20px rgba(124,58,237,.35)">'+
        '<div style="display:flex;align-items:center;gap:12px">'+
          '<div style="font-size:32px">📖</div>'+
          '<div><div style="font-size:16px;font-weight:900;color:#fff">星海学习岛</div>'+
          '<div style="font-size:12px;color:#c4b5fd;margin-top:2px">学会星海单词 · 挑战女帝赛尔娅</div></div>'+
        '</div>'+
        '<div style="font-size:20px;color:#fbbf24">›</div>'+
      '</div>';

    var mask = document.createElement('div');
    mask.id = '__hs_season_panel';
    mask.style.cssText = 'position:fixed;inset:0;z-index:2147483520;background:rgba(12,21,56,.85);display:flex;align-items:center;justify-content:center;padding:18px;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;overflow-y:auto';

    var html;
    if(!season){
      html = '<div style="text-align:center;color:#cbd5e1;padding:40px 20px">'+
        '<div style="font-size:54px;margin-bottom:14px">🏁</div>'+
        '<div style="font-size:18px;font-weight:800;color:#fff;margin-bottom:8px">星海秘境</div>'+
        '<div style="font-size:14px">秘境即将开启，敬请期待！</div>'+islandBtn+'</div>';
    } else {
      var pts = d.points[season.id] || 0;
      var dl = daysLeft(season);
      var r = RARITY_STYLE[season.card.rarity] || RARITY_STYLE.rare;
      var hasThisCard = d.unlockedCards.indexOf(season.id) >= 0;
      var pPref = readCardPref(season.id);

      var pImg = (pPref&&pPref.formPng)?pPref.formPng:'bosses/saelya.webp';
      var pBg  = (pPref&&pPref.bgCss)?pPref.bgCss:'radial-gradient(circle at 50% 30%,#2a2350,#0d0a22)';

      var milestonesHtml = '';
      (season.pointMilestones||[]).forEach(function(m){
        var claimed = (d.claimedMilestones[season.id]||[]).indexOf(m.points) >= 0;
        var reached = pts >= m.points;
        var pct = Math.min(100, Math.round(pts/m.points*100));
        milestonesHtml +=
          '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">'+
            '<div style="flex-shrink:0;width:54px;font-size:12px;color:'+(reached?'#fbbf24':'#64748b')+';font-weight:800">'+m.points+'分</div>'+
            '<div style="flex:1;height:8px;background:#1e293b;border-radius:4px;overflow:hidden">'+
              '<div style="height:100%;width:'+pct+'%;background:linear-gradient(90deg,#fbbf24,#f59e0b);border-radius:4px"></div>'+
            '</div>'+
            '<div style="flex-shrink:0;font-size:12px;color:'+(claimed?'#22c55e':'#64748b')+';font-weight:700;min-width:70px;text-align:right">'+(claimed?'✅ 旧版已领取':'旧版已停用')+'</div>'+
          '</div>';
      });

      html =
        '<div style="width:100%;max-width:360px;background:linear-gradient(160deg,#1a2660,#0c1538);border:2px solid rgba(251,191,36,.4);border-radius:22px;box-shadow:0 18px 50px rgba(0,0,0,.6);padding:22px 20px;max-height:86vh;overflow-y:auto">'+
          '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px">'+
            '<div style="font-size:19px;font-weight:900;color:#fff">'+season.name+'</div>'+
            '<div id="__hs_close" style="font-size:22px;color:#64748b;cursor:pointer;line-height:1;padding:0 4px">×</div>'+
          '</div>'+
          '<div style="font-size:13px;color:#fbbf24;font-weight:700;margin-bottom:16px">⏳ 本赛季还剩 '+dl+' 天</div>'+
          islandBtn+
          '<div'+(hasThisCard?' id="__hs_curcard" data-season="'+season.id+'"':'')+' style="background:linear-gradient(135deg,'+r.glow+',rgba(12,21,56,.3));border:2px solid '+r.color+';border-radius:16px;padding:16px;text-align:center;margin-bottom:14px;box-shadow:0 0 20px '+r.glow+';'+(hasThisCard?'cursor:pointer':'')+'">'+
            '<div style="font-size:11px;color:'+r.color+';font-weight:800;letter-spacing:1px;margin-bottom:6px">★ '+r.name+'限定卡 ★</div>'+
            (hasThisCard
              ? '<div class="__hs_panel_thumb" style="width:96px;height:128px;margin:0 auto 8px;border-radius:10px;overflow:hidden;background:'+pBg+'"><img src="'+pImg+'?v=1040" onerror="this.onerror=null;this.src=\'bosses/saelya.webp?v=1040\'" style="width:100%;height:100%;object-fit:contain;object-position:center bottom" alt=""></div>'
              : '<div style="font-size:46px;margin-bottom:6px">❓</div>')+
            '<div style="font-size:17px;font-weight:900;color:#fff;margin-bottom:4px">'+(hasThisCard?season.card.name:'？？？')+'</div>'+
            '<div style="font-size:12px;color:#cbd5e1;line-height:1.5">'+(hasThisCard?'✨ 已收入囊中 · 点击进入全屏观赏':season.card.desc)+'</div>'+
          '</div>'+
          '<div style="background:rgba(96,165,250,.1);border-radius:12px;padding:12px;margin-bottom:16px">'+
            '<div style="font-size:13px;font-weight:800;color:#60a5fa;margin-bottom:4px">🎮 本赛季新玩法：'+season.mechanic.name+'</div>'+
            '<div style="font-size:12px;color:#cbd5e1;line-height:1.5">'+season.mechanic.desc+'</div>'+
          '</div>'+
          '<div style="text-align:center;margin-bottom:16px">'+
            '<div style="font-size:12px;color:#94a3b8;margin-bottom:2px">历史赛季积分（只读）</div>'+
            '<div style="font-size:30px;font-weight:900;color:#fbbf24">'+pts+'</div>'+
            '<div style="font-size:11px;color:#64748b">v941 起不再累加，也不再发放旧里程碑奖励</div>'+
          '</div>'+
          '<div style="font-size:13px;font-weight:800;color:#fff;margin-bottom:10px">📜 旧版里程碑（历史记录）</div>'+
          milestonesHtml +
          (function(){
            var allCount = totalCardCount();
            var ownedCount = ownedCardCount();
            return '<div id="__hs_hall_entry" style="margin-top:16px;background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.25);border-radius:12px;padding:13px 15px;cursor:pointer;display:flex;justify-content:space-between;align-items:center">'+
              '<div><div style="font-size:13px;font-weight:800;color:#fbbf24">🏛️ 神秘殿堂</div>'+
              '<div style="font-size:11px;color:#94a3b8;margin-top:2px">历代赛季限定卡 · 已收藏 '+ownedCount+'/'+allCount+'</div></div>'+
              '<div style="font-size:18px;color:#fbbf24">›</div>'+
            '</div>';
          })() +
        '</div>';
    }

    mask.innerHTML = html;
    document.body.appendChild(mask);

    function close(){ if(mask.parentNode) mask.parentNode.removeChild(mask); }
    var closeBtn = document.getElementById('__hs_close');
    if(closeBtn) closeBtn.addEventListener('click', close);
    mask.addEventListener('click', function(e){ if(e.target===mask) close(); });
    var islandEntry = document.getElementById('__hs_island_entry');
    if(islandEntry) islandEntry.addEventListener('click', function(e){ e.stopPropagation();

      var op = null;
      try{ op = window.openIsland || (window.parent && window.parent !== window && window.parent.openIsland) || null; }catch(_e){}
      if(op){ op('island_season.html'); } else { location.href='island_season.html'; }
    });
    var hallEntry = document.getElementById('__hs_hall_entry');
    if(hallEntry) hallEntry.addEventListener('click', function(e){ e.stopPropagation(); openHall(); });
    var curCard = document.getElementById('__hs_curcard');
    if(curCard) curCard.addEventListener('click', function(e){ e.stopPropagation(); openShowcase(curCard.getAttribute('data-season')); });
  }

  function readCardPref(id){
    var season = getSeasonById(id);
    if(!season) return null;
    var forms = FORMS[id] || [season.card.img];
    var p = null;
    try { p = JSON.parse(localStorage.getItem('hs_showcase_'+id)||'null'); } catch(e){}
    if(!p || typeof p !== 'object' || Array.isArray(p)) p = {};
    var formIdx = safeStoredIndex(p.formIdx, forms.length);
    var bgIdx = safeStoredIndex(p.bgIdx, BGS.length);

    return { formIdx:formIdx, bgIdx:bgIdx, formPng:forms[formIdx], bgCss:BGS[bgIdx] };
  }

  function refreshHallCard(id){
    var pref = readCardPref(id); if(!pref) return;
    function apply(img, box){

      if(img){ var _sp=(pref.formPng||'bosses/saelya.webp'); img.onerror=function(){this.onerror=null;this.src='bosses/saelya.webp?v=1040';}; img.src = _sp + '?v=1040'; img.style.objectFit='contain'; img.style.objectPosition='center bottom'; }
      if(box && pref.bgCss){ box.style.background = pref.bgCss; }
    }
    var hall = document.getElementById('__hs_hall_panel');
    if(hall){ var gc = hall.querySelector('.__hs_gcard[data-season="'+id+'"]'); if(gc) apply(gc.querySelector('img'), gc.querySelector('.__hs_thumb_box')); }
    var panel = document.getElementById('__hs_season_panel');
    if(panel){ var cc = panel.querySelector('#__hs_curcard[data-season="'+id+'"]'); if(cc) apply(cc.querySelector('img'), cc.querySelector('.__hs_panel_thumb')); }
  }

  function openHall(){
    var t = todayStr();
    var d = loadData();
    var mask = document.createElement('div');
    mask.id = '__hs_hall_panel';
    mask.style.cssText = 'position:fixed;inset:0;z-index:2147483530;background:rgba(12,21,56,.88);display:flex;align-items:center;justify-content:center;padding:18px;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;overflow-y:auto';

    var ownedTotal = 0, grandTotal = totalCardCount();
    var cardsHtml = '', _saelyaH = '';
    SEASONS.forEach(function(s){
      var r = RARITY_STYLE[s.card.rarity] || RARITY_STYLE.rare;
      var owned = tempUnlockAll() || d.unlockedCards.indexOf(s.id) >= 0;
      var ended = t > s.end;
      var notStarted = t < s.start;
      if(owned){
        ownedTotal++;
        var pref = readCardPref(s.id);

        var tImg = (pref&&pref.formPng)?pref.formPng:'bosses/saelya.webp';
        var tBg  = (pref&&pref.bgCss)?pref.bgCss:'radial-gradient(circle at 50% 30%,#2a2350,#0d0a22)';
        _saelyaH +=
          '<div class="__hs_gcard" data-season="'+s.id+'" style="background:linear-gradient(160deg,'+r.glow+',rgba(12,21,56,.35));border:2px solid '+r.color+';border-radius:14px;padding:10px 10px 12px;text-align:center;box-shadow:0 0 16px '+r.glow+';cursor:pointer">'+
            '<div class="__hs_thumb_box" style="width:100%;aspect-ratio:1/1;border-radius:10px;overflow:hidden;background:'+tBg+';margin-bottom:8px">'+
              '<img src="'+tImg+'?v=1040" onerror="this.onerror=null;this.src=\'bosses/saelya.webp?v=1040\'" style="width:100%;height:100%;object-fit:contain;object-position:center bottom;filter:drop-shadow(0 4px 10px rgba(0,0,0,.5))" alt="">'+
            '</div>'+
            '<div style="font-size:13px;font-weight:900;color:#fff;line-height:1.2">'+s.card.name+'</div>'+
            '<div style="font-size:10px;color:'+r.color+';font-weight:800;margin-top:3px">★ '+r.name+'限定</div>'+
            '<div style="font-size:10px;color:#22c55e;font-weight:800;margin-top:4px">✓ 已收藏 · 点击观赏</div>'+
          '</div>';
      } else if(notStarted){
        _saelyaH +=
          '<div style="background:rgba(30,41,59,.5);border:1.5px dashed #334155;border-radius:14px;padding:14px;text-align:center;opacity:.7">'+
            '<div style="font-size:40px;margin-bottom:6px">🗓️</div>'+
            '<div style="font-size:13px;font-weight:900;color:#94a3b8">即将开启</div>'+
            '<div style="font-size:10px;color:#64748b;margin-top:4px">'+s.name+'</div>'+
          '</div>';
      } else if(ended){
        _saelyaH +=
          '<div style="background:rgba(30,41,59,.5);border:1.5px solid #334155;border-radius:14px;padding:14px;text-align:center;opacity:.78">'+
            '<div style="font-size:40px;margin-bottom:6px;filter:grayscale(1)">🎴</div>'+
            '<div style="font-size:13px;font-weight:900;color:#64748b">'+s.card.name+'</div>'+
            '<div style="font-size:10px;color:#475569;font-weight:800;margin-top:3px">'+s.name+'</div>'+
            '<div style="font-size:10px;color:#ef4444;font-weight:800;margin-top:4px">🔒 已绝版 · 错过</div>'+
          '</div>';
      } else {

        _saelyaH +=
          '<div style="background:rgba(30,41,59,.45);border:1.5px solid '+r.color+';border-radius:14px;padding:14px;text-align:center">'+
            '<div style="font-size:40px;margin-bottom:6px">❓</div>'+
            '<div style="font-size:13px;font-weight:900;color:#cbd5e1">？？？</div>'+
            '<div style="font-size:10px;color:'+r.color+';font-weight:800;margin-top:3px">★ '+r.name+'限定 · 进行中</div>'+
            '<div style="font-size:10px;color:#94a3b8;font-weight:700;margin-top:4px">通关星海副本后解锁</div>'+
          '</div>';
      }

      if(Array.isArray(s.bossCards)){
        s.bossCards.forEach(function(bc){
          var br2 = RARITY_STYLE[bc.rarity] || RARITY_STYLE.legend;
          var bcOwned = tempUnlockAll() || d.unlockedCards.indexOf(bc.id) >= 0;
          if(bcOwned){
            ownedTotal++;
            var bcBg = bc.bgImg ? ('url("'+bc.bgImg+'?v=1040") center/cover') : bc.bg;
            cardsHtml +=
              '<div class="__hs_bcard" data-bc="'+bc.id+'" style="background:linear-gradient(160deg,'+br2.glow+',rgba(12,21,56,.35));border:2px solid '+br2.color+';border-radius:14px;padding:10px 10px 12px;text-align:center;box-shadow:0 0 16px '+br2.glow+';cursor:pointer">'+
                '<div style="width:100%;aspect-ratio:1/1;border-radius:10px;overflow:hidden;background:'+bcBg+';margin-bottom:8px">'+
                  '<img src="'+bc.img+'?v=1040" onerror="this.onerror=null;this.style.visibility=\'hidden\'" style="width:100%;height:100%;object-fit:contain;object-position:center bottom;filter:drop-shadow(0 4px 10px rgba(0,0,0,.5))" alt="">'+
                '</div>'+
                '<div style="font-size:13px;font-weight:900;color:#fff;line-height:1.2">'+bc.name+'</div>'+
                '<div style="font-size:10px;color:'+br2.color+';font-weight:800;margin-top:3px">★ '+br2.name+'限定</div>'+
                '<div style="font-size:10px;color:#22c55e;font-weight:800;margin-top:4px">✓ 已收藏 · 点击观赏</div>'+
              '</div>';
          } else {
            cardsHtml +=
              '<div style="background:rgba(30,41,59,.45);border:1.5px solid '+br2.color+';border-radius:14px;padding:14px;text-align:center">'+
                '<div style="font-size:40px;margin-bottom:6px">❓</div>'+
                '<div style="font-size:13px;font-weight:900;color:#cbd5e1">？？？</div>'+
                '<div style="font-size:10px;color:'+br2.color+';font-weight:800;margin-top:3px">★ '+br2.name+'限定 · 赛季 Boss</div>'+
                '<div style="font-size:10px;color:#94a3b8;font-weight:700;margin-top:4px">通关密码面板解锁</div>'+
              '</div>';
          }
        });
      }
    });
    cardsHtml += _saelyaH;

    var html =
      '<div style="width:100%;max-width:380px;background:linear-gradient(160deg,#1a2660,#0c1538);border:2px solid rgba(251,191,36,.4);border-radius:22px;box-shadow:0 18px 50px rgba(0,0,0,.6);padding:22px 20px;max-height:88vh;overflow-y:auto">'+
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">'+
          '<div style="font-size:18px;font-weight:900;color:#fff">🏛️ 神秘殿堂</div>'+
          '<div id="__hs_hall_close" style="font-size:22px;color:#64748b;cursor:pointer;line-height:1;padding:0 4px">×</div>'+
        '</div>'+
        '<div style="font-size:12px;color:#cbd5e1;margin-bottom:4px;line-height:1.5">历代赛季限定卡的殿堂 · <span style="color:#fbbf24">已收藏 '+ownedTotal+'/'+grandTotal+'</span>。点亮的卡可点击进入全屏观赏。</div>'+
        '<div style="font-size:11px;color:#94a3b8;margin-bottom:16px;line-height:1.5">限定卡绝版后无法再获得，把握每个赛季！</div>'+
        '<div onclick="if(window.hansenStoryArchive){window.hansenStoryArchive();}" style="margin-bottom:16px;background:linear-gradient(135deg,#7c3aed,#4f46e5);padding:1.5px;border-radius:14px;cursor:pointer;box-shadow:0 6px 20px rgba(124,58,237,.35)"><div style="border-radius:12.5px;padding:13px 14px;display:flex;align-items:center;gap:12px;background:radial-gradient(120% 120% at 0% 0%,rgba(167,139,250,.22),transparent 55%),linear-gradient(135deg,#2a1f55,#191338)"><div style="flex:none;width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:25px;background:radial-gradient(circle at 35% 28%,rgba(167,139,250,.3),rgba(124,58,237,.18));border:1px solid rgba(167,139,250,.5)">📖</div><div style="flex:1;min-width:0"><div style="font-size:15px;font-weight:900;color:#f3e8ff">星海纪事</div><div style="font-size:11px;color:#c4b5fd;margin-top:2px">《星海的回响》· 拿到守关卡回看每章全文</div></div><div style="flex:none;color:#c4b5fd;font-size:13px;font-weight:800">翻阅<span style="font-size:18px;line-height:1">›</span></div></div></div>'+
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">'+cardsHtml+'</div>'+
      '</div>';

    mask.innerHTML = html;
    document.body.appendChild(mask);
    function close(){ if(mask.parentNode) mask.parentNode.removeChild(mask); }
    var cb = document.getElementById('__hs_hall_close');
    if(cb) cb.addEventListener('click', close);
    mask.addEventListener('click', function(e){ if(e.target===mask) close(); });

    Array.prototype.forEach.call(mask.querySelectorAll('.__hs_gcard'), function(el){
      el.addEventListener('click', function(e){ e.stopPropagation(); openShowcase(el.getAttribute('data-season')); });
    });

    Array.prototype.forEach.call(mask.querySelectorAll('.__hs_bcard'), function(el){
      el.addEventListener('click', function(e){ e.stopPropagation(); openSeasonBossHall(el.getAttribute('data-bc')); });
    });
  }

  function openShowcase(seasonId){
    if(document.getElementById('__hs_showcase')) return;
    var mask = document.createElement('div');
    mask.id = '__hs_showcase';
    mask.style.cssText = 'position:fixed;inset:0;z-index:2147483600;background:#0a0a14';
    var iframe = document.createElement('iframe');
    iframe.src = 'season_showcase.html?v=1040&boss=' + encodeURIComponent(seasonId || '');
    iframe.setAttribute('title', '神秘殿堂');
    iframe.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:0;display:block;background:#0a0a14';
    mask.appendChild(iframe);
    var closeBtn = document.createElement('div');
    closeBtn.textContent = '×';
    closeBtn.setAttribute('aria-label', '关闭');
    closeBtn.style.cssText = 'position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:16px;z-index:5;width:40px;height:40px;border-radius:50%;background:rgba(10,12,24,.82);border:1px solid rgba(255,255,255,.28);color:#fff;font-size:24px;line-height:38px;text-align:center;cursor:pointer';
    closeBtn.addEventListener('click', function(){ if(mask.parentNode) mask.parentNode.removeChild(mask); refreshHallCard(seasonId); });
    mask.appendChild(closeBtn);
    document.body.appendChild(mask);
  }

  function openSeasonBossHall(bossId){
    if(document.getElementById('__hs_showcase')) return;
    var lv=1, bcs=(SEASONS[0]&&SEASONS[0].bossCards)||[];
    for(var i=0;i<bcs.length;i++){ if(bcs[i].id===bossId){ lv=i+1; break; } }
    var mask = document.createElement('div');
    mask.id = '__hs_showcase';
    mask.style.cssText = 'position:fixed;inset:0;z-index:2147483600;background:#0a0a14';
    var iframe = document.createElement('iframe');
    iframe.src = 'boss_hall.html?v=1040&season=1&lv=' + lv;
    iframe.setAttribute('title', 'BOSS 殿堂');
    iframe.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:0;display:block;background:#0a0a14';
    mask.appendChild(iframe);
    var closeBtn = document.createElement('div');
    closeBtn.textContent = '×';
    closeBtn.setAttribute('aria-label', '关闭');
    closeBtn.style.cssText = 'position:absolute;top:calc(env(safe-area-inset-top,0px) + 14px);right:16px;z-index:5;width:40px;height:40px;border-radius:50%;background:rgba(10,12,24,.82);border:1px solid rgba(255,255,255,.28);color:#fff;font-size:24px;line-height:38px;text-align:center;cursor:pointer';
    closeBtn.addEventListener('click', function(){ if(mask.parentNode) mask.parentNode.removeChild(mask); });
    mask.appendChild(closeBtn);
    document.body.appendChild(mask);
  }

  function openBossCardView(card){
    if(!card || document.getElementById('__hs_bcv')) return;
    var r = RARITY_STYLE[card.rarity] || RARITY_STYLE.legend;
    var bgStyle = card.bgImg ? ('url("'+card.bgImg+'?v=1040") center/cover') : card.bg;
    var mask = document.createElement('div');
    mask.id = '__hs_bcv';
    mask.style.cssText = 'position:fixed;inset:0;z-index:2147483600;background:rgba(8,8,18,.92);display:flex;align-items:center;justify-content:center;padding:24px;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif';
    mask.innerHTML =
      '<div style="width:100%;max-width:330px">'+
        '<div style="position:relative;width:100%;aspect-ratio:3/4;border-radius:20px;overflow:hidden;border:3px solid '+r.color+';box-shadow:0 0 34px '+r.glow+',0 18px 50px rgba(0,0,0,.6);background:'+bgStyle+'">'+
          '<img src="'+card.img+'?v=1040" onerror="this.onerror=null;this.style.visibility=\'hidden\'" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain;object-position:center bottom;filter:drop-shadow(0 8px 18px rgba(0,0,0,.6))" alt="">'+
          '<div style="position:absolute;top:11px;left:11px;background:'+r.color+';color:#1a1226;font-size:11px;font-weight:900;padding:3px 11px;border-radius:8px">★ '+r.name+'</div>'+
          '<div style="position:absolute;left:0;right:0;bottom:0;padding:16px 15px 17px;background:linear-gradient(to top,rgba(8,8,18,.94),rgba(8,8,18,.55),transparent)">'+
            '<div style="font-size:18px;font-weight:900;color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.8)">'+card.name+'</div>'+
            '<div style="font-size:12px;color:#cbd5e1;margin-top:6px;line-height:1.55">'+card.desc+'</div>'+
            '<div style="font-size:10px;color:'+r.color+';font-weight:800;margin-top:8px;letter-spacing:.5px">赛季限定 · 神秘殿堂典藏</div>'+
          '</div>'+
        '</div>'+
        '<div id="__hs_bcv_close" style="margin:18px auto 0;width:46px;height:46px;border-radius:50%;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.3);color:#fff;font-size:24px;line-height:44px;text-align:center;cursor:pointer">×</div>'+
      '</div>';
    document.body.appendChild(mask);
    function close(){ if(mask.parentNode) mask.parentNode.removeChild(mask); }
    mask.addEventListener('click', function(e){ if(e.target===mask) close(); });
    var cb = document.getElementById('__hs_bcv_close'); if(cb) cb.addEventListener('click', close);
  }

  function mountUI(){
    if(!isHomePage()) return;
    buildEntryButton();
    buildHallEntry();
  }

  var tries = 0;
  var timer = setInterval(function(){
    tries++;
    var done = hookScoreEvents();
    if(document.body && isHomePage()){ buildProgressBar(); buildEntryButton(); buildHallEntry(); }
    var barMounted = !!document.getElementById('hsnSeasonBar');
    if((done && (barMounted || !isHomePage())) || tries >= 100){ clearInterval(timer); }
  }, 150);

})();
