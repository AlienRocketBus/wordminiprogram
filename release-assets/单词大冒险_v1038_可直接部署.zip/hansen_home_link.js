
(function(){
  'use strict';

  try{
    var st = document.createElement('style');
    st.textContent = '@view-transition{navigation:auto}'

      + '::view-transition-old(root),::view-transition-new(root){animation-duration:.16s}'

      + '.world-map-btn{touch-action:manipulation;-webkit-tap-highlight-color:transparent}';
    document.head.appendChild(st);
  }catch(e){}

  try{
    var _rd = document.createElement('style');
    _rd.id = 'hsn-text-readability';
    var _halo = 'text-shadow:0 0 1px rgba(0,0,0,.6),0 1px 2px rgba(0,0,0,.85),0 0 6px rgba(0,0,0,.55)!important';
    _rd.textContent =

      '#homeScreen>div:first-child>div:last-child,.pet-name,.pet-text,.section-label{'+_halo+'}'

      + '#homeScreen>div:first-child>div:first-child{filter:drop-shadow(0 0 18px rgba(251,191,36,.30)) drop-shadow(0 1px 2px rgba(0,0,0,.55))!important;text-shadow:none!important}'

      + '.page .tagline,.page .subtitle,.page .intro{'+_halo+'}'

      + '.page h1.main{filter:drop-shadow(0 0 30px rgba(251,191,36,.30)) drop-shadow(0 1px 2px rgba(0,0,0,.55))!important}';
    document.head.appendChild(_rd);
  }catch(e){}

  var isHome = /(?:^|\/)index\.html?$/.test(location.pathname) || /\/$/.test(location.pathname);

  if(isHome){

    document.addEventListener('click', function(e){
      var t = e.target;
      var a = (t && t.closest) ? t.closest('a[href^="island_"]') : null;
      if(a){ try{ sessionStorage.setItem('hsn_from_home','1'); }catch(err){} }
    }, true);

    return;
  }

  window.goHome = function(){

    try{ if(window.playNavClick) window.playNavClick(); }catch(e){}

    try{
      if(window.parent && window.parent !== window){

        if(/island_season[1-5]\.html/.test(location.pathname||'') && typeof window.parent.openIsland === 'function'){
          window.parent.openIsland('island_season.html');
          return false;
        }

        if(/island_land[1-8]\.html/.test(location.pathname||'') && typeof window.parent.openIsland === 'function'){
          window.parent.openIsland('land_map.html');
          return false;
        }
        if(window.parent.closeIsland){
          window.parent.closeIsland();
          return false;
        }
      }
    }catch(e){}

    if(/island_land[1-8]\.html/.test(location.pathname||'')){
      try{ location.replace('land_map.html'); }catch(e){ try{ (function(){ if(window.HansenRoom){ HansenRoom.open('land'); return; } location.href='land_map.html'; })(); }catch(e2){} }
      return false;
    }
    var fromHome = false;
    try{ fromHome = sessionStorage.getItem('hsn_from_home') === '1'; }catch(e){}
    if(!fromHome){

      try{
        var ref = document.referrer || '';
        if(ref){
          var u = new URL(ref);
          if(u.origin === location.origin && /(?:^|\/)(?:index\.html?)?$/.test(u.pathname)){ fromHome = true; }
        }
      }catch(e){}
    }
    if(fromHome && window.history.length > 1){
      try{ window.history.back(); }
      catch(e){ try{ location.replace('index.html'); }catch(e2){} return false; }

      setTimeout(function(){
        try{
          if(document.visibilityState === 'visible'){ location.replace('index.html'); }
        }catch(e){}
      }, 600);
    } else {
      try{ location.replace('index.html'); }
      catch(e){ try{ location.href = 'index.html'; }catch(e2){} }
    }
    return false;
  };

  try{ window.goHome.__navSoundHooked = true; }catch(e){}

  setTimeout(function(){
    try{

      var lowMem = false;
      try{
        lowMem = (navigator.deviceMemory && navigator.deviceMemory < 4) ||
                 /MicroMessenger/i.test(navigator.userAgent || '');
      }catch(e){}
      if(!lowMem && window.HTMLScriptElement && HTMLScriptElement.supports && HTMLScriptElement.supports('speculationrules')){
        var sp = document.createElement('script');
        sp.type = 'speculationrules';
        sp.textContent = JSON.stringify({ prerender:[{ urls:['index.html'] }], prefetch:[{ urls:['index.html'] }] });
        document.head.appendChild(sp);
      } else {
        var lk = document.createElement('link');
        lk.rel = 'prefetch';
        lk.href = 'index.html';
        document.head.appendChild(lk);
      }
    }catch(e){}
  }, 1500);
})();
