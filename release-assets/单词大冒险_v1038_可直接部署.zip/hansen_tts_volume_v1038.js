
(function () {
  'use strict';
  if (window.HansenTTSVolume) return;

  var KEY = 'hansen_tts_volume';
  var DEFAULT = 85;
  var MP3_BOOST = 1.0;

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  function readPct() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw === null) return DEFAULT;
      var n = parseInt(raw, 10);
      if (!isFinite(n)) return DEFAULT;
      return clamp(n, 0, 100);
    } catch (e) { return DEFAULT; }
  }
  function writePct(p) {
    var n = clamp(parseInt(p, 10) || 0, 0, 100);
    try { localStorage.setItem(KEY, String(n)); } catch (e) {}
    return n;
  }

  function gain() { return readPct() / 100; }

  function calib(isMp3) {
    var g = gain();
    return clamp(isMp3 ? g * MP3_BOOST : g, 0, 1);
  }

  function apply(target, opts) {
    if (!target) return target;
    var isMp3 = !!(opts && opts.mp3);
    try {

      if (target.volume === 0 && opts && opts.keepSilent) return target;
      target.volume = calib(isMp3);
    } catch (e) {}
    return target;
  }

  function hijack() {

    try {
      var U = window.SpeechSynthesisUtterance;
      if (U && !U.__hsnVolPatched) {
        var Wrapped = function (text) {
          var u = new U(text);
          try {

            u.volume = calib(false);
          } catch (e) {}
          return u;
        };
        Wrapped.prototype = U.prototype;
        Wrapped.__hsnVolPatched = true;
        window.SpeechSynthesisUtterance = Wrapped;
      }
    } catch (e) {}

    try {
      var proto = window.HTMLMediaElement && window.HTMLMediaElement.prototype;
      if (proto && !proto.__hsnVolPatched) {
        var origPlay = proto.play;
        proto.play = function () {
          try {

            if (this.volume !== 0) this.volume = calib(true);
          } catch (e) {}
          return origPlay.apply(this, arguments);
        };
        proto.__hsnVolPatched = true;
      }
    } catch (e) {}
  }
  hijack();

  function preview(word) {
    var txt = String(word || 'hello');
    try {
      if (!window.speechSynthesis) return false;
      speechSynthesis.cancel();
      var u = new window.SpeechSynthesisUtterance(txt);
      u.lang = 'en-US';
      u.rate = 0.95;
      apply(u);
      speechSynthesis.speak(u);
      return true;
    } catch (e) { return false; }
  }

  window.HansenTTSVolume = {
    KEY: KEY,
    DEFAULT: DEFAULT,
    get: readPct,
    set: function (p) { var n = writePct(p); hijack(); return n; },
    gain: gain,
    apply: apply,
    preview: preview,
    _calib: calib
  };
})();
