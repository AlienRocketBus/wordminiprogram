
(function () {
  'use strict';
  if (window.HansenIslandPrefetch) return;

  var done = {};
  var MAX = 6;
  var idleCount = 0;

  function ver() {
    try {
      var s = document.querySelector('script[src*="hansen_island_prefetch"]');
      var m = s && s.getAttribute('src').match(/[?&]v=(\d+)/);
      return m ? m[1] : '';
    } catch (e) { return ''; }
  }

  function normalize(href) {
    if (!href) return '';
    var u = String(href).split('#')[0];
    if (!/island_[a-z0-9]+\.html/i.test(u)) return '';
    return u.split('?')[0];
  }

  function prefetch(url, why) {
    var u = normalize(url);
    if (!u || done[u]) return false;
    done[u] = 1;
    try {
      var v = ver();
      var link = document.createElement('link');
      link.rel = 'prefetch';
      link.as = 'document';
      link.href = u + (v ? ('?v=' + v) : '');
      link.setAttribute('data-why', why || '');
      (document.head || document.documentElement).appendChild(link);
      return true;
    } catch (e) { return false; }
  }

  function bindEager() {
    var links = document.querySelectorAll('a[href*="island_"]');
    for (var i = 0; i < links.length; i++) {
      (function (a) {
        var go = function () { prefetch(a.getAttribute('href'), 'touch'); };
        a.addEventListener('pointerenter', go, { passive: true });
        a.addEventListener('touchstart', go, { passive: true });
        a.addEventListener('pointerdown', go, { passive: true });
      })(links[i]);
    }
    return links.length;
  }

  function prefetchRecent() {
    var picked = [];
    try {
      var last = localStorage.getItem('lastIslandKey');
      if (last) picked.push('island_' + String(last).replace(/[^a-z0-9]/gi, '') + '.html');
    } catch (e) {}
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('wordIsland') === 0) {
          var name = k.slice('wordIsland'.length).toLowerCase();
          if (name) picked.push('island_' + name + '.html');
        }
      }
    } catch (e) {}
    var n = 0;
    for (var j = 0; j < picked.length && idleCount < MAX; j++) {
      if (prefetch(picked[j], 'recent')) { n++; idleCount++; }
    }
    return n;
  }

  function prefetchVisible() {
    var links = document.querySelectorAll('a[href*="island_"]');
    var i = 0;
    (function step() {
      if (i >= links.length || idleCount >= MAX) return;
      var href = links[i++].getAttribute('href');
      if (prefetch(href, 'idle')) idleCount++;
      setTimeout(step, 900);
    })();
  }

  function boot() {
    bindEager();
    var run = function () { prefetchRecent(); setTimeout(prefetchVisible, 1500); };
    if (typeof window.requestIdleCallback === 'function') {
      requestIdleCallback(function () { run(); }, { timeout: 4000 });
    } else {
      setTimeout(run, 2500);
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  window.HansenIslandPrefetch = {
    prefetch: prefetch,
    prefetched: function () { return Object.keys(done); },
    _bind: bindEager
  };
})();
