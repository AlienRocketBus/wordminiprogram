
(function () {
  'use strict';
  if (window.HansenRoom) return;

  var rooms = {};
  var Z = 2147483500;

  function cfgOf(key) {
    var MAP = {
      land:    { url: 'land_map.html',        title: '单词大陆', warm: true  },
      season:  { url: 'island_season.html',   title: '赛季岛',   warm: true  },
      hall:    { url: 'boss_hall.html',       title: 'Boss 殿堂', warm: false },
      showcase:{ url: 'season_showcase.html', title: '赛季展柜', warm: false },
      bee:     { url: 'spelling_bee.html',    title: '拼写蜂',   warm: false }
    };
    return MAP[key] || null;
  }

  function ver() {
    try {
      var s = document.querySelector('script[src*="hansen_room_warm"]');
      var m = s && s.getAttribute('src').match(/[?&]v=(\d+)/);
      return m ? m[1] : '';
    } catch (e) { return ''; }
  }

  function build(key) {
    if (rooms[key]) return rooms[key];
    var cfg = cfgOf(key);
    if (!cfg) return null;

    var wrap = document.createElement('div');
    wrap.id = 'hsn_room_' + key;
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-label', cfg.title);
    wrap.style.cssText = 'position:fixed;inset:0;z-index:' + Z + ';background:#0f172a;'
      + 'display:none;overflow:hidden';

    var ifr = document.createElement('iframe');
    ifr.title = cfg.title;
    ifr.setAttribute('allow', 'autoplay');
    ifr.style.cssText = 'display:block;width:100%;height:100%;border:0;margin:0;padding:0;background:#0f172a';
    var v = ver();
    ifr.src = cfg.url + (v ? ('?v=' + v) : '');
    ifr.addEventListener('load', function () {
      var r = rooms[key]; if (r) { r.ready = true; r.loading = false; }
    });

    var back = document.createElement('button');
    back.type = 'button';
    back.setAttribute('aria-label', '返回');
    back.textContent = '✕';
    back.style.cssText = 'position:absolute;top:calc(env(safe-area-inset-top,0px) + 10px);right:12px;z-index:2;'
      + 'width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,0,0,.45);color:#fff;'
      + 'font-size:18px;font-weight:900;cursor:pointer';
    back.onclick = function () { close(key); };

    wrap.appendChild(ifr);
    wrap.appendChild(back);
    (document.body || document.documentElement).appendChild(wrap);

    rooms[key] = { wrap: wrap, iframe: ifr, ready: false, loading: true };
    return rooms[key];
  }

  function warm(key) {
    var r = rooms[key];
    if (r) return r;
    return build(key);
  }

  function open(key) {
    var r = rooms[key] || build(key);
    if (!r) return false;
    r.wrap.style.display = 'block';
    try { document.documentElement.style.overflow = 'hidden'; } catch (e) {}
    return true;
  }

  function close(key) {
    var r = rooms[key];
    if (r) r.wrap.style.display = 'none';
    try { document.documentElement.style.overflow = ''; } catch (e) {}
  }

  function isReady(key) { var r = rooms[key]; return !!(r && r.ready); }
  function isOpen(key) {
    var r = rooms[key];
    return !!(r && r.wrap && r.wrap.style.display === 'block');
  }

  var prefetched = {};
  function prefetch(url) {
    if (!url || prefetched[url]) return;
    prefetched[url] = 1;
    try {
      var v = ver();
      var full = url + (v ? ('?v=' + v + '&warm=1') : '?warm=1');
      var ifr = document.createElement('iframe');
      ifr.setAttribute('aria-hidden', 'true');
      ifr.tabIndex = -1;
      ifr.style.cssText = 'position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;border:0;left:-9999px;top:-9999px';
      ifr.src = full;

      ifr.addEventListener('load', function () {
        setTimeout(function () { try { ifr.remove(); } catch (e) {} }, 600);
      });
      (document.body || document.documentElement).appendChild(ifr);
    } catch (e) {}
  }

  function scheduleWarm() {
    var keys = Object.keys({ land: 1, season: 1 }).filter(function (k) {
      var c = cfgOf(k); return c && c.warm;
    });
    var i = 0;
    function next() {
      if (i >= keys.length) return;
      warm(keys[i++]);

      setTimeout(next, 1200);
    }

    var PREFETCH = ['boss_hall.html', 'season_showcase.html', 'spelling_bee.html'];
    function warmAssets() {
      var j = 0;
      (function step() {
        if (j >= PREFETCH.length) return;
        prefetch(PREFETCH[j++]);
        setTimeout(step, 1500);
      })();
    }
    function chain() { next(); setTimeout(warmAssets, keys.length * 1300 + 800); }
    if (typeof window.requestIdleCallback === 'function') {
      requestIdleCallback(function () { chain(); }, { timeout: 4000 });
    } else {
      setTimeout(chain, 2500);
    }
  }

  if (document.readyState === 'complete') scheduleWarm();
  else window.addEventListener('load', scheduleWarm);

  window.HansenRoom = {
    open: open, close: close, warm: warm, prefetch: prefetch,
    prefetched: function(){ return Object.keys(prefetched); },
    isReady: isReady, isOpen: isOpen,
    _rooms: function () { return Object.keys(rooms); }
  };
})();
