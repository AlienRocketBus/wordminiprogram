
'use strict';

const CACHE_PREFIX = 'hansen-v944-';

const SHELL_CACHE = CACHE_PREFIX + 'shell-96';
const PAGE_CACHE = CACHE_PREFIX + 'pages-94';
const ASSET_CACHE = CACHE_PREFIX + 'assets-94';
const ICON_CACHE = CACHE_PREFIX + 'icons-3';
const CURRENT_CACHES = new Set([SHELL_CACHE, PAGE_CACHE, ASSET_CACHE, ICON_CACHE]);

const SHELL = [
  './index.html', './_frame.html', './_sw_upgrade_v944.html', './manifest.webmanifest', './favicon.ico', './cartoon_font.woff2',
  './hansen_sw_upgrade_gate_v944.js', './hansen_backup_bootstrap_v944.js', './hansen_coin_wallet.js', './copy_protect.js', './perf_boost.js', './hansen_preload.js?v=1037', './click_sound.js', './click_setting.js',
  './vocab_all.js', './hansen_upgrade.js', './hansen_boss_lock.js?v=1037', './hansen_onboarding.js?v=1037', './hansen_theme_shop.js',
  './hansen_season.js?v=1037', './hansen_cinema_themes.js?v=1037', './hansen_diamond_shop.js?v=1037', './hansen_gem_system.js',
  './hansen_canonical_progress.js?v=1037', './hansen_crystal.js', './hansen_cards.js?v=1037', './hansen_gacha.js?v=1037', './hansen_land_cards.js?v=1037', './hansen_round_reward.js?v=1037', './hansen_round_bar.js?v=1037', './hansen_pet_showcase.js?v=1037', './hansen_quest_global.js?v=1037', './hansen_island_upgrade.js?v=1037', './hansen_focused_typing_v946.js', './hansen_explore_progress_v945.js?v=1037', './hansen_spell_practice.js?v=1037', './hansen_review.js?v=1037', './hansen_wrong_overview.js?v=1037', './hansen_backup_v944.js?v=1037', './hansen_accessibility.js?v=1037',
  './hansen_stability.js', './hansen_home_link.js', './hansen_addiction.js?v=1037', './hansen_mylearning.js?v=1037', './hansen_palette.js?v=1037', './hansen_boss_theme.js?v=1037', './hansen_econ_guide.js?v=1037', './hansen_perf_v944.js?v=1037'
];

async function trim(cacheName, maxEntries) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  while (keys.length > maxEntries) await cache.delete(keys.shift());
}

async function putIfReasonable(cacheName, request, response, maxEntries) {
  if (!response || !response.ok || response.type === 'opaque') return false;
  const length = Number(response.headers.get('content-length') || 0);
  if (length && length > 1572864) return false;
  try {
    const cache = await caches.open(cacheName);
    await cache.put(request, response.clone());
    await trim(cacheName, maxEntries);
    return true;
  } catch (error) {

    return false;
  }
}

const NAVIGATION_TIMEOUT_MS = 3000;
const COLD_NAVIGATION_TIMEOUT_MS = 12000;

async function bufferedNavigationResponse(response) {

  const bytes = await response.arrayBuffer();
  const noBody = response.status === 204 || response.status === 205 || response.status === 304;
  return new Response(noBody ? null : bytes, {
    status: response.status,
    statusText: response.statusText,
    headers: response.headers
  });
}

async function fetchNavigationWithTimeout(request, timeoutMs) {

  timeoutMs = Math.max(1, Number(timeoutMs) || NAVIGATION_TIMEOUT_MS);
  if (typeof AbortController === 'undefined') {
    let legacyTimer;
    try {
      return await Promise.race([
        fetch(request).then(bufferedNavigationResponse),
        new Promise((_, reject) => {
          legacyTimer = setTimeout(() => reject(new Error('navigation timeout')), timeoutMs);
        })
      ]);
    } finally {
      clearTimeout(legacyTimer);
    }
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await bufferedNavigationResponse(await fetch(request, { signal: controller.signal }));
  } finally {
    clearTimeout(timer);
  }
}

function scopeRootPath() {
  try {
    const scope = self.registration && self.registration.scope;
    if (scope) return new URL(scope).pathname.replace(/[^/]$/, '$&/');
  } catch (error) {}
  try { return new URL('./', self.location.href).pathname; } catch (error) { return '/'; }
}

function isHomeNavigation(url) {
  const root = scopeRootPath();
  return url.pathname === root || url.pathname === root + 'index.html';
}

function homeShellRequest() {
  try { return new Request(new URL('./index.html', self.location.href).href); }
  catch (error) { return new Request(self.location.origin + '/index.html'); }
}

function offlineNavigationResponse() {

  const html = '<!doctype html><html lang="zh-CN"><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>当前页面尚未下载</title><body style="margin:0;min-height:100vh;display:grid;place-items:center;' +
    'font-family:system-ui,-apple-system,Microsoft YaHei,sans-serif;background:#eef6ff;color:#172033">' +
    '<main style="max-width:28rem;padding:32px;text-align:center"><div style="font-size:52px">📡</div>' +
    '<h1 style="font-size:22px">当前页面尚未下载</h1><p style="line-height:1.7">请联网打开这个页面一次，' +
    '之后就能从本机缓存中访问。</p><button onclick="location.reload()" style="font:inherit;font-weight:700;' +
    'padding:12px 20px;border:0;border-radius:12px;background:#4f46e5;color:white">重试连接</button></main></body></html>';
  return new Response(html, {
    status: 503,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store'
    }
  });
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);

    await cache.addAll(SHELL.map(url => new Request(url, { cache: 'reload' })));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();

    await Promise.all(names.filter(name => name.startsWith('hansen-') && !CURRENT_CACHES.has(name)).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  let url;
  try { url = new URL(request.url); } catch (e) { return; }
  if (url.origin !== self.location.origin) return;

  const path = url.pathname;
  const isLargeMedia = /\.(?:mp3|mp4|wav|ogg|webm)$/i.test(path) ||
    /\/(?:words|sentences|bosses|bosses_bg|pets|cards|avatars|weapons)\//i.test(path);
  if (isLargeMedia) return;

  if (request.mode === 'navigate') {
    const navigation = (async () => {
      let fallback = null;
      try { fallback = await caches.match(request, { ignoreSearch: true }); } catch (error) {}
      if (!fallback && isHomeNavigation(url)) {
        try { fallback = await caches.match(homeShellRequest(), { ignoreSearch: true }); } catch (error) {}
      }
      try {
        const fresh = await fetchNavigationWithTimeout(request, fallback ? NAVIGATION_TIMEOUT_MS : COLD_NAVIGATION_TIMEOUT_MS);
        const cacheable = isHomeNavigation(url) || /\/(?:index|_frame|land_map|spelling_bee|boss_hall|season_showcase|island_[a-z0-9]+)\.html$/i.test(url.pathname);
        return { response: fresh, fresh, cacheable };
      } catch (e) {
        return { response: fallback || offlineNavigationResponse(), fresh: null, cacheable: false };
      }
    })();

    event.waitUntil(navigation.then(result => result.fresh && result.cacheable ?
      putIfReasonable(PAGE_CACHE, request, result.fresh, 12) : false).catch(() => false));
    event.respondWith(navigation.then(result => result.response));
    return;
  }

  const isCode = /\.(?:js|css|woff2|ico|webmanifest)$/i.test(path);

  const isSmallIcon = /\/icons\/(?:[^/]+\/)*[^/]+\.(?:webp|png|svg)$/i.test(path);
  if (!isCode && !isSmallIcon) return;

  const cacheName = isSmallIcon ? ICON_CACHE : ASSET_CACHE;
  const maxEntries = isSmallIcon ? 36 : 72;
  const network = fetch(request);
  const refresh = network.catch(() => null);
  event.waitUntil(network.then(response => putIfReasonable(cacheName, request, response, maxEntries)).catch(() => false));
  if (isCode) {

    event.respondWith((async () => {
      const exact = await caches.match(request);
      if (exact) return exact;
      const fresh = await refresh;
      if (fresh) return fresh;
      return (await caches.match(new Request(url.origin + url.pathname))) ||
        new Response('', { status: 504 });
    })());
  } else {
    event.respondWith(caches.match(request, { ignoreSearch: true }).then(async cached => {
      return cached || (await refresh) || new Response('', { status: 504 });
    }));
  }
});
