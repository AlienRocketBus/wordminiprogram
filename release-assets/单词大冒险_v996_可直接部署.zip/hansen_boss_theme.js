
(function () {
  if (window.__hansenBossThemeLoaded) return;
  window.__hansenBossThemeLoaded = true;

  var KEY = 'hansen_boss_theme';
  var THEMES = [
    { id: 'dark',   name: '深空',     emoji: '🌌', desc: '纯净深色幕布 · 电影感', sw: 'linear-gradient(160deg,#22305e,#0d142c 55%,#05070f)' },
    { id: 'light',  name: '晨曦',     emoji: '🌤️', desc: '明亮清爽 · 每个字都清清楚楚', sw: 'linear-gradient(160deg,#ffffff,#dbe7f8 55%,#bcd0ea)' },
    { id: 'cinema', name: '电影场景', emoji: '🎬', desc: '用你在钻石商店装备的 IMAX 主题', sw: 'linear-gradient(135deg,#f472b6,#facc15 50%,#38bdf8)' }
  ];

  function cur() {
    try {
      var v = localStorage.getItem(KEY);
      return (v === 'light' || v === 'cinema') ? v : 'dark';
    } catch (e) { return 'dark'; }
  }

  var L = 'html.hsn-bt-light #bossScreen ';
  var D = 'html.hsn-bt-dark #bossScreen ';
  var C = 'html.hsn-bt-cinema #bossScreen ';
  var CSS = [

    'html.hsn-bt-dark #bossScreen::before{background:linear-gradient(180deg,#0f1a38 0%,#0a1122 60%,#05070f 100%) !important}',

    'html.hsn-bt-dark #bossScreen,html.hsn-bt-cinema #bossScreen{' +
      '--boss-answer-primary:#fde68a;--boss-answer-text:#f8fafc;--boss-answer-muted:#e2e8f0;' +
      '--boss-answer-type:#bfdbfe;--boss-answer-correct:#86efac;--boss-answer-wrong:#fca5a5}',
    D + '#bossQType,' + C + '#bossQType{color:var(--boss-answer-type) !important;text-shadow:0 1px 3px rgba(0,0,0,.82) !important}',
    D + '#bossQ,' + C + '#bossQ{color:var(--boss-answer-primary) !important;text-shadow:0 1px 3px rgba(0,0,0,.82) !important}',
    D + '#bossQSub,' + C + '#bossQSub{color:var(--boss-answer-muted) !important;text-shadow:0 1px 3px rgba(0,0,0,.82) !important}',
    D + '.boss-answer-kicker,' + C + '.boss-answer-kicker,' +
      D + '#bossQSub *,' + C + '#bossQSub *{color:var(--boss-answer-muted) !important}',
    D + '.boss-answer-primary,' + C + '.boss-answer-primary,' +
      D + '.boss-answer-secondary,' + C + '.boss-answer-secondary{color:var(--boss-answer-primary) !important}',
    D + '#bossOpts .boss-opt,' + C + '#bossOpts .boss-opt,' +
      D + '#bossOpts .boss-opt .boss-answer-choice-text,' + C + '#bossOpts .boss-opt .boss-answer-choice-text{' +
      'color:var(--boss-answer-text) !important;text-shadow:0 1px 3px rgba(0,0,0,.82) !important}',
    D + '#bossOpts .boss-answer-choice-label,' + C + '#bossOpts .boss-answer-choice-label{color:var(--boss-answer-primary) !important}',

    D + '#bossQ [style*="color:#fbbf24"],' + C + '#bossQ [style*="color:#fbbf24"],' +
      D + '#bossQ [style*="color:#fde047"],' + C + '#bossQ [style*="color:#fde047"],' +
      D + '#bossQ [style*="color:#fde68a"],' + C + '#bossQ [style*="color:#fde68a"],' +
      D + '#bossQ [style*="color:#facc15"],' + C + '#bossQ [style*="color:#facc15"],' +
      D + '#bossQ [style*="color:#fcd34d"],' + C + '#bossQ [style*="color:#fcd34d"]{' +
      'color:var(--boss-answer-primary) !important}',
    D + '#bossOpts .boss-opt [style*="color:#fbbf24"],' + C + '#bossOpts .boss-opt [style*="color:#fbbf24"],' +
      D + '#bossOpts .boss-opt [style*="color:#fde047"],' + C + '#bossOpts .boss-opt [style*="color:#fde047"],' +
      D + '#bossOpts .boss-opt [style*="color:#facc15"],' + C + '#bossOpts .boss-opt [style*="color:#facc15"]{' +
      'color:var(--boss-answer-primary) !important}',

    D + '#bossOpts [style*="color:#3b82f6"],' + C + '#bossOpts [style*="color:#3b82f6"]{color:#93c5fd !important}',
    D + '#bossOpts [style*="color:#22c55e"],' + C + '#bossOpts [style*="color:#22c55e"]{color:#86efac !important}',
    D + '#bossOpts [style*="color:#a855f7"],' + C + '#bossOpts [style*="color:#a855f7"]{color:#d8b4fe !important}',
    D + '#bossOpts [style*="color:#facc15"],' + C + '#bossOpts [style*="color:#facc15"]{color:#fde68a !important}',
    D + '#bossQ [style*="color:#22c55e"],' + C + '#bossQ [style*="color:#22c55e"],' +
      D + '#bossQSub [style*="color:#22c55e"],' + C + '#bossQSub [style*="color:#22c55e"]{' +
      'color:var(--boss-answer-correct) !important}',
    D + '#bossQ [style*="color:#ef4444"],' + C + '#bossQ [style*="color:#ef4444"],' +
      D + '#bossQSub [style*="color:#ef4444"],' + C + '#bossQSub [style*="color:#ef4444"],' +
      D + '#bossOpts [style*="color:#ef4444"],' + C + '#bossOpts [style*="color:#ef4444"]{' +
      'color:var(--boss-answer-wrong) !important}',

    D + '#bossOpts .boss-opt.correct,' + C + '#bossOpts .boss-opt.correct,' +
      D + '#bossOpts .boss-opt.correct *,' + C + '#bossOpts .boss-opt.correct *,' +
      D + '.boss-answer-result-correct,' + C + '.boss-answer-result-correct,' +
      D + '.boss-answer-result-correct *,' + C + '.boss-answer-result-correct *{' +
      'color:var(--boss-answer-correct) !important}',
    D + '#bossOpts .boss-opt.wrong,' + C + '#bossOpts .boss-opt.wrong,' +
      D + '#bossOpts .boss-opt.wrong *,' + C + '#bossOpts .boss-opt.wrong *,' +
      D + '.boss-answer-result-wrong,' + C + '.boss-answer-result-wrong,' +
      D + '.boss-answer-result-wrong *,' + C + '.boss-answer-result-wrong *{' +
      'color:var(--boss-answer-wrong) !important}',

    D + '.bts-slot.filled,' + C + '.bts-slot.filled{color:var(--boss-answer-primary) !important;border-bottom-color:var(--boss-answer-primary) !important}',
    D + '#btsHint,' + C + '#btsHint{color:var(--boss-answer-text) !important}',
    D + '#btsKbd .key,' + C + '#btsKbd .key{color:#1c1c1e !important}',
    D + '.bts-slot.boss-answer-result-correct,' + C + '.bts-slot.boss-answer-result-correct{' +
      'color:var(--boss-answer-correct) !important;border-bottom-color:var(--boss-answer-correct) !important}',
    D + '.bts-slot.boss-answer-result-wrong,' + C + '.bts-slot.boss-answer-result-wrong{' +
      'color:var(--boss-answer-wrong) !important;border-bottom-color:var(--boss-answer-wrong) !important}',
    D + '#btsHint.boss-answer-result-correct,' + C + '#btsHint.boss-answer-result-correct,' +
      D + '#btsHint.boss-answer-result-correct *,' + C + '#btsHint.boss-answer-result-correct *{' +
      'color:var(--boss-answer-correct) !important}',
    D + '#btsHint.boss-answer-result-wrong,' + C + '#btsHint.boss-answer-result-wrong,' +
      D + '#btsHint.boss-answer-result-wrong *,' + C + '#btsHint.boss-answer-result-wrong *{' +
      'color:var(--boss-answer-wrong) !important}',

    D + '#bsfHole:not(.boss-answer-result-correct):not(.boss-answer-result-wrong),' +
      C + '#bsfHole:not(.boss-answer-result-correct):not(.boss-answer-result-wrong){color:#1e293b !important;background:#fbbf24 !important;text-shadow:none !important}',

    'html.hsn-bt-light #bossScreen::before{background:' +
      'radial-gradient(circle at 50% 30%, rgba(38,62,120,.20) 0%, rgba(38,62,120,.05) 44%, transparent 68%),' +
      'radial-gradient(ellipse 130% 78% at 50% 26%, #ffffff 0%, #eaf2ff 34%, #d3e2f7 64%, #bcd0ea 100%) !important}',

    L + '.back-btn{background:rgba(255,255,255,.82) !important;color:#1e293b !important;border-color:rgba(30,41,59,.28) !important}',
    L + '.boss-phase-tag{background:linear-gradient(135deg,#4338ca,#3730a3) !important;color:#fff !important}',
    L + '.boss-rage-tag{background:linear-gradient(135deg,#dc2626,#991b1b) !important;color:#fff !important}',
    L + '.boss-combo{background:rgba(255,255,255,.90) !important;color:#1e40af !important;border-color:#4f46e5 !important}',
    L + '.boss-name{background:rgba(255,255,255,.94) !important;color:#b91c1c !important;border-color:rgba(185,28,28,.45) !important}',
    L + '.boss-hp-bar{background:#dbe4f0 !important;border-color:#dc2626 !important}',
    L + '.boss-hp-text{background:rgba(255,255,255,.92) !important;color:#1e293b !important}',
    L + '.hero-section{background:rgba(255,255,255,.86) !important;border-color:#8fb2e6 !important;color:#1e293b !important}',
    L + '.hero-hp-bar{background:#dbe4f0 !important;border-color:#3b82f6 !important}',
    L + '.hero-hp-text{color:#0c4a6e !important}',
    L + '.hero-dmg-float{color:#b91c1c !important}',

    'html.hsn-bt-light #bossScreen #bossMsg{background:linear-gradient(135deg,rgba(239,246,255,.97),rgba(219,234,254,.95)) !important;border-color:#3b82f6 !important;color:#1e3a5f !important}',
    'html.hsn-bt-light #bossScreen #bossMsg.hit{background:linear-gradient(135deg,rgba(220,252,231,.96),rgba(187,247,208,.94)) !important;border-color:#16a34a !important;color:#14532d !important}',
    'html.hsn-bt-light #bossScreen #bossMsg.crit{background:linear-gradient(135deg,rgba(250,245,255,.97),rgba(243,232,255,.95)) !important;border-color:#9333ea !important;color:#7e22ce !important}',
    'html.hsn-bt-light #bossScreen #bossMsg.rage{background:linear-gradient(135deg,rgba(254,242,242,.97),rgba(254,226,226,.95)) !important;border-color:#dc2626 !important;color:#b91c1c !important}',
    'html.hsn-bt-light #bossScreen #bossMsg.miss{background:linear-gradient(135deg,rgba(254,226,226,.96),rgba(254,202,202,.94)) !important;border-color:#dc2626 !important;color:#991b1b !important}',
    'html.hsn-bt-light #bossScreen #bossMsg.phase{background:linear-gradient(135deg,rgba(254,226,226,.96),rgba(254,202,202,.94)) !important;border-color:#dc2626 !important;color:#991b1b !important}',

    'html.hsn-bt-light #bossScreen #bossMsg .boss-msg-inner{color:inherit !important}',

    'html.hsn-bt-light #bossScreen #bossName{background:rgba(255,255,255,.94) !important;color:#b91c1c !important;border-color:rgba(185,28,28,.45) !important;text-shadow:none !important}',
    'html.hsn-bt-light #bossScreen #bossHPText{background:rgba(255,255,255,.92) !important;color:#1e293b !important;text-shadow:none !important}',
    'html.hsn-bt-light #bossScreen #bossQType{background:rgba(255,255,255,.92) !important;color:#1e40af !important;border-color:rgba(59,130,246,.55) !important}',
    'html.hsn-bt-light #bossScreen #bossQ,html.hsn-bt-light #bossScreen #bossQ *{color:#1e40af !important;text-shadow:none !important}',
    'html.hsn-bt-light #bossScreen #bossQ{background:rgba(255,255,255,.96) !important;border-color:rgba(59,130,246,.50) !important}',
    'html.hsn-bt-light #bossScreen #bossQSub,html.hsn-bt-light #bossScreen #bossQSub *{color:#334155 !important;text-shadow:none !important}',
    'html.hsn-bt-light #bossScreen #bossQSub{background:rgba(255,255,255,.92) !important}',
    'html.hsn-bt-light #bossScreen #heroHPText{color:#0c4a6e !important;text-shadow:none !important}',
    'html.hsn-bt-light #bossScreen #bossPhaseTag{background:linear-gradient(135deg,#4338ca,#3730a3) !important;color:#fff !important}',

    L + '.boss-q-type{background:rgba(255,255,255,.92) !important;color:#1e40af !important;border-color:rgba(59,130,246,.55) !important}',
    L + '.boss-question{background:rgba(255,255,255,.96) !important;color:#1e40af !important;border-color:rgba(59,130,246,.50) !important}',
    L + '.boss-q-sub{background:rgba(255,255,255,.92) !important;color:#334155 !important}',

    L + '.boss-opt{background:linear-gradient(135deg,#ffffff,#eaf1fb) !important;color:#1e293b !important;border-color:#a8bdd9 !important}',
    L + '.boss-opt:hover{background:linear-gradient(135deg,#e0e7ff,#c7d2fe) !important;color:#312e81 !important;border-color:#6366f1 !important}',
    L + '.boss-opt.correct{background:linear-gradient(135deg,#dcfce7,#bbf7d0) !important;color:#14532d !important;border-color:#22c55e !important}',
    L + '.boss-opt.wrong{background:linear-gradient(135deg,#fee2e2,#fecaca) !important;color:#7f1d1d !important;border-color:#ef4444 !important}',
    'html.hsn-bt-light #bossScreen #bossOpts .boss-opt.correct,html.hsn-bt-light #bossScreen #bossOpts .boss-opt.correct *,' +
      'html.hsn-bt-light #bossScreen .boss-answer-result-correct,html.hsn-bt-light #bossScreen .boss-answer-result-correct *{color:#14532d !important}',
    'html.hsn-bt-light #bossScreen #bossOpts .boss-opt.wrong,html.hsn-bt-light #bossScreen #bossOpts .boss-opt.wrong *,' +
      'html.hsn-bt-light #bossScreen .boss-answer-result-wrong,html.hsn-bt-light #bossScreen .boss-answer-result-wrong *{color:#7f1d1d !important}',
    'html.hsn-bt-light #bossScreen .bts-slot.filled{color:#1e40af !important;border-bottom-color:#1e40af !important}',
    'html.hsn-bt-light #bossScreen #btsHint{color:#1e293b !important}',
    'html.hsn-bt-light #bossScreen #btsKbd .key{color:#1c1c1e !important}',
    'html.hsn-bt-light #bossScreen #bsfHole:not(.boss-answer-result-correct):not(.boss-answer-result-wrong){color:#1e293b !important;background:#fbbf24 !important;text-shadow:none !important}',
    'html.hsn-bt-light #bossScreen #bossQ .boss-answer-result-correct,' +
      'html.hsn-bt-light #bossScreen #bossQ .boss-answer-result-correct *{color:#14532d !important}',
    'html.hsn-bt-light #bossScreen #bossQ .boss-answer-result-wrong,' +
      'html.hsn-bt-light #bossScreen #bossQ .boss-answer-result-wrong *{color:#7f1d1d !important}',
    'html.hsn-bt-light #bossScreen #bossOpts .bts-slot.boss-answer-result-correct{' +
      'color:#14532d !important;border-bottom-color:#16a34a !important}',
    'html.hsn-bt-light #bossScreen #bossOpts .bts-slot.boss-answer-result-wrong{' +
      'color:#7f1d1d !important;border-bottom-color:#dc2626 !important}',
    'html.hsn-bt-light #bossScreen #btsHint.boss-answer-result-correct,' +
      'html.hsn-bt-light #bossScreen #btsHint.boss-answer-result-correct *{color:#14532d !important}',
    'html.hsn-bt-light #bossScreen #btsHint.boss-answer-result-wrong,' +
      'html.hsn-bt-light #bossScreen #btsHint.boss-answer-result-wrong *{color:#7f1d1d !important}',

    L + '.boss-listen-btn,' + L + '.boss-speaker-btn{color:#3730a3 !important;border-color:rgba(79,70,229,.45) !important}',
    L + '.boss-divider{background:linear-gradient(90deg,transparent,#94a3b8,transparent) !important}',

    L + '.boss-name,' + L + '.boss-question,' + L + '.boss-q-sub,' + L + '.boss-hp-text,' + L + '.hero-hp-text{text-shadow:none !important}',

    'html.hsn-bt-light #bossScreen,html.hsn-bt-light #bossContent,' + L + '.boss-arena{color:#1e293b !important}',

    L + '[style*="color:#cbd5e1"],' + L + '[style*="color:#e2e8f0"]{color:#1e293b !important}',
    L + '[style*="color:#94a3b8"]{color:#475569 !important}',
    L + '[style*="color:#fbbf24"]{color:#1e40af !important}',
    L + '[style*="color:#22c55e"]{color:#15803d !important}',
    L + '[style*="color:#ef4444"]{color:#b91c1c !important}',

    L + '.boss-victory h2{background:linear-gradient(90deg,#1e40af,#6d28d9) !important;-webkit-background-clip:text !important;background-clip:text !important;-webkit-text-fill-color:transparent !important}',

    'html.hsn-bt-light #bossScreen #bsfBox{background:rgba(255,255,255,.94) !important;color:#1e293b !important;border-color:#6366f1 !important;text-shadow:none !important}',
    L + '[style*="background:rgba(15,23,42"],' + L + '[style*="background:#0f172a"],' +
      L + '[style*="background:#1e293b"],' + L + '[style*="background:#334155"],' +
      L + '[style*="background:#475569"],' + L + '[style*="background:linear-gradient(135deg,#1e293b"]' +
      '{background:rgba(255,255,255,.94) !important;color:#1e293b !important}',

    'html.hsn-bt-dark body.hsn-boss-noheader #hsnCinemaCanvas,html.hsn-bt-light body.hsn-boss-noheader #hsnCinemaCanvas,' +
      'html.hsn-bt-dark body.hsn-boss-battle #hsnCinemaCanvas,html.hsn-bt-light body.hsn-boss-battle #hsnCinemaCanvas{display:none !important}',

    'html.hsn-bt-light body.hsn-boss-noheader::before,html.hsn-bt-light body.hsn-boss-noheader::after,' +
      'html.hsn-bt-light body.hsn-boss-battle::before,html.hsn-bt-light body.hsn-boss-battle::after{display:none !important}'
  ].join('\n');

  function ensureCSS() {
    var st = document.getElementById('hsnBossThemeCSS');
    if (!st) {
      st = document.createElement('style');
      st.id = 'hsnBossThemeCSS';
      (document.head || document.documentElement).appendChild(st);
    }
    if (st.textContent !== CSS) st.textContent = CSS;
  }

  function inBossScreen() {
    try {
      return !!(document.body && (document.body.classList.contains('hsn-boss-noheader') ||
        document.body.classList.contains('hsn-boss-battle')));
    }
    catch (e) { return false; }
  }

  var cinemaWasSuppressed = false;

  function restoreActiveCinema() {
    try {
      var shop = window.HansenDiamondShop;
      if (shop && typeof shop.restoreActiveTheme === 'function') {
        shop.restoreActiveTheme();
        return true;
      }
      var equipped = shop && shop.getEquipped && shop.getEquipped();
      var tid = typeof equipped === 'string' ? equipped : equipped && (equipped.theme || equipped.imax || equipped.id);
      if (tid && window.HansenCinema && window.HansenCinema.apply) return window.HansenCinema.apply(tid);
    } catch (e) { }
    return false;
  }

  function syncCinema() {
    try {
      guardCinema();
      var C = window.HansenCinema;
      if (!C) return false;
      var blocked = inBossScreen() && cur() !== 'cinema';
      if (blocked) {
        cinemaWasSuppressed = true;
        if (C.stop) C.stop();
        return false;
      }
      if (cinemaWasSuppressed) {
        cinemaWasSuppressed = false;
        return restoreActiveCinema();
      }
    } catch (e) { }
    return true;
  }

  function apply(id) {
    if (id !== 'light' && id !== 'cinema') id = 'dark';
    try { localStorage.setItem(KEY, id); } catch (e) { }
    var h = document.documentElement;
    h.classList.remove('hsn-bt-dark', 'hsn-bt-light', 'hsn-bt-cinema');
    h.classList.add('hsn-bt-' + id);
    ensureCSS();
    syncCinema();
    try { renderPicker(); } catch (e) { }
    return true;
  }

  function guardCinema() {
    try {
      var C = window.HansenCinema;
      if (!C || C.__hsnBtWrapped) return;
      var origApply = C.apply;
      C.apply = function (tid) {
        if (inBossScreen() && cur() !== 'cinema') {
          cinemaWasSuppressed = true;
          try { C.stop && C.stop(); } catch (e) { }
          return false;
        }
        return origApply.apply(C, arguments);
      };
      C.__hsnBtWrapped = true;
    } catch (e) { }
  }

  function renderPicker() {
    var sc = document.getElementById('settingsContent');
    if (!sc) return;
    var c = cur();
    var box = document.getElementById('hsnBossThemePicker');
    if (!box) {
      box = document.createElement('div');
      box.className = 'settings-section';
      box.id = 'hsnBossThemePicker';
      var pal = document.getElementById('hsnPalPicker');
      if (pal && pal.nextSibling) sc.insertBefore(box, pal.nextSibling);
      else if (pal) sc.appendChild(box);
      else sc.insertBefore(box, sc.firstChild);
    }
    var h = '<h3 style="margin:0 0 4px">🥊 打Boss 主题</h3>'
      + '<div style="font-size:12px;color:var(--pal-ink-2,#cbd5e1);margin-bottom:10px">只影响打Boss画面 · 背景干净, 不抢 boss 的戏 · 每个字都清清楚楚</div>'
      + '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:9px">';
    for (var i = 0; i < THEMES.length; i++) {
      var t = THEMES[i], on = (t.id === c);
      h += '<div class="hsn-bt-sw" data-bt="' + t.id + '" style="cursor:pointer;border-radius:12px;padding:8px 5px;text-align:center;'
        + 'background:' + t.sw + ';'
        + 'border:' + (on ? '3px solid #22c55e' : '2px solid rgba(148,163,184,.45)') + ';'
        + 'box-shadow:' + (on ? '0 0 12px rgba(34,197,94,.55)' : 'none') + '">'
        + '<div style="font-size:20px;line-height:1.1">' + t.emoji + '</div>'
        + '<div style="font-size:12px;font-weight:800;margin-top:3px;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.95),0 0 8px rgba(0,0,0,.8)">' + t.name + '</div>'
        + (on ? '<div style="font-size:10px;font-weight:800;color:#bbf7d0;text-shadow:0 1px 3px rgba(0,0,0,.95)">使用中</div>' : '')
        + '</div>';
    }
    h += '</div><div style="font-size:11px;color:var(--pal-ink-2,#cbd5e1);margin-top:8px">'
      + (c === 'cinema' ? '⚠️ 电影场景很花, 会盖住 boss 立绘 —— 想让 boss 更突出就选「深空」或「晨曦」'
                        : '现在打Boss的背景是干净的幕布, boss 立绘和文字都很突出 ✅')
      + '</div>';
    box.innerHTML = h;
    var sws = box.querySelectorAll('.hsn-bt-sw');
    for (var j = 0; j < sws.length; j++) {
      sws[j].onclick = (function (id) {
        return function () {
          apply(id);
          if (id === 'cinema') {
            try { restoreActiveCinema(); } catch (e) { }
          }
        };
      })(THEMES[j].id);
    }
  }

  apply(cur());
  guardCinema();

  function boot() {
    ensureCSS();
    guardCinema();
    syncCinema();

    try {
      if (document.body && window.MutationObserver && !document.body.__hsnBtClassObserver) {
        var classObserver = new MutationObserver(function (records) {
          for (var i = 0; i < records.length; i++) {
            if (records[i].attributeName === 'class') { syncCinema(); break; }
          }
        });
        classObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
        document.body.__hsnBtClassObserver = classObserver;
      }
    } catch (e) { }
    try { renderPicker(); } catch (e) { }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  window.addEventListener('load', function () { setTimeout(boot, 300); });

  (function hookShow() {
    if (typeof window.showScreen !== 'function') { return setTimeout(hookShow, 60); }
    if (window.__hsnBtHooked) return;
    window.__hsnBtHooked = true;
    var orig = window.showScreen;
    window.showScreen = function (id) {
      var r = orig.apply(this, arguments);
      if (id === 'settings') { try { renderPicker(); } catch (e) { } }
      try { ensureCSS(); guardCinema(); syncCinema(); } catch (e) { }
      return r;
    };
  })();

  window.HansenBossTheme = { apply: apply, get: cur, list: THEMES };
})();
