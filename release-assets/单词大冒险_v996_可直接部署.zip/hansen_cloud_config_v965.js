
window.HANSEN_CLOUD_CONFIG = {
  envId: '',
  region: ''
};
