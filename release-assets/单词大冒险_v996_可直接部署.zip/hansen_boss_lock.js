
window.__HBU_VERSION__ = 'v996';
window.__HBU_LOADED_AT__ = Date.now();

(function(){
  'use strict';

  window.__HBU_BOSS_CONFIG__ = [
    {lv:1,  timeLimit:60}, {lv:2,  timeLimit:55}, {lv:3,  timeLimit:50}, {lv:4,  timeLimit:45},
    {lv:5,  timeLimit:40}, {lv:6,  timeLimit:35}, {lv:7,  timeLimit:32}, {lv:8,  timeLimit:28},
    {lv:9,  timeLimit:25}, {lv:10, timeLimit:22}, {lv:11, timeLimit:20}, {lv:12, timeLimit:18},
    {lv:13, timeLimit:16}, {lv:14, timeLimit:15}, {lv:15, timeLimit:14}, {lv:16, timeLimit:13},
    {lv:17, timeLimit:12}, {lv:18, timeLimit:11}, {lv:19, timeLimit:10}, {lv:20, timeLimit:8}
  ];

  function _r(name){
    try {
      switch(name){
        case 'bossCurrent': return typeof bossCurrent !== 'undefined' ? bossCurrent : window.bossCurrent;
        case 'bossActive': return typeof bossActive !== 'undefined' ? bossActive : window.bossActive;
        case 'bossPhase': return typeof bossPhase !== 'undefined' ? bossPhase : window.bossPhase;
        case 'bossHP': return typeof bossHP !== 'undefined' ? bossHP : window.bossHP;
        case 'bossMaxHP': return typeof bossMaxHP !== 'undefined' ? bossMaxHP : window.bossMaxHP;
        case 'bossRageMode': return typeof bossRageMode !== 'undefined' ? bossRageMode : window.bossRageMode;
        case '_bossCorrectIdx': return typeof _bossCorrectIdx !== 'undefined' ? _bossCorrectIdx : window._bossCorrectIdx;
        case 'heroHP': return typeof heroHP !== 'undefined' ? heroHP : window.heroHP;
        case 'heroMaxHP': return typeof heroMaxHP !== 'undefined' ? heroMaxHP : window.heroMaxHP;
        case 'bossCombo': return typeof bossCombo !== 'undefined' ? bossCombo : window.bossCombo;
      }
    } catch(e){}
    return window[name];
  }
  function _w(name, val){
    try {
      if(name === 'bossHP'){
        if(typeof bossHP !== 'undefined') bossHP = val; else window.bossHP = val;
      } else if(name === 'heroHP'){
        if(typeof heroHP !== 'undefined') heroHP = val; else window.heroHP = val;
      }
    } catch(e){}
  }

  var BOSS_QUOTES = {
    '淘气小幽灵': '嘻嘻~ 抓不到我哦!',
    '暗影忍者':   '影舞步, 你看不见我!',
    '百战兽人':   '百战兽人在此, 拿出你的真本事!',
    '史前霸王龙': '远古巨兽苏醒, 颤抖吧!',
    '千年僵尸':   '沉睡在永恒诅咒中吧...',
    '暗夜吸血鬼': '今夜的血... 格外香甜~',
    '蒙面大魔王': '黑暗降临, 凡人颤抖!',
    '地狱犬王':   '三头之吼, 灵魂撕裂!',
    '黑森林巫婆': '尝尝老婆子的毒苹果吧, 嘿嘿嘿!',
    '异次元巫师': '维度崩塌! 异次元降临!',
    '龙骑士统帅': '巨龙之翼, 遮天蔽日!',
    '暗黑灯神':   '灵魂, 即是代价!',
    '海底巨怪':   '深渊呼唤, 沉入海底!',
    '寒冰女王':   '冬天是我的领域!',
    '烈焰魔神':   '焚尽万物, 化为灰烬!',
    '雷电之主':   '天雷怒吼, 闪电贯穿!',
    '机械泰坦':   '目标锁定, 执行清除!',
    '外星霸主':   '弱小地球人, 已被征服!',
    '混沌魔尊':   '深渊审判, 地狱之门开!',
    '上古太阳神':   '吾即万物之始, 臣服吧!'
  };

  var BOSS_TAUNTS = {

    '淘气小幽灵': [
      '嘻嘻嘻~ 抓我啊~', '我躲到云里啦!', '看不见我看不见我~', '想抓我? 没那么容易!',
      '捉迷藏开始啦~'
    ],
    '暗影忍者': [
      '影舞步, 现身!', '忍法, 隐身术!', '速度即是一切.', '看准时机, 一击!',
      '影分身之术!'
    ],
    '百战兽人': [
      '吼——! 又一个挑战者!', '我的战锤渴望胜利!', '为部落而战!', '百战不败, 岂会输你!',
      '让你见识真正的勇士!'
    ],
    '史前霸王龙': [
      '吼!!! 远古霸主驾到!', '化石才是你归宿!', '感受远古之力!', '巨齿撕裂万物!',
      '颤抖吧, 小生灵!'
    ],

    '千年僵尸': [
      '千年沉睡...', '古老咒语启动...', '永恒诅咒...', '腐烂气息缭绕...',
      '我已等候千年...', '古墓在呼唤...', '醒来吧, 沉睡者...'
    ],
    '暗夜吸血鬼': [
      '今夜月色真美~', '黑夜永恒, 我喜欢.', '请允许我尝一口~', '城堡欢迎你做客.',
      '你听见夜莺歌吗?', '古老伯爵向你问好.', '夜永远属于我.'
    ],
    '蒙面大魔王': [
      '哈哈哈... 凡人.', '面具下是谁? 猜啊!', '黑暗之力降临!', '你以为能赢?',
      '向魔王臣服吧!', '无人能识我面目.', '魔王的游戏开始!'
    ],
    '地狱犬王': [
      '嗷呜~ 三头之吼!', '三个头颅一齐袭!', '地狱的看门犬!', '颤抖吧, 小英雄!',
      '我能闻到你的恐惧.', '我守的是地狱之门!', '三头联攻无可挡!'
    ],

    '黑森林巫婆': [
      '老婆子的毒苹果, 尝一口吧!', '咕噜咕噜, 魔药煮沸啦!', '骑上扫帚, 看你往哪逃!', '黑森林的诅咒降临!',
      '我的小蝙蝠, 咬他!', '紫色魔焰, 烧成灰!', '熬了百年的毒药, 香吧?', '哈哈, 小娃娃也敢闯我森林?',
      '吃我一记魔法棒!'
    ],
    '异次元巫师': [
      '空间撕裂!', '维度崩塌!', '禁忌魔法吟唱!', '时空在我手中!',
      '异次元正打开!', '你将穿越虚空!', '维度法则被改写!', '我超越了三维!',
      '你看到的不是真实!'
    ],
    '龙骑士统帅': [
      '巨龙之翼遮天!', '龙焰焚天!', '跪下吧, 渺小者!', '龙骑士的荣耀!',
      '我的龙听我号令!', '战旗正在飘扬!', '千年传承的力量!', '战场上无人能敌!',
      '巨龙的怒火!'
    ],
    '暗黑灯神': [
      '三个愿望? 不可能!', '黑暗烟雾笼罩!', '你的灵魂归我!', '我是黑色的灯神!',
      '贪婪是你的代价!', '瓶中我蛰伏太久!', '金色烟雾在卷起!', '我已重获自由!',
      '命运由我玩弄!'
    ],

    '海底巨怪': [
      '八爪缠绕无处逃!', '深渊呼唤着你!', '海底千年之宿!', '触手无所不能!',
      '海水会淹没你!', '深渊之眼盯着你!', '回不去地面了!', '海洋是我的领地!',
      '波涛在咆哮!', '潜入更深处!', '张开大口吞噬!'
    ],
    '寒冰女王': [
      '冻结一切包括你!', '冰封万古之力!', '哈哈, 瑟瑟发抖了?', '冬天是我的领域!',
      '冰晶在飞舞!', '我冷若雪山顶!', '感受冰之吻!', '心已开始结冰!',
      '永冻之地, 欢迎!', '冰柱破空而来!', '我冰封一切色彩!'
    ],
    '烈焰魔神': [
      '焚尽世间一切!', '烈火地狱降临!', '我即火焰本身!', '感受灼烧之力!',
      '燃烧吧, 一切!', '火山在脚下苏醒!', '我的怒火无可挡!', '炎之印记!',
      '热浪滚滚而来!', '我从地心而来!', '焰之裁决!'
    ],
    '雷电之主': [
      '天雷轰顶!', '闪电之力无敌!', '颤抖吧, 凡人!', '雷神降临!',
      '电光在我指尖!', '雷霆万钧!', '听这天雷怒吼!', '云端是我的宝座!',
      '霹雳! 一击!', '我是九天之主!', '暴雷即将袭来!'
    ],

    '机械泰坦': [
      '系统在线!', '目标已锁定!', '清除程序启动...', '执行: 清除程序.',
      '系统启动 100%.', '你的算法太弱.', '运算速度无限.', '钢铁不会疲倦.',
      '警告: 检测到人类!', '数据采集中...', '防御系统激活.', '漏洞已锁定.',
      '终极协议启动!'
    ],
    '外星霸主': [
      '你的星球归我了!', '宇宙最强生物!', '弱小地球人!', '我穿越光年而来!',
      '你们科技真原始!', '母舰已就位!', '扫描你!', '投降吧, 地球人!',
      '宇宙的征服者!', '你的智商太低!', '我曾征服七大星系!', '你这生物真有趣!',
      '银河尽在我掌!'
    ],
    '混沌魔尊': [
      '深渊审判!', '地狱之门已开启!', '我即黑暗本身!', '千年王座的主人!',
      '万物归我支配!', '黑色火焰燃尽一切!', '听这绝望的呼啸!', '终焉降临!',
      '我曾撼动神祇!', '无人能逃我之掌!', '审判的钟声敲响!', '一切化为虚无!',
      '黑暗将吞噬光明!'
    ],
    '上古太阳神': [
      '吾即是万物之始!', '宇宙在我掌中!', '凡人终须臣服!', '我先于时间而存!',
      '我即是法则!', '群星向我朝拜!', '在我面前神也卑微!', '我观看了万古更替!',
      '时空因我而存!', '我创造亦能毁灭!', '原初之力!', '凡人勿与我对视!',
      '我即是开端与终结!'
    ]
  };

  function getRandomTaunt(b){
    if(!b) return '';
    var arr = (b.name && BOSS_TAUNTS[b.name]) ? BOSS_TAUNTS[b.name] : (b.taunts || []);
    if(!arr.length) return '';
    return arr[Math.floor(Math.random() * arr.length)];
  }

  var lastTauntTime = 0;
  var lastTauntText = '';
  function getThrottledTaunt(b){
    var now = Date.now();
    if(now - lastTauntTime < 3000 && lastTauntText){

      return lastTauntText;
    }

    var taunt = getRandomTaunt(b);
    if(taunt){
      lastTauntText = '💬 ' + taunt;
      lastTauntTime = now;
    }
    return lastTauntText;
  }

  function resetTauntThrottle(text){
    lastTauntTime = Date.now();
    lastTauntText = text || '';
  }

  function fitBossMsg(){
    var el = document.getElementById('bossMsg');
    if(!el || el.__fittingMsg) return;
    el.__fittingMsg = true;
    try {
      var inner = el.firstElementChild;
      var wrapped = !!(inner && inner.classList && inner.classList.contains('boss-msg-inner') && el.childNodes.length === 1);
      if(!wrapped){
        if(el.innerHTML.indexOf('boss-msg-inner') === -1){
          el.innerHTML = '<span class="boss-msg-inner">' + el.innerHTML + '</span>';
        }
        inner = el.firstElementChild;
      }
      if(inner){
        inner.style.transform = 'none';
        var content = inner.scrollWidth || inner.offsetWidth;
        var vw = window.innerWidth || document.documentElement.clientWidth || 360;
        var avail = vw - 52;
        if(avail > 40 && content > avail){
          inner.style.transform = 'scale(' + (avail / content).toFixed(4) + ')';
        }
      }
    } catch(e){}
    el.__fittingMsg = false;
  }
  window.HansenFitBossMsg = fitBossMsg;

  function setBossMsg(content){
    var msgEl = document.getElementById('bossMsg');
    if(!msgEl) return;
    msgEl.innerHTML = content;
    msgEl.className = 'boss-msg';
    fitBossMsg();
  }

  var isStartingBoss = false;

    var bossConfig = [

    {wrongExtra:0,   timeLimit:60, askAll:false, rewardMult:1.0, intro:'⏰ 60 秒 入门小怪 ✏️'},

    {wrongExtra:5,   timeLimit:55, askAll:false, rewardMult:1.0, intro:'⏰ 55 秒 英汉互译 🔁'},

    {wrongExtra:10,  timeLimit:50, askAll:false, rewardMult:1.2, intro:'⏰ 50 秒 忍者出招 🥷'},

    {wrongExtra:15,  timeLimit:45, askAll:false, rewardMult:1.3, intro:'⏰ 45 秒 黑魔法登场 🧙'},

    {wrongExtra:20,  timeLimit:40, askAll:false, rewardMult:1.4, intro:'⏰ 40 秒 灯神召唤!'},

    {wrongExtra:25,  timeLimit:35, askAll:false, rewardMult:1.6, intro:'⏰ 35 秒 史前霸主!'},

    {wrongExtra:30,  timeLimit:32, askAll:false, rewardMult:1.8, intro:'⏰ 32 秒 神秘大魔王!'},

    {wrongExtra:35,  timeLimit:28, askAll:false, rewardMult:2.0, intro:'⏰ 28 秒 三头犬王!'},

    {wrongExtra:40,  timeLimit:25, askAll:false, rewardMult:2.2, intro:'⏰ 25 秒 冰冻全场!'},

    {wrongExtra:45,  timeLimit:22, askAll:false, rewardMult:2.4, intro:'⏰ 22 秒 烈焰焚身!'},

    {wrongExtra:50,  timeLimit:20, askAll:false, rewardMult:2.6, intro:'⏰ 20 秒 雷霆万钧!'},

    {wrongExtra:55,  timeLimit:18, askAll:false, rewardMult:2.8, intro:'⏰ 18 秒 深渊降临!'},

    {wrongExtra:60,  timeLimit:16, askAll:false, rewardMult:3.0, intro:'⏰ 16 秒 鲜血诅咒!'},

    {wrongExtra:65,  timeLimit:15, askAll:false, rewardMult:3.2, intro:'⏰ 15 秒 古老恐惧!'},

    {wrongExtra:70,  timeLimit:14, askAll:false, rewardMult:3.5, intro:'⏰ 14 秒 维度崩塌!'},

    {wrongExtra:75,  timeLimit:13, askAll:false, rewardMult:3.8, intro:'⏰ 13 秒 钢铁洪流!'},

    {wrongExtra:80,  timeLimit:12, askAll:false, rewardMult:4.0, intro:'⏰ 12 秒 星际侵略!'},

    {wrongExtra:85,  timeLimit:11, askAll:false, rewardMult:4.3, intro:'⏰ 11 秒 龙翼蔽天!'},

    {wrongExtra:90,  timeLimit:10, askAll:true,  rewardMult:4.6, intro:'⏰ 10 秒 + 全岛词覆盖!'},

    {wrongExtra:99,  timeLimit:8,  askAll:true,  rewardMult:5.0, intro:'⚠️ 终极: 全岛词 + 8 秒 + 答错半血!'},
  ];

  function getBossLevel(){
    try {
      var lvl = Math.max(0, (window.S && window.S.level || 1) - 1);
      return Math.min(lvl, bossConfig.length - 1);
    } catch(e){ return 0; }
  }
  function getBossCfg(){

    try {
      if(/island_season\.html/.test(location.pathname||'')){
        var _sN814 = (window._hansenRebattleLv>=1) ? Math.min(6, window._hansenRebattleLv|0) : 1;
        var _si814 = (_sN814>=6) ? '赛尔娅终极 · 240 词总复习!' : '星海词汇守关挑战!';
        return { wrongExtra:0, timeLimit:0, askAll:false, rewardMult:1.5, intro:_si814 };
      }
    } catch(e){}
    return bossConfig[getBossLevel()] || bossConfig[0];
  }

  var timerInterval = null;
  var timerToken = 0;
  var pollInterval = null;

  var bossSessionToken = 0;

  var lastNextBossQAt = 0;

  var _bossQWdInterval = null;

  var _lastAnswerAt = 0;

  function clearTimer(){
    timerToken++;
    if(timerInterval){ clearTimeout(timerInterval); timerInterval = null; }
    var fill = document.getElementById('bossTimerFill');
    if(fill){
      fill.style.setProperty('transition', 'transform 0.3s ease-out', 'important');
      fill.style.transform = 'scaleX(1)';
    }
  }

  function hideTimer(){
    timerToken++;
    if(timerInterval){ clearTimeout(timerInterval); timerInterval = null; }
    var el = document.getElementById('bossTimerEl');
    if(el) el.style.display = 'none';
  }

  var NEW_MODE_PROB = 0.30;

  function getNewModeProb(){
    if(typeof window.__hbuNewModeProb === 'number') return window.__hbuNewModeProb;
    return NEW_MODE_PROB;
  }

  var CH5_TYPING_PROB = 0.50;
  function pickChapterMode(level){

    if(level >= 17 && Math.random() < CH5_TYPING_PROB) return 'typing';

    if(Math.random() >= getNewModeProb()) return null;

    var pool = [];
    if(level >= 5)  pool.push('spellFill');
    if(level >= 9)  pool.push('spellPick');
    if(level >= 13) pool.push('sentTrans');
    if(level >= 17) pool.push('typing');

    if(pool.length === 0) return null;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  function applyChapterMode(){
    var w = window._bossWord;
    if(!w || !w.en) return;

    try { var _ar = document.querySelector('.boss-arena'); if(_ar) { _ar.classList.remove('bts-typing'); _ar.classList.remove('bts-compact'); } } catch(e){}
    try { var _bo = document.getElementById('bossOpts'); if(_bo){ _bo.style.display=''; _bo.style.gridTemplateColumns=''; _bo.style.width=''; _bo.style.maxWidth=''; _bo.style.marginLeft=''; _bo.style.marginRight=''; _bo.style.gap=''; } } catch(e){}
    if(window._btsKeyHandler){ try { document.removeEventListener('keydown', window._btsKeyHandler); } catch(e){} window._btsKeyHandler = null; }

    var level;

    if(/island_land[1-8]\.html/.test(location.pathname||'') && window._s1Idx != null){
      level = Math.max(1, Math.min(20, ((window._s1Idx|0)+1)*4));
    } else if(window._hansenRebattleLv != null && window._hansenRebattleLv >= 1){
      level = window._hansenRebattleLv;
    } else {
      level = (window.S && window.S.level) || 1;
    }
    var mode = pickChapterMode(level);
    if(!mode) return;

    if(mode === 'spellFill'  && w.en.length < 5) return;
    if(mode === 'spellPick'  && w.en.length < 4) return;
    if(mode === 'sentTrans'  && (!w.ex || !w.exCn || w.exCn.length < 4)) return;
    if(mode === 'typing'     && w.en.length < 3) return;

    if(mode === 'spellFill') applySpellFill(w);
    else if(mode === 'spellPick') applySpellPick(w);
    else if(mode === 'sentTrans') applySentTrans(w);
    else if(mode === 'typing')    applyTyping(w);
  }

  function shuffleArr(a){
    for(var i = a.length - 1; i > 0; i--){
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function esc(s){
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  var _bts3dSeq = 0;
  function icon3dCheck(size){
    var s = size || 30; var id = 'btsck' + (_bts3dSeq++);
    return '<svg width="'+s+'" height="'+s+'" viewBox="0 0 48 48" style="vertical-align:middle;display:inline-block;filter:drop-shadow(0 3px 4px rgba(0,0,0,0.45))">' +
      '<defs>' +
        '<radialGradient id="'+id+'g" cx="38%" cy="32%" r="75%">' +
          '<stop offset="0%" stop-color="#86efac"/><stop offset="45%" stop-color="#22c55e"/><stop offset="100%" stop-color="#15803d"/>' +
        '</radialGradient>' +
        '<linearGradient id="'+id+'h" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0%" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="55%" stop-color="#ffffff" stop-opacity="0"/>' +
        '</linearGradient>' +
      '</defs>' +
      '<circle cx="24" cy="24" r="22" fill="url(#'+id+'g)" stroke="#0a5a2a" stroke-width="1.2"/>' +
      '<ellipse cx="24" cy="16" rx="16" ry="9" fill="url(#'+id+'h)"/>' +
      '<path d="M14 25 l7 7 l14 -16" fill="none" stroke="#0a4d23" stroke-width="6.5" stroke-linecap="round" stroke-linejoin="round" opacity="0.35" transform="translate(0,1.5)"/>' +
      '<path d="M14 25 l7 7 l14 -16" fill="none" stroke="#ffffff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</svg>';
  }
  function icon3dCross(size){
    var s = size || 30; var id = 'btsx' + (_bts3dSeq++);
    return '<svg width="'+s+'" height="'+s+'" viewBox="0 0 48 48" style="vertical-align:middle;display:inline-block;filter:drop-shadow(0 3px 4px rgba(0,0,0,0.45))">' +
      '<defs>' +
        '<radialGradient id="'+id+'g" cx="38%" cy="32%" r="75%">' +
          '<stop offset="0%" stop-color="#fca5a5"/><stop offset="45%" stop-color="#ef4444"/><stop offset="100%" stop-color="#b91c1c"/>' +
        '</radialGradient>' +
        '<linearGradient id="'+id+'h" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0%" stop-color="#ffffff" stop-opacity="0.75"/><stop offset="55%" stop-color="#ffffff" stop-opacity="0"/>' +
        '</linearGradient>' +
      '</defs>' +
      '<circle cx="24" cy="24" r="22" fill="url(#'+id+'g)" stroke="#7a1414" stroke-width="1.2"/>' +
      '<ellipse cx="24" cy="16" rx="16" ry="9" fill="url(#'+id+'h)"/>' +
      '<path d="M16 16 l16 16 M32 16 l-16 16" fill="none" stroke="#6e1010" stroke-width="6.5" stroke-linecap="round" opacity="0.35" transform="translate(0,1.5)"/>' +
      '<path d="M16 16 l16 16 M32 16 l-16 16" fill="none" stroke="#ffffff" stroke-width="6" stroke-linecap="round"/>' +
      '</svg>';
  }

  function applySpellFill(w){
    var en = w.en.toLowerCase();
    var holeLen = en.length >= 7 ? 3 : 2;
    var maxStart = en.length - holeLen - 1;
    if(maxStart < 1) return;
    var holeStart = 1 + Math.floor(Math.random() * maxStart);

    var prefix = en.substring(0, holeStart);
    var hole = en.substring(holeStart, holeStart + holeLen);
    var suffix = en.substring(holeStart + holeLen);

    var choices = [hole];
    var letters = 'abcdefghijklmnopqrstuvwxyz';
    var attempts = 0;
    while(choices.length < 4 && attempts < 30){
      attempts++;
      var d = '';
      for(var i = 0; i < holeLen; i++){
        d += letters.charAt(Math.floor(Math.random() * 26));
      }
      if(choices.indexOf(d) < 0) choices.push(d);
    }

    var fbi = 0;
    while(choices.length < 4){
      var fallback = '';
      for(var fi = 0; fi < holeLen; fi++){
        fallback += letters.charAt((fbi + fi) % 26);
      }
      fbi++;
      if(choices.indexOf(fallback) < 0) choices.push(fallback);
      if(fbi > 50) break;
    }

    shuffleArr(choices);
    var correctIdx = choices.indexOf(hole);

    var bq = document.getElementById('bossQ');
    var bs = document.getElementById('bossQSub');
    var bo = document.getElementById('bossOpts');
    var bqt = document.getElementById('bossQType');
    if(!bq || !bs || !bo) return;

    if(bqt) bqt.textContent = '🎯 拼写补全';
    bq.innerHTML =
      '<div class="boss-answer-primary" style="font-size:18px;font-weight:900;color:#fbbf24;margin-bottom:5px;text-shadow:0 0 12px rgba(251,191,36,0.4)">' + esc(w.cn || '') + '</div>' +
      '<div class="boss-answer-kicker" style="font-size:10px;color:#cbd5e1;margin-bottom:2px">补全英文 (缺 ' + holeLen + ' 个字母):</div>' +
      '<div id="bsfBox" class="boss-answer-box" style="font-size:18px;font-weight:900;letter-spacing:2px;color:#fff;font-family:Consolas,monospace;background:rgba(15,23,42,0.85);padding:5px 12px;border-radius:9px;border:2px solid #6366f1;display:inline-block">' +
      prefix +
      '<span id="bsfHole" class="boss-answer-hole" style="color:#1e293b;background:#fbbf24;padding:0 5px;border-radius:4px;margin:0 2px">' + new Array(holeLen + 1).join('_') + '</span>' +
      suffix + '</div>';
    bs.innerHTML = '';

    window._bsfPrefix = prefix; window._bsfHole = hole; window._bsfSuffix = suffix;

    try { var _ar3 = document.querySelector('.boss-arena'); if(_ar3) _ar3.classList.remove('bts-compact'); } catch(e){}

    bo.style.display = '';
    bo.style.gridTemplateColumns = 'repeat(2, 1fr)';
    bo.style.gap = '5px';
    bo.innerHTML = choices.map(function(c, i){
      return '<div class="boss-opt boss-answer-choice" onclick="bossAnswer(' + i + ')" style="font-size:15px;font-weight:900;letter-spacing:2px;font-family:Consolas,monospace;color:#fbbf24;text-align:center;padding:7px 6px">' + c + '</div>';
    }).join('');
    bo.dataset.done = '';

    window._bossCorrectIdx = correctIdx;
    window._bossQType = 'spellFill';
  }

  function applySpellPick(w){
    var en = w.en.toLowerCase();

    var scrambled = en;
    var sAtt = 0;
    while(scrambled === en && sAtt < 30){
      scrambled = shuffleArr(en.split('')).join('');
      sAtt++;
    }

    if(scrambled === en) scrambled = en.split('').reverse().join('');

    var choices = [en];
    var att = 0;
    while(choices.length < 6 && att < 80){
      att++;
      var d = shuffleArr(en.split('')).join('');
      if(d !== en && choices.indexOf(d) < 0) choices.push(d);
    }

    var letters = 'abcdefghijklmnopqrstuvwxyz';
    while(choices.length < 6){
      var arr = en.split('');
      arr[Math.floor(Math.random() * arr.length)] = letters.charAt(Math.floor(Math.random() * 26));
      var d2 = arr.join('');
      if(d2 !== en && choices.indexOf(d2) < 0) choices.push(d2);
      if(choices.length === 5 && d2 === en) choices.push(letters.charAt(0));
    }

    shuffleArr(choices);
    var correctIdx = choices.indexOf(en);

    var bq = document.getElementById('bossQ');
    var bs = document.getElementById('bossQSub');
    var bo = document.getElementById('bossOpts');
    var bqt = document.getElementById('bossQType');
    if(!bq || !bs || !bo) return;

    if(bqt) bqt.textContent = '🔤 拼字辨认 · 6 选 1';
    bq.innerHTML =
      '<div class="boss-answer-kicker" style="font-size:11px;color:#cbd5e1;margin-bottom:1px">中文意思:</div>' +
      '<div class="boss-answer-primary" style="font-size:18px;font-weight:900;color:#fbbf24;margin-bottom:2px;text-shadow:0 0 12px rgba(251,191,36,0.4)">' + esc(w.cn || '') + '</div>' +
      '<div class="boss-answer-kicker" style="font-size:11px;color:#cbd5e1;margin-bottom:1px">乱序字母 (选出正确拼写):</div>' +
      '<div class="boss-answer-secondary boss-answer-box" style="font-size:18px;font-weight:900;letter-spacing:3px;color:#fbbf24;font-family:Consolas,monospace;background:rgba(15,23,42,0.85);padding:3px 12px;border-radius:9px;border:2px dashed #a855f7;display:inline-block">' + scrambled + '</div>';
    bs.innerHTML = '';

    try { var _ar2 = document.querySelector('.boss-arena'); if(_ar2) _ar2.classList.remove('bts-compact'); } catch(e){}

    bo.style.display = '';
    bo.style.gridTemplateColumns = 'repeat(3, 1fr)';
    bo.style.gap = '5px';
    bo.innerHTML = choices.map(function(c, i){
      return '<div class="boss-opt boss-answer-choice" onclick="bossAnswer(' + i + ')" style="font-size:14px;font-weight:800;font-family:Consolas,monospace;color:#fbbf24;text-align:center;padding:6px 3px">' + c + '</div>';
    }).join('');
    bo.dataset.done = '';

    window._bossCorrectIdx = correctIdx;
    window._bossQType = 'spellPick';
  }

  function applySentTrans(w){
    var allW = window.allW || window.WORDS || [];
    if(!Array.isArray(allW) || allW.length < 10) return;

    var distractors = [];
    var seenText = {};
    seenText[w.ex] = true;
    var att = 0;
    while(distractors.length < 3 && att < 80){
      att++;
      var other = allW[Math.floor(Math.random() * allW.length)];
      if(other && other.ex && other.ex.length > 10 && !seenText[other.ex]){
        distractors.push(other.ex);
        seenText[other.ex] = true;
      }
    }
    if(distractors.length < 3) return;

    var choices = [w.ex].concat(distractors);
    shuffleArr(choices);
    var correctIdx = choices.indexOf(w.ex);

    var bq = document.getElementById('bossQ');
    var bs = document.getElementById('bossQSub');
    var bo = document.getElementById('bossOpts');
    var bqt = document.getElementById('bossQType');
    if(!bq || !bs || !bo) return;

    if(bqt) bqt.textContent = '📜 句子翻译';

    bq.innerHTML =
      '<div style="text-align:center"><div class="boss-answer-primary boss-answer-box" style="display:inline-block;font-size:16px;font-weight:700;color:#fbbf24;background:rgba(15,23,42,0.85);padding:3px 14px;border-radius:8px;border:2px solid #ef4444;line-height:1.3;max-width:100%">' + esc(w.exCn) + '</div></div>';
    bs.innerHTML = '选出正确的英文翻译';

    bo.style.display = '';
    bo.style.gridTemplateColumns = '1fr';
    bo.style.gap = '5px';
    bo.innerHTML = choices.map(function(c, i){
      return '<div class="boss-opt boss-answer-choice" onclick="bossAnswer(' + i + ')" style="padding:9px 12px;text-align:left;font-size:12.5px;line-height:1.4">' +
        '<span class="boss-answer-choice-label" style="color:#fbbf24;font-weight:900;margin-right:6px">' + 'ABCD'.charAt(i) + '.</span>' +
        '<span class="boss-answer-choice-text" style="color:#fff">' + esc(c) + '</span></div>';
    }).join('');
    bo.dataset.done = '';

    window._bossCorrectIdx = correctIdx;
    window._bossQType = 'sentTrans';
  }

  var _btsTyped = '';

  function bossKeyboardHtml(){
    var rows = [['q','w','e','r','t','y','u','i','o','p'],['a','s','d','f','g','h','j','k','l'],['z','x','c','v','b','n','m']];
    var k = '<div class="keyboard" id="btsKbd">';
    k += '<div class="keyboard-row">'; rows[0].forEach(function(l){ k += '<button class="key" data-k="'+l+'" type="button">'+l+'</button>'; }); k += '</div>';
    k += '<div class="keyboard-row indent">'; rows[1].forEach(function(l){ k += '<button class="key" data-k="'+l+'" type="button">'+l+'</button>'; }); k += '</div>';
    k += '<div class="keyboard-row">'; rows[2].forEach(function(l){ k += '<button class="key" data-k="'+l+'" type="button">'+l+'</button>'; }); k += '<button class="key delete" data-act="del" type="button">&#9003;</button></div>';
    k += '</div>';
    return k;
  }

  function applyTyping(w){
    var bq = document.getElementById('bossQ');
    var bs = document.getElementById('bossQSub');
    var bo = document.getElementById('bossOpts');
    var bqt = document.getElementById('bossQType');
    if(!bq || !bs || !bo) return;

    window._hansenTypingSubmitting = false;
    _btsTyped = '';

    try { var ar = document.querySelector('.boss-arena'); if(ar) ar.classList.add('bts-typing'); } catch(e){}

    bq.innerHTML =
      '<div class="boss-answer-kicker" style="font-size:10px;color:#cbd5e1;margin-bottom:2px">\u770b\u4e2d\u6587\u610f\u601d, \u62fc\u51fa\u82f1\u6587:</div>' +
      '<div class="boss-answer-primary" style="font-size:18px;font-weight:900;color:#fbbf24;line-height:1.05;text-shadow:0 0 12px rgba(251,191,36,0.5)">' + esc(w.cn || '') + '</div>';
    bs.innerHTML = '';

    var target = (w.en || '').toLowerCase();
    var targetLetters = target.replace(/ /g, '').length;

    var slotsHtml = '';
    target.split('').forEach(function(ch, i){
      if(ch === ' ') slotsHtml += '<div class="bts-slot space" id="btsSlot'+i+'"></div>';
      else slotsHtml += '<div class="bts-slot" id="btsSlot'+i+'"></div>';
    });

    bo.style.display = 'block';
    bo.style.gridTemplateColumns = '';
    bo.innerHTML =
      '<div class="boss-opt" style="display:none"></div>' +
      '<div class="bts-row">' +
        '<div class="bts-slots" id="btsSlots">' + slotsHtml + '</div>' +
      '</div>' +
      '<div id="btsHint" class="bts-hint-below"></div>' +
      bossKeyboardHtml();
    bo.dataset.done = '';
    window._bossQType = 'typing';

    function fillSlots(){
      var idx = 0;
      for(var i = 0; i < target.length; i++){
        var el = document.getElementById('btsSlot'+i);
        if(!el) continue;
        if(target[i] === ' '){ el.textContent = ' '; continue; }
        if(idx < _btsTyped.length){ el.textContent = _btsTyped[idx]; el.classList.add('filled'); }
        else { el.textContent = ''; el.classList.remove('filled'); }
        idx++;
      }
    }
    function btsKey(l){
      if(bo.dataset.done) return;
      if(_btsTyped.length >= targetLetters) return;
      _btsTyped += l;
      fillSlots();
      try { if(window.playBeep) window.playBeep(700 + _btsTyped.length * 40, 0.04); } catch(e){}
      if(_btsTyped.length >= targetLetters){ setTimeout(function(){ submitTyping(); }, 220); }
    }
    function btsDel(){
      if(bo.dataset.done) return;
      if(_btsTyped.length === 0) return;
      _btsTyped = _btsTyped.slice(0, -1);
      fillSlots();
    }
    function btsHint(){
      if(bo.dataset.done) return;
      var ns = target.replace(/ /g, '');
      if(_btsTyped.length < ns.length){
        _btsTyped += ns[_btsTyped.length];
        fillSlots();
        var h = document.getElementById('btsHint');
        if(h){ h.textContent = '\ud83d\udca1 \u5df2\u586b\u5165\u4e00\u4e2a\u5b57\u6bcd'; setTimeout(function(){ if(h) h.textContent = ''; }, 1200); }
        if(_btsTyped.length >= targetLetters){ setTimeout(function(){ submitTyping(); }, 220); }
      }
    }

    var kbd = document.getElementById('btsKbd');
    if(kbd){
      kbd.addEventListener('click', function(e){
        var btn = e.target;
        if(!btn || !btn.classList || !btn.classList.contains('key')) return;
        if(btn.dataset.k) btsKey(btn.dataset.k);
        else if(btn.dataset.act === 'del') btsDel();
        else if(btn.dataset.act === 'hint') btsHint();
      });
    }

    if(window._btsKeyHandler){ try { document.removeEventListener('keydown', window._btsKeyHandler); } catch(e){} window._btsKeyHandler = null; }
    window._btsKeyHandler = function(e){
      if(bo.dataset.done) return;
      if(e.key === 'Backspace'){ e.preventDefault(); btsDel(); }
      else if(e.key === 'Enter'){ e.preventDefault(); if(_btsTyped.length >= targetLetters) submitTyping(); }
      else if(/^[a-zA-Z]$/.test(e.key)){ btsKey(e.key.toLowerCase()); }
    };
    document.addEventListener('keydown', window._btsKeyHandler);
  }

  function submitTyping(){
    var w = window._bossWord;
    if(!w) return;
    var bo = document.getElementById('bossOpts');
    if(bo && bo.dataset.done) return;
    if(window._hansenTypingSubmitting) return;
    window._hansenTypingSubmitting = true;

    var userInput = (_btsTyped || '').toLowerCase().trim();
    var correctEn = (w.en || '').toLowerCase().replace(/ /g, '').trim();
    var isRight = userInput === correctEn;

    window._bossCorrectIdx = isRight ? 0 : 1;

    try {
      var slots = document.querySelectorAll('.bts-slot');
      var col = isRight ? '#22c55e' : '#ef4444';
      for(var i = 0; i < slots.length; i++){
        if(!slots[i].classList.contains('space')){
          slots[i].style.borderBottomColor = col;
          slots[i].style.color = col;
          slots[i].classList.remove('boss-answer-result-correct', 'boss-answer-result-wrong');
          slots[i].classList.add(isRight ? 'boss-answer-result-correct' : 'boss-answer-result-wrong');
        }
      }
    } catch(e){}
    var hint = document.getElementById('btsHint');
    if(hint){
      hint.classList.remove('boss-answer-result-correct', 'boss-answer-result-wrong');
      hint.classList.add(isRight ? 'boss-answer-result-correct' : 'boss-answer-result-wrong');
      if(isRight) hint.innerHTML = icon3dCheck(30) + ' <span style="color:#22c55e;font-family:Consolas,monospace;letter-spacing:1px;vertical-align:middle">' + esc(w.en) + '</span>';
      else hint.innerHTML = icon3dCross(30) + ' <span style="color:#ef4444;font-family:Consolas,monospace;letter-spacing:1px;vertical-align:middle">' + esc(w.en) + '</span>';
    }

    if(window._btsKeyHandler){ try { document.removeEventListener('keydown', window._btsKeyHandler); } catch(e){} window._btsKeyHandler = null; }

    if(typeof window.bossAnswer === 'function'){ window.bossAnswer(0); }
    setTimeout(function(){ window._hansenTypingSubmitting = false; }, 100);
  }
  window.hansenSubmitTyping = submitTyping;

  (function injectBtsCss(){
    function doInject(){
      try {
        if(document.getElementById('bts-typing-css')) return;
        var st = document.createElement('style');
        st.id = 'bts-typing-css';
        st.textContent =

          'body.hsn-boss-battle{overflow:hidden!important}' +
          'body.hsn-boss-battle .bottom-nav{display:none!important}' +
          'body.hsn-boss-battle .app{padding-bottom:0!important}' +
          'body.hsn-boss-battle #bossScreen{padding-bottom:0!important}' +
          'body.hsn-boss-battle #bossScreen .screen-title{display:none!important}' +
          'body.hsn-boss-noheader .top-bar{display:none!important}' +
          'body.hsn-boss-noheader .app{padding-top:0!important}' +
          'body.hsn-boss-noheader .world-map-btn{display:none!important}' +
          '.boss-arena.bts-typing .boss-sprite,.boss-arena.bts-typing .boss-sprite-wrap{width:230px!important;height:230px!important;font-size:230px!important}' +
          '.boss-arena.bts-typing .boss-sprite svg{width:230px!important;height:230px!important;transform:scale(.9304)!important;transform-origin:50% 100%!important}' +
          '#bossScreen .boss-arena.bts-typing .boss-sprite-wrap{margin:34px 0 0!important}'   +
          '.boss-arena.bts-typing .boss-q-type{display:none!important}' +
          '.boss-arena.bts-typing .boss-name{font-size:13px;margin:1px 0}' +
          '.boss-arena.bts-typing .boss-hp-bar{margin:2px auto}' +
          '.boss-arena.bts-typing .boss-hp-text{font-size:11px}' +
          '.boss-arena.bts-typing .boss-divider{margin:2px 0}' +
          '.boss-arena.bts-typing .hero-section{margin:1px -11px!important;padding:1px 2px!important}' +
          '.boss-arena.bts-typing .boss-msg{display:none}' +

          '.boss-arena.bts-typing .boss-stats-bar{flex-wrap:nowrap!important;height:24px;overflow:hidden;font-size:10px;margin-bottom:1px}' +
          '.boss-arena.bts-typing .boss-combo,.boss-arena.bts-typing .boss-phase-tag,.boss-arena.bts-typing .boss-rage-tag{padding:2px 6px!important;font-size:10px!important;white-space:nowrap}' +
          '.boss-arena.bts-typing .boss-q-type{margin:2px auto}' +
          '.bts-row{position:relative;display:flex;align-items:center;justify-content:center;margin:2px 0 1px}' +
          '.bts-slots{display:flex;gap:5px;justify-content:center;margin:0}' +
          '.bts-hint-below{text-align:center;font-size:22px;font-weight:900;min-height:12px;margin:2px 0;line-height:1.15}' +
          '.bts-slot{min-width:24px;height:32px;padding:0 4px;border-bottom:4px solid #475569;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:800;color:#fff;text-transform:lowercase;transition:border-color .15s,color .15s}' +
          '.bts-slot.filled{border-bottom-color:#fbbf24;color:#fbbf24}' +
          '.bts-slot.space{border-bottom-color:transparent;min-width:12px}' +

          '.boss-arena.bts-typing #bossOpts{display:block!important;max-width:none!important;width:100vw!important;margin-left:calc(-50vw + 50%)!important;margin-right:0!important;grid-template-columns:none!important}' +
          '#btsKbd{--kg:3px;--kw:calc((100vw - 4px - 9*var(--kg)) / 10);width:100vw;max-width:100vw;margin:8px 0 0;background:#d1d5db;padding:6px 2px 8px;box-sizing:border-box}' +
          '#btsKbd .keyboard-row{display:flex;gap:var(--kg);justify-content:center;margin-bottom:3px}' +
          '#btsKbd .keyboard-row.indent{padding:0}' +
          '#btsKbd .key{flex:0 0 auto;width:var(--kw);height:46px;background:#fff;border:none;border-radius:5px;color:#1c1c1e;font-size:23px;font-weight:500;box-shadow:0 1px 0 rgba(0,0,0,.3);padding:0;text-transform:lowercase}' +
          '#btsKbd .key.delete{width:calc(var(--kw) * 1.5 + var(--kg) * 0.5);background:#aeb3bd;font-size:19px}' +
          '.bts-row,.bts-hint-below{max-width:100vw}' +

            '' +

          '@media (max-height:729px){#btsKbd .key{height:34px!important;font-size:19px!important}#btsKbd{margin-top:4px!important;padding:4px 2px 5px!important}#btsKbd .keyboard-row{margin-bottom:3px!important}.boss-arena.bts-typing .hero-section{margin:0 -11px!important;padding:0 2px!important}.boss-arena.bts-typing .bts-hint-below{min-height:10px!important;margin:1px 0!important}.boss-arena.bts-typing .boss-hp-bar{margin:1px auto!important}}' + '@media (max-height:679px){#btsKbd .key{height:28px!important;font-size:17px!important}#btsKbd{margin-top:1px!important;padding:2px 2px 3px!important}#btsKbd .keyboard-row{margin-bottom:2px!important}.boss-arena.bts-typing .bts-slot{height:24px!important;font-size:18px!important}.boss-arena.bts-typing .bts-hint-below{min-height:8px!important;margin:0!important}.boss-arena.bts-typing .hero-section{margin:0 -11px!important;padding:0!important}}' +

          '.boss-arena.bts-compact .boss-sprite,.boss-arena.bts-compact .boss-sprite-wrap{width:230px!important;height:230px!important;font-size:230px!important}' +
          '.boss-arena.bts-compact .boss-sprite svg{width:230px!important;height:230px!important;transform:scale(.9304)!important;transform-origin:50% 100%!important}' +
          '#bossScreen .boss-arena.bts-compact .boss-sprite-wrap{margin:34px 0 0!important}'   +
          '.boss-arena.bts-compact .boss-name{font-size:14px;margin:1px 0}' +
          '.boss-arena.bts-compact .boss-hp-bar{margin:2px auto}' +
          '.boss-arena.bts-compact .boss-hp-text{font-size:11px}' +
          '.boss-arena.bts-compact .boss-divider{margin:2px 0}' +
          '.boss-arena.bts-compact .hero-section{margin:2px -11px;padding:3px 2px}' +
          '.boss-arena.bts-compact .boss-msg{display:none}' +
          '.boss-arena.bts-compact .boss-q-type{margin:2px auto}';
        (document.head || document.documentElement).appendChild(st);
      } catch(e){}
    }
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', doInject);
    else doInject();
  })();

  function startTimer(seconds, onTimeout){
    clearTimer();
    var myToken = timerToken;
    var subEl = document.getElementById('bossQSub');
    if(!subEl) return;

    var el = document.getElementById('bossTimerEl');
    if(!el){
      el = document.createElement('div');
      el.id = 'bossTimerEl';

      el.style.cssText = 'height:3px;width:100%;max-width:360px;margin:3px auto;background:rgba(15,23,42,0.85);border-radius:2px;overflow:hidden;position:relative;box-shadow:inset 0 0 2px rgba(0,0,0,0.5)';

      el.innerHTML = '<div id="bossTimerFill" style="position:absolute;left:0;top:0;width:100%;height:100%;transform-origin:left center;background:linear-gradient(90deg,#22c55e 0%,#fbbf24 50%,#ef4444 100%);box-shadow:0 0 6px rgba(251,191,36,0.5);border-radius:1px"></div>';
      subEl.parentNode.insertBefore(el, subEl.nextSibling);
    }
    el.style.display = 'block';

    var fill = document.getElementById('bossTimerFill');

    fill.style.setProperty('transition', 'none', 'important');
    fill.style.transform = 'scaleX(1)';

    void fill.offsetWidth;
    fill.style.setProperty('transition', 'transform ' + seconds + 's linear', 'important');
    fill.style.transform = 'scaleX(0)';

    timerInterval = setTimeout(function(){
      timerInterval = null;
      if(myToken !== timerToken) return;

      var bo = document.getElementById('bossOpts');
      if(bo && bo.dataset.done) return;
      if(onTimeout) onTimeout();
    }, seconds * 1000);
  }

  function init(){

    if(!document.getElementById('hansenBossCss')){
      var s = document.createElement('style');
      s.id = 'hansenBossCss';
      s.textContent = [

        '#bossScreen #bossMsg{background:linear-gradient(135deg,rgba(251,191,36,.25),rgba(239,68,68,.15)) !important;border:2px solid #fbbf24 !important;padding:5px 14px !important;border-radius:10px !important;width:max-content !important;max-width:calc(100vw - 20px) !important;min-width:48px !important;margin:3px auto !important;min-height:32px !important;box-sizing:border-box !important;display:block !important;color:#fef3c7 !important;font-size:13px !important;font-weight:700 !important;line-height:18px !important;white-space:normal !important;overflow:visible !important;animation:none !important;transform:none !important;transition:color .25s !important;text-align:center !important}',

        '#bossScreen #bossMsg .boss-msg-inner{display:inline-block !important;transform-origin:center center !important;white-space:normal !important;line-height:18px !important;vertical-align:middle !important}',

        '#bossScreen #bossMsg.hit{color:#86efac !important}',
        '#bossScreen #bossMsg.miss{color:#fca5a5 !important}',
        '#bossScreen #bossMsg.crit{color:#fde68a !important}',
        '#bossScreen #bossMsg.rage{color:#fde68a !important}',
        '#bossScreen #bossMsg.phase{color:#fca5a5 !important}',

        '.boss-sprite svg{width:230px;height:230px;display:block;margin:0 auto;transform:scale(.9304);transform-origin:50% 100%;transition:transform .45s ease}',

        '#bossScreen{padding:4px 12px 14px !important}',

        'body.hsn-boss-battle::before{content:"" !important;position:fixed !important;inset:0 !important;z-index:0 !important;background:linear-gradient(180deg,rgba(8,11,22,.50) 0%,rgba(8,11,22,.30) 14%,rgba(8,11,22,.28) 34%,rgba(8,11,22,.48) 45%,rgba(8,11,22,.50) 58%,rgba(8,11,22,.60) 72%,rgba(8,11,22,.66) 100%) !important;pointer-events:none !important}',

        '#bossScreen .boss-name{text-shadow:0 1px 3px rgba(0,0,0,.92),0 0 14px rgba(0,0,0,.7),0 0 20px rgba(239,68,68,.45) !important}',
        '#bossScreen .boss-question{text-shadow:0 1px 3px rgba(0,0,0,.92),0 0 12px rgba(0,0,0,.6),0 0 14px rgba(251,191,36,.35) !important}',
        '#bossScreen .boss-q-sub{color:#eef2f7 !important;font-weight:600 !important;text-shadow:0 1px 3px rgba(0,0,0,.95),0 1px 9px rgba(0,0,0,.7) !important}',

        '#bossScreen .boss-name{display:table !important;margin:2px auto !important;color:#f87171 !important;background:rgba(6,10,20,.93) !important;padding:2px 12px !important;border-radius:9px !important;border:1px solid rgba(248,113,113,.35) !important}',
        '#bossScreen .boss-hp-text{display:table !important;margin:1px auto 0 !important;background:rgba(8,12,26,.82) !important;padding:1px 10px !important;border-radius:8px !important}',
        '#bossScreen .boss-q-sub{display:table !important;margin:0 auto 4px !important;background:rgba(8,12,26,.82) !important;padding:3px 12px !important;border-radius:9px !important}',
        '#bossScreen .boss-question{display:table !important;margin:2px auto 1px !important;background:rgba(8,12,26,.86) !important;padding:4px 16px !important;border-radius:11px !important;border:1px solid rgba(251,191,36,.42) !important}',
        '#bossScreen .hero-hp-text{text-shadow:0 1px 3px rgba(0,0,0,.9) !important}',

        '.boss-victory{text-shadow:0 1px 3px rgba(0,0,0,.92),0 1px 2px rgba(0,0,0,.85),0 0 8px rgba(0,0,0,.55) !important}',
        '.boss-victory h2{text-shadow:none !important;filter:drop-shadow(0 2px 4px rgba(0,0,0,.88)) drop-shadow(0 0 10px rgba(0,0,0,.5)) !important}',

        '#molesContent,#fishContent,#matchContent,#listenContent,#typingContent,#clozeContent,#scrambleContent,#bubbleContent,#eagleContent,#reviewContent,#exploreContent,#speedContent,#petContent,#chestContent{text-shadow:0 1px 3px rgba(0,0,0,.9),0 1px 2px rgba(0,0,0,.8),0 0 8px rgba(0,0,0,.5)}',
        '#speedContent .speed-timer{text-shadow:none !important}',
        '#bossScreen > .back-btn{position:absolute !important;top:8px !important;left:10px !important;width:36px !important;height:36px !important;min-width:0 !important;padding:0 !important;margin:0 !important;border-radius:50% !important;font-size:19px !important;line-height:33px !important;text-align:center !important;background:rgba(15,23,42,.28) !important;border:1.5px solid rgba(255,255,255,.30) !important;color:rgba(255,255,255,.92) !important;box-shadow:0 2px 8px rgba(0,0,0,.22) !important;z-index:9 !important;backdrop-filter:none !important;-webkit-backdrop-filter:none !important}',

        '#bossScreen > .screen-title{display:none !important}',

        '#bossScreen .boss-arena{padding:0 !important;line-height:1.1}',

        '#bossScreen .boss-stats-bar{position:absolute !important;top:8px !important;right:10px !important;display:flex !important;flex-direction:column !important;align-items:flex-end !important;gap:6px !important;margin:0 !important;padding:0 !important;z-index:8 !important;width:auto !important}',
        '#bossScreen .boss-combo{display:none !important}',
        '#bossScreen .boss-arena{position:relative !important}',

        '#bossScreen .boss-sprite-wrap{width:230px;height:230px;margin:34px 0 0 !important;line-height:0 !important;vertical-align:top}',
        '#bossScreen .boss-sprite{width:230px;height:230px;margin:0 !important}',
        '.boss-sprite.boss-rage svg, .boss-arena.bts-typing .boss-sprite.boss-rage svg{transform:scale(1.0) !important}',
        '.boss-sprite.boss-rage.boss-hit-anim{animation:hansenHitFxRage .35s !important}',
        '@keyframes hansenHitFxRage{0%{transform:scale(1);filter:brightness(1)}30%{transform:scale(1.02);filter:brightness(2.2) saturate(1.5)}60%{transform:scale(.99);filter:brightness(1.4)}100%{transform:scale(1);filter:brightness(1)}}',
        'body.hsn-boss-battle .combo-badge{top:6px !important;padding:4px 11px !important;font-size:12px !important}',

        '#bossScreen .boss-name{margin:2px auto !important;font-size:15px !important}'    ,
        '#bossScreen .boss-hp-bar{margin:2px auto !important}',
        '#bossScreen .boss-hp-text{margin:0 auto !important;font-size:11px !important}'    ,
        '#bossScreen .boss-divider{margin:2px 0 !important}',

        '#bossScreen .hero-section{padding:5px 2px !important;margin:3px -11px !important}',

        '#bossScreen .boss-q-type{margin-top:4px !important;font-size:11px !important}',
        '#bossScreen .boss-question{font-size:20px !important;margin:4px auto 2px !important;min-height:26px !important;line-height:1.2 !important}',
        '#bossScreen .boss-q-sub{font-size:12px !important;margin:0 auto 4px !important}'    ,
        '#bossScreen .boss-opts{margin-top:2px !important}',

        '.boss-sprite.boss-hit-anim{animation:hansenHitFx .35s !important}',
        '@keyframes hansenHitFx{0%{transform:scale(1);filter:brightness(1)}30%{transform:scale(1.12);filter:brightness(2.2) saturate(1.5)}60%{transform:scale(.96);filter:brightness(1.4)}100%{transform:scale(1);filter:brightness(1)}}',

        '.hansen-slash{position:absolute;top:50%;left:50%;width:150px;height:2.5px;background:linear-gradient(90deg,transparent 0%,rgba(229,231,235,0.3) 10%,rgba(229,231,235,0.85) 30%,#fff 50%,rgba(229,231,235,0.85) 70%,rgba(229,231,235,0.3) 90%,transparent 100%);box-shadow:0 0 4px rgba(255,255,255,0.9),0 0 9px rgba(203,213,225,0.4);transform:translate(-50%,-50%) rotate(-28deg) scaleX(0);transform-origin:center center;animation:hansenSlashCut 0.7s ease-out forwards;pointer-events:none;z-index:10;border-radius:2px}',

        '.hansen-slash.slash-2{animation:hansenSlashCutR 0.7s ease-out 0.08s forwards}',

        '@keyframes hansenSlashCut{0%{opacity:0;transform:translate(-50%,-50%) rotate(-28deg) scaleX(0)}5%{opacity:1;transform:translate(-50%,-50%) rotate(-28deg) scaleX(1.05)}12%{opacity:1;transform:translate(-50%,-50%) rotate(-28deg) scaleX(1)}55%{opacity:0.9;transform:translate(-50%,-50%) rotate(-28deg) scaleX(1)}100%{opacity:0;transform:translate(-50%,-50%) rotate(-28deg) scaleX(1)}}',
        '@keyframes hansenSlashCutR{0%{opacity:0;transform:translate(-50%,-50%) rotate(28deg) scaleX(0)}5%{opacity:1;transform:translate(-50%,-50%) rotate(28deg) scaleX(1.05)}12%{opacity:1;transform:translate(-50%,-50%) rotate(28deg) scaleX(1)}55%{opacity:0.9;transform:translate(-50%,-50%) rotate(28deg) scaleX(1)}100%{opacity:0;transform:translate(-50%,-50%) rotate(28deg) scaleX(1)}}',

        '.hansen-cannon-flash{position:fixed;inset:0;background:radial-gradient(circle at center,rgba(255,255,255,0.85) 0%,rgba(251,191,36,0.4) 25%,rgba(239,68,68,0.2) 50%,transparent 80%);z-index:99998;pointer-events:none;animation:hansenFlash 0.55s ease-out forwards}',
        '@keyframes hansenFlash{0%{opacity:0}15%{opacity:1}55%{opacity:0.7}100%{opacity:0}}',
        '.hansen-cannon-text{position:fixed;top:35%;left:50%;transform:translate(-50%,-50%) scale(0.5);font-size:60px;font-weight:900;color:#fff;text-shadow:0 0 20px #fbbf24,0 0 40px #ef4444,3px 3px 0 #000;z-index:99999;pointer-events:none;animation:hansenCannonText 0.7s cubic-bezier(0.34,1.56,0.64,1) forwards;white-space:nowrap;font-family:Microsoft YaHei,sans-serif}',
        '@keyframes hansenCannonText{0%{transform:translate(-50%,-50%) scale(0);opacity:0}30%{transform:translate(-50%,-50%) scale(1.2);opacity:1}70%{transform:translate(-50%,-50%) scale(1);opacity:1}100%{transform:translate(-50%,-80%) scale(0.9);opacity:0}}',

        '.boss-sprite.boss-hit-anim{animation:hansenHitNoFlash 0.35s ease-out !important;transform-origin:center bottom !important}',
        '@keyframes hansenHitNoFlash{0%{transform:scale(1) translateY(0)}35%{transform:scale(1.08) translateY(-3px)}65%{transform:scale(0.97) translateY(0)}100%{transform:scale(1) translateY(0)}}',

        '.boss-sprite, .boss-sprite.boss-float{animation:bossFloatSlow 6s ease-in-out infinite !important;transform-origin:center bottom !important}',
        '@keyframes bossFloatSlow{0%,100%{transform:scale(1) translateY(0)}50%{transform:scale(1) translateY(-3px)}}',

        '.boss-sprite.boss-rage{animation:bossRageStatic 6s ease-in-out infinite !important;filter:drop-shadow(0 0 30px #ef4444) drop-shadow(0 0 58px rgba(239,68,68,.5)) hue-rotate(-12deg) !important;transform-origin:center bottom !important}',
        '@keyframes bossRageStatic{0%,100%{transform:scale(1) translateY(0)}50%{transform:scale(1) translateY(-3px)}}',

        '.boss-sprite.boss-rage.boss-rage-final{animation:bossRageFinal 6s ease-in-out infinite !important;filter:drop-shadow(0 0 35px #ef4444) drop-shadow(0 0 18px #fbbf24) hue-rotate(-15deg) saturate(1.15) !important}',
        '@keyframes bossRageFinal{0%,100%{transform:scale(1.30) translateY(0)}50%{transform:scale(1.30) translateY(-4px)}}',

        '.hansen-blood{position:absolute;top:50%;left:50%;width:7px;height:7px;border-radius:50%;background:radial-gradient(circle,#ef4444 30%,#991b1b 75%);box-shadow:0 0 8px rgba(239,68,68,.85);pointer-events:none;z-index:9}',
        '@keyframes hansenBloodSplat{0%{transform:translate(-50%,-50%) scale(0.4);opacity:1}30%{opacity:1}100%{transform:translate(calc(-50% + var(--bx,40px)),calc(-50% + var(--by,-30px))) scale(0.3);opacity:0}}',

        '.hansen-cannon-ring{position:absolute;top:50%;left:50%;width:30px;height:30px;border-radius:50%;border:3px solid #fbbf24;box-shadow:0 0 18px rgba(251,191,36,0.7),inset 0 0 10px rgba(251,191,36,0.4);transform:translate(-50%,-50%) scale(0);animation:hansenCannonRing 0.7s ease-out forwards;pointer-events:none;z-index:9}',
        '@keyframes hansenCannonRing{0%{transform:translate(-50%,-50%) scale(0);opacity:1;border-width:5px}50%{transform:translate(-50%,-50%) scale(4);opacity:0.7;border-width:2px}100%{transform:translate(-50%,-50%) scale(7);opacity:0;border-width:1px}}',

        '@keyframes hansenSuperCoreFlash{0%{transform:scale(0.3);opacity:0}15%{transform:scale(1.2);opacity:1}40%{transform:scale(1.5);opacity:0.85}100%{transform:scale(1.8);opacity:0}}',
        '@keyframes hansenSuperRing{0%{transform:scale(0);opacity:1;border-width:5px}40%{transform:scale(3.5);opacity:0.85;border-width:3px}100%{transform:scale(6);opacity:0;border-width:1px}}',
        '@keyframes hansenSuperRing2{0%{transform:scale(0.4);opacity:0;border-width:4px}30%{transform:scale(2.8);opacity:0.8;border-width:2px}100%{transform:scale(5.5);opacity:0;border-width:1px}}',

        '.levelup{animation:hansenLevelUpFade 2s ease-out forwards !important}',
        '@keyframes hansenLevelUpFade{0%{opacity:0;transform:translate(-50%,-50%) scale(1)}15%{opacity:1;transform:translate(-50%,-50%) scale(1)}80%{opacity:1;transform:translate(-50%,-50%) scale(1)}100%{opacity:0;transform:translate(-50%,-75%) scale(1)}}',

        '.flash-screen{animation:hansenSoftFlash 0.5s ease-out !important}',
        '@keyframes hansenSoftFlash{0%{background:rgba(34,197,94,0.08)}100%{background:transparent}}',

        '.confetti{animation:hansenConfettiFall 1.8s ease-out forwards !important}',
        '@keyframes hansenConfettiFall{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(100vh)}}',

        '@keyframes cFall{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(100vh)}}',
        '@keyframes lvlIn{0%{opacity:0;transform:translate(-50%,-50%) scale(1)}15%{opacity:1;transform:translate(-50%,-50%) scale(1)}85%{opacity:1;transform:translate(-50%,-50%) scale(1)}100%{opacity:0;transform:translate(-50%,-50%) scale(1)}}',

        '@keyframes popIn{from{opacity:0;transform:scale(1)}to{opacity:1;transform:scale(1)}}',
        '@keyframes rewardPop{from{opacity:0;transform:scale(1)}to{opacity:1;transform:scale(1)}}',

        'body.shake-screen, .shake-screen{animation:none !important;transform:none !important}',
        '.boss-opt.wrong, .cloze-opt.wrong, .typing-slot.wrong, .scramble-word.shake-screen{animation:none !important;transform:none !important}',
        '.chest-box.shake{animation:none !important;transform:none !important}',

        '[class*="shake"]{animation:none !important;transform:none !important}',

        '@keyframes shk{0%,100%{transform:none}}',
        '@keyframes shake{0%,100%{transform:none}}',
        '@keyframes chestShake{0%,100%{transform:none}}',

        '.world-map-btn{position:fixed !important;top:calc(env(safe-area-inset-top,0px) + 2px) !important;right:max(6px,env(safe-area-inset-right,0px)) !important;width:58px !important;height:58px !important;border-radius:16px !important;border:none !important;background:transparent !important;padding:0 !important;box-shadow:none !important;animation:worldMapFloat 3.5s ease-in-out infinite !important;z-index:101 !important;filter:none !important}',
        '.world-map-btn:active{transform:translateY(2px) scale(.97) !important;animation:none !important}',

        'body.modal-open .world-map-btn{opacity:0 !important;pointer-events:none !important;transform:none !important;animation:none !important}',

        '.top-bar{padding:calc(10px + env(safe-area-inset-top,0px)) calc(70px + env(safe-area-inset-right,0px)) 10px max(14px,env(safe-area-inset-left,0px)) !important;gap:6px !important}',

        '.avatar{width:42px !important;height:42px !important}',

        '.top-stats{gap:3px !important}',
        '.stat-row{gap:4px !important}',
        '.stat-badge{padding:2px 5px !important;font-size:11px !important}',
        '.xp-bar{height:6px !important;margin-top:3px !important}',
        '.top-name{font-size:12px !important}',
        '.xp-text{font-size:10px !important;margin-top:1px !important}'
      ].join('');
      document.head.appendChild(s);
    }

    if(!window.__hbuShakeBlocked__){
      window.__hbuShakeBlocked__ = true;
      var origAdd = DOMTokenList.prototype.add;
      DOMTokenList.prototype.add = function(){
        var blockedClasses = ['shake-screen', 'shake'];
        var args = [];
        for(var i = 0; i < arguments.length; i++){
          if(blockedClasses.indexOf(arguments[i]) === -1) args.push(arguments[i]);
        }
        return origAdd.apply(this, args);
      };
    }

    if(typeof window.startBoss === 'undefined' || typeof window.bossAnswer === 'undefined'){
      setTimeout(init, 100);
      return;
    }

    var origStartBoss = window.startBoss;
    var origBossAnswer = window.bossAnswer;
    var origStopBoss = window.stopBoss;
    var origNextBossQ = window.nextBossQ;
    var origTriggerBossRage = window.triggerBossRage;

    if(typeof origTriggerBossRage === 'function'){
      window.triggerBossRage = function(){
        var ret = origTriggerBossRage.apply(this, arguments);
        var level = (window.S && window.S.level) || 0;
        if(level >= 20){

          var tries = 0;
          var ensureFinal = function(){
            var sp = document.getElementById('bossSprite');
            if(sp && sp.classList.contains('boss-rage')){
              sp.classList.add('boss-rage-final');
              return;
            }
            tries++;
            if(tries < 20) setTimeout(ensureFinal, 100);
          };
          ensureFinal();
        }
        return ret;
      };
    }

    window.startBoss = function(){
      var cfg = getBossCfg();
      isStartingBoss = true;

      bossSessionToken++;
      try { lastNextBossQAt = 0; } catch(e){}
      window._bossQType = null;

      var _S61 = window.S, _restoreLv61 = null;
      if(_S61 && typeof _S61.level === 'number'){
        var _tgt61 = (window._hansenRebattleLv != null && window._hansenRebattleLv >= 1)
                       ? (window._hansenRebattleLv | 0)
                       : (_S61.level | 0);
        var _cap61 = 20;
        try {
          if(window.HansenBossProgress && typeof window.HansenBossProgress.getUnlockedBossLv === 'function'){
            _cap61 = window.HansenBossProgress.getUnlockedBossLv() | 0;
          } else if(typeof _S61.bossUnlocked === 'number'){
            _cap61 = _S61.bossUnlocked | 0;
          }
        } catch(e){ _cap61 = 20; }
        if(!_cap61 || _cap61 < 1) _cap61 = 1;
        _tgt61 = Math.max(1, Math.min(_tgt61, _cap61, 20));
        if(_S61.level !== _tgt61){ _restoreLv61 = _S61.level; _S61.level = _tgt61; }
      }
      try {
        origStartBoss.apply(this, arguments);
      } finally {
        if(_restoreLv61 != null && _S61){ _S61.level = _restoreLv61; }
      }

      try{ document.body.classList.add('hsn-boss-battle'); }catch(e){}

      var msg = document.getElementById('bossMsg');
      if(msg){
        if(msg.getAttribute('style')) msg.removeAttribute('style');
        if(window.MutationObserver && !msg.__hbu_obs){
          var obs = new MutationObserver(function(){
            if(msg.getAttribute('style')){
              msg.removeAttribute('style');
            }
          });
          obs.observe(msg, {attributes: true, attributeFilter: ['style']});
          msg.__hbu_obs = obs;
        }

        if(window.MutationObserver && !msg.__hbu_cobs){
          var cobs = new MutationObserver(function(){ fitBossMsg(); });
          cobs.observe(msg, {childList: true, subtree: true, characterData: true});
          msg.__hbu_cobs = cobs;
          fitBossMsg();
        }
      }

      var b = _r('bossCurrent');
      if(b){
        var quote = BOSS_QUOTES[b.name] || ('🎯 ' + cfg.intro);
        setBossMsg('💬 ' + quote);
      }

      if(pollInterval) clearInterval(pollInterval);
      pollInterval = setInterval(function(){
        var content = document.getElementById('bossContent');
        if(content && (content.innerHTML.indexOf('boss-victory') >= 0 || content.innerHTML.indexOf('开始挑战') >= 0)){
          clearInterval(pollInterval); pollInterval = null;
          hideTimer();
        }
      }, 200);

      if(_bossQWdInterval){ clearInterval(_bossQWdInterval); _bossQWdInterval = null; }
      _bossQWdInterval = setInterval(ensureBossQuestion, 1200);
      if(!window.__hbuVisWd){
        window.__hbuVisWd = true;
        try {
          document.addEventListener('visibilitychange', function(){

            if(document.visibilityState === 'visible'){
              setTimeout(ensureBossQuestion, 60);
              setTimeout(ensureBossQuestion, 500);
            }
          });
        } catch(e){}
      }
    };

    function _bossQWdHasLiveQ(){
      var bo = document.getElementById('bossOpts');
      if(bo){
        if(bo.querySelector('input, textarea')) return true;

        if(bo.querySelectorAll('.boss-opt').length >= 1 && bo.dataset && !bo.dataset.done) return true;
      }
      return false;
    }

    function _bossQWdAnsweredShowing(){
      var bo = document.getElementById('bossOpts');
      return !!(bo && bo.dataset && bo.dataset.done && bo.querySelectorAll('.boss-opt').length >= 1);
    }
    function _bossQWdOnEndPage(){
      var c = document.getElementById('bossContent');
      if(!c) return false;
      var h = c.innerHTML;
      return h.indexOf('boss-victory') >= 0 || h.indexOf('boss-defeat') >= 0 || h.indexOf('开始挑战') >= 0;
    }
    function _bossQWdStuck(){

      try{ if(window._bossTransUntil && Date.now() < window._bossTransUntil) return false; }catch(e){}
      if(_r('bossActive') !== true) return false;
      var s = document.getElementById('bossScreen');
      if(!(s && s.classList.contains('active'))) return false;
      if(_bossQWdOnEndPage()) return false;
      if(_bossQWdHasLiveQ()) return false;

      if(_bossQWdAnsweredShowing()){
        if(_lastAnswerAt && (Date.now() - _lastAnswerAt) > 3500) return true;
        return false;
      }

      var _boWd = document.getElementById('bossOpts');
      if(_boWd && _boWd.querySelectorAll('.boss-opt').length > 0) return false;
      return true;
    }
    function ensureBossQuestion(){
      if(!_bossQWdStuck()) return;

      setTimeout(function(){
        if(!_bossQWdStuck()) return;
        try { lastNextBossQAt = 0; } catch(e){}
        window._bossQType = null;
        try { console.warn('[HBU] 🔴 BUG#62 看门狗: 检测到 boss 题目区空白卡死, 强制恢复出题'); } catch(e){}
        if(typeof window.nextBossQ === 'function'){
          try { window.nextBossQ(); } catch(e){ try { console.warn('[HBU] BUG#62 看门狗恢复失败:', e); } catch(_e){} }
        }
      }, 250);
    }
    if(typeof origNextBossQ === 'function'){

      window.nextBossQ = function(){

        var bossScr = document.getElementById('bossScreen');
        if(!bossScr || !bossScr.classList.contains('active')){
          return;
        }

        var now = Date.now();
        if(now - lastNextBossQAt < 800){

          var _boLk = document.getElementById('bossOpts');
          if(_boLk && _boLk.querySelectorAll('.boss-opt').length > 0){
            return;
          }

        }

        var boCheck = document.getElementById('bossOpts');
        if(boCheck && boCheck.dataset && boCheck.dataset.done === '' && window._bossQType){

          return;
        }
        lastNextBossQAt = now;

        clearTimer();

        window._bossQType = null;

        var boReset = document.getElementById('bossOpts');
        if(boReset){
          boReset.style.gridTemplateColumns = '';
          boReset.style.gap = '';
          boReset.style.display = '';
        }

        function calcPhase(){
          var p = _r('bossPhase');
          if(typeof p === 'number') return p;

          var bhp = _r('bossHP'), bmax = _r('bossMaxHP');
          if(typeof bhp === 'number' && typeof bmax === 'number' && bmax > 0){
            var pct = bhp / bmax;
            if(pct <= 0.33) return 3;
            if(pct <= 0.66) return 2;
            return 1;
          }
          return 1;
        }
        var phaseBefore = calcPhase();
        var rageBefore = _r('bossRageMode') === true;

        origNextBossQ.apply(this, arguments);

        var phaseAfter = calcPhase();
        var rageAfter = _r('bossRageMode') === true;
        var justSwitchedPhaseOrRage = (phaseAfter !== phaseBefore) || (rageAfter && !rageBefore);

        if(justSwitchedPhaseOrRage){

          return;
        }

        try { applyChapterMode(); } catch(e){ console.warn('[HBU] chapter mode failed:', e); }

        var b = _r('bossCurrent');
        if(!b) return;
        var cfg = getBossCfg();

        if(isStartingBoss){
          var quote = BOSS_QUOTES[b.name] || ('🎯 ' + cfg.intro);
          setBossMsg('💬 ' + quote);

          resetTauntThrottle('💬 ' + quote);
          isStartingBoss = false;
        } else {

          var display = getThrottledTaunt(b);
          if(display) setBossMsg(display);
        }

        if(cfg.timeLimit > 0){

          var actualLimit = cfg.timeLimit;
          var lv = (window.S && window.S.level) || 17;
          if(window._bossQType === 'typing'){

            var typingMap = {17: 18, 18: 16, 19: 14, 20: 12};
            actualLimit = typingMap[lv] || cfg.timeLimit;
          } else if(window._bossQType === 'sentTrans'){

            var sentMap = {13: 22, 14: 20, 15: 18, 16: 17, 17: 16, 18: 15, 19: 14, 20: 13};
            actualLimit = Math.max(cfg.timeLimit, sentMap[lv] || cfg.timeLimit);
          } else if(window._bossQType === 'spellFill' || window._bossQType === 'spellPick'){

            var spellMap = {17: 14, 18: 13, 19: 12, 20: 11};
            actualLimit = Math.max(cfg.timeLimit, spellMap[lv] || cfg.timeLimit);
          }
          startTimer(actualLimit, function(){
            var opts = document.getElementById('bossOpts');
            if(opts && opts.dataset.done) return;

            if(window._bossQType === 'typing'){
              if(typeof window.hansenSubmitTyping === 'function'){
                window.hansenSubmitTyping();
              }
              return;
            }

            var allOpts = document.querySelectorAll('#bossOpts .boss-opt');
            var optCount = allOpts.length || 4;
            var correctIdx = _r('_bossCorrectIdx');
            var wrongIdx = (correctIdx + 1) % optCount;
            if(typeof window.bossAnswer === 'function'){
              window.bossAnswer(wrongIdx);
            }
          });
        }
      };
    }

    window.bossAnswer = function(i){

      var _bo60 = document.getElementById('bossOpts');
      if(_bo60 && _bo60.dataset.done){ return; }
      _lastAnswerAt = Date.now();
      clearTimer();

      var cfg = getBossCfg();
      var correctIdx = _r('_bossCorrectIdx');
      var isCorrect = (i === correctIdx);

      var heroBefore = _r('heroHP');

      origBossAnswer.apply(this, arguments);

      try {
        var resultClass = isCorrect ? 'boss-answer-result-correct' : 'boss-answer-result-wrong';
        var oppositeClass = isCorrect ? 'boss-answer-result-wrong' : 'boss-answer-result-correct';
        var resultNode = null;
        if(window._bossQType === 'spellFill'){
          resultNode = document.getElementById('bsfHole');
        } else if(window._bossQType === 'cloze'){
          var qResultNodes = document.querySelectorAll('#bossQ span[style*="border-bottom"]');
          if(qResultNodes.length) resultNode = qResultNodes[qResultNodes.length - 1];
        }
        if(resultNode && resultNode.classList){
          resultNode.classList.remove(oppositeClass);
          resultNode.classList.add(resultClass);
        }
      } catch(e){}

      if(isCorrect){
        var wrap = document.querySelector('.boss-sprite-wrap');
        var combo = _r('bossCombo') || 0;
        var isSuperCrit = (combo > 0 && combo % 20 === 0);
        var isCannon = (combo > 0 && combo % 10 === 0 && !isSuperCrit);
        var isSlash = (combo > 0 && combo % 5 === 0 && !isSuperCrit && !isCannon);
        window.__hbuLastCombo = combo;
        window.__hbuLastTier = isSuperCrit ? 'SUPER' : (isCannon ? 'CANNON' : (isSlash ? 'SLASH' : 'NORMAL'));

        if(wrap && (isSlash || isCannon)){
          wrap.style.position = 'relative';

          var slashScale = isCannon ? 1.4 : 1;
          var slash = document.createElement('div');
          slash.className = 'hansen-slash';
          if(isCannon){
            slash.style.width = '210px';
            slash.style.height = '3.5px';
          }
          wrap.appendChild(slash);

          var slash2 = document.createElement('div');
          slash2.className = 'hansen-slash slash-2';
          if(isCannon){
            slash2.style.width = '210px';
            slash2.style.height = '3.5px';
          }
          wrap.appendChild(slash2);

          setTimeout(function(){
            if(slash.parentNode) slash.parentNode.removeChild(slash);
            if(slash2.parentNode) slash2.parentNode.removeChild(slash2);
          }, 900);

          if(isCannon){
            var ring = document.createElement('div');
            ring.className = 'hansen-cannon-ring';
            wrap.appendChild(ring);
            setTimeout(function(){ if(ring.parentNode) ring.parentNode.removeChild(ring); }, 800);
          }

          var pCount = isCannon ? 15 : 8;
          for(var bi = 0; bi < pCount; bi++){
            var bd = document.createElement('div');
            bd.className = 'hansen-blood';
            var ang = Math.random() * Math.PI * 2;
            var dist = isCannon ? (38 + Math.random() * 38) : (28 + Math.random() * 32);
            var dx = Math.round(Math.cos(ang) * dist);
            var dy = Math.round(Math.sin(ang) * dist);
            bd.style.setProperty('--bx', dx + 'px');
            bd.style.setProperty('--by', dy + 'px');
            bd.style.animation = 'hansenBloodSplat 0.6s ease-out forwards';

            if(bi < (isCannon ? 3 : 2)){

              var sz = 4 + Math.floor(Math.random() * 3);
              bd.style.width = sz + 'px';
              bd.style.height = sz + 'px';
              bd.style.background = 'radial-gradient(circle,#fff 30%,#e5e7eb 70%)';
              bd.style.boxShadow = '0 0 6px rgba(255,255,255,0.9)';
            } else if(isCannon && bi < 5){

              var sz = 5 + Math.floor(Math.random() * 3);
              bd.style.width = sz + 'px';
              bd.style.height = sz + 'px';
              bd.style.background = 'radial-gradient(circle,#fef3c7 25%,#fbbf24 70%)';
              bd.style.boxShadow = '0 0 8px rgba(251,191,36,0.9)';
            } else {

              var sz = 5 + Math.floor(Math.random() * 4);
              bd.style.width = sz + 'px';
              bd.style.height = sz + 'px';
            }
            wrap.appendChild(bd);
            (function(el){ setTimeout(function(){ if(el.parentNode) el.parentNode.removeChild(el); }, 700); })(bd);
          }
        }

        if(isSuperCrit){
          var maxBHp = _r('bossMaxHP') || 100;
          var curBHp = _r('bossHP') || 0;
          var baseExtra = Math.floor(maxBHp * 0.05);
          var extraDmg = baseExtra * 3;
          if(extraDmg < 1) extraDmg = 1;

          var newBHp = Math.max(0, curBHp - extraDmg);
          _w('bossHP', newBHp);

          var heal = Math.floor(extraDmg / 2);
          var maxHHp = _r('heroMaxHP') || 100;
          var curHHp = _r('heroHP') || 0;
          var newHHp = Math.min(maxHHp, curHHp + heal);
          _w('heroHP', newHHp);

          var bFill = document.getElementById('bossHPFill');
          var bText = document.getElementById('bossHPText');
          if(bFill) bFill.style.width = (newBHp / maxBHp * 100) + '%';
          if(bText) bText.textContent = 'HP: ' + newBHp + ' / ' + maxBHp;

          var heroFill2 = document.getElementById('heroHPFill');
          if(heroFill2) heroFill2.style.width = (newHHp / maxHHp * 100) + '%';
          var heroText2 = document.getElementById('heroHPText');
          if(heroText2) heroText2.textContent = newHHp + ' / ' + maxHHp;

          if(wrap){
            wrap.style.position = 'relative';

            var coreFlash = document.createElement('div');
            coreFlash.style.cssText = 'position:absolute;left:50%;top:50%;width:90px;height:90px;margin:-45px 0 0 -45px;background:radial-gradient(circle,#fff 0%,#fbbf24 35%,rgba(239,68,68,0.6) 65%,transparent 90%);border-radius:50%;z-index:5;pointer-events:none;animation:hansenSuperCoreFlash .55s ease-out forwards';
            wrap.appendChild(coreFlash);

            var ring1 = document.createElement('div');
            ring1.style.cssText = 'position:absolute;left:50%;top:50%;width:60px;height:60px;margin:-30px 0 0 -30px;border:4px solid #fbbf24;border-radius:50%;z-index:4;pointer-events:none;box-shadow:0 0 20px #fbbf24;animation:hansenSuperRing .7s ease-out forwards';
            wrap.appendChild(ring1);

            var ring2 = document.createElement('div');
            ring2.style.cssText = 'position:absolute;left:50%;top:50%;width:60px;height:60px;margin:-30px 0 0 -30px;border:3px solid #ef4444;border-radius:50%;z-index:4;pointer-events:none;box-shadow:0 0 16px #ef4444;animation:hansenSuperRing2 .9s ease-out forwards';
            wrap.appendChild(ring2);

            for(var sci = 0; sci < 25; sci++){
              var sp = document.createElement('div');
              sp.className = 'hansen-blood';
              var ang2 = (sci / 25) * Math.PI * 2 + Math.random() * 0.3;
              var dist2 = 50 + Math.random() * 50;
              var dx2 = Math.round(Math.cos(ang2) * dist2);
              var dy2 = Math.round(Math.sin(ang2) * dist2);
              sp.style.setProperty('--bx', dx2 + 'px');
              sp.style.setProperty('--by', dy2 + 'px');
              sp.style.animation = 'hansenBloodSplat 0.8s ease-out forwards';
              if(sci < 8){ sp.style.background = '#fbbf24'; sp.style.boxShadow = '0 0 8px #fbbf24'; }
              else if(sci < 16){ sp.style.background = '#ef4444'; }
              else { sp.style.background = '#fff'; sp.style.boxShadow = '0 0 6px #fbbf24'; }
              wrap.appendChild(sp);
            }

            setTimeout(function(){
              if(coreFlash.parentNode) coreFlash.remove();
              if(ring1.parentNode) ring1.remove();
              if(ring2.parentNode) ring2.remove();

              var blobs = wrap.querySelectorAll('.hansen-blood');
              blobs.forEach(function(b){ if(b.parentNode) b.remove(); });
            }, 950);
          }

          setBossMsg('⚡ <b>' + combo + ' 超级暴击!</b> -' + extraDmg + ' · 吸血 +' + heal);

          if(newBHp <= 0 && typeof window.bossVictory === 'function'){

            var sessTok = bossSessionToken;
            setTimeout(function(){
              if(sessTok !== bossSessionToken) return;
              window.bossVictory();
            }, 1000);
          }
        }
      }

      if(!isCorrect){
        var maxHp = _r('heroMaxHP') || 100;
        if(_r('heroHP') <= 0 && typeof window.bossDefeat === 'function'){
          var sessTok2 = bossSessionToken;
          setTimeout(function(){
            if(sessTok2 !== bossSessionToken) return;
            window.bossDefeat();
          }, 1200);
        }
      }
    };

    window.stopBoss = function(){
      hideTimer();

      bossSessionToken++;

      try { lastNextBossQAt = 0; } catch(e){}

      window._bossQType = null;
      window._bossWord = null;
      window._bossCorrectIdx = null;

      if(pollInterval){ clearInterval(pollInterval); pollInterval = null; }
      if(pollInterval){ clearInterval(pollInterval); pollInterval = null; }

      if(_bossQWdInterval){ clearInterval(_bossQWdInterval); _bossQWdInterval = null; }
      if(origStopBoss) origStopBoss.apply(this, arguments);
    };

    if(getBossCfg().askAll){

    }

    if(typeof window.showComboToast === 'function'){
      var origShowComboToast = window.showComboToast;
      window.showComboToast = function(html, type, duration){
        if(typeof type === 'string' && type.indexOf('milestone-') === 0){
          return;
        }
        return origShowComboToast.call(this, html, type, duration);
      };
    }

    if(window.HansenUpgrade){
      window.HansenUpgrade.showCombo = function(){};
      window.HansenUpgrade.showXpGain = function(){};
    }

    if(typeof window.floatText === 'function' && !window.__hbu_floatText_patched){
      var origFloatText = window.floatText;
      window.floatText = function(x, y, text, color){
        if(typeof text === 'string' && text.indexOf('COMBO XP') !== -1) return;
        return origFloatText.apply(this, arguments);
      };
      window.__hbu_floatText_patched = true;
    }

    if(!document.getElementById('hansen-hero-hit-css')){
      var _hhc = document.createElement('style');
      _hhc.id = 'hansen-hero-hit-css';
      _hhc.textContent =

        '#bossScreen .hero-hp-bar{position:relative}' +
        '#bossScreen .hero-hp-fill{position:relative;z-index:2}' +
        '#bossScreen .hero-hp-trail{position:absolute;left:0;top:0;height:100%;z-index:1;border-radius:5px;background:linear-gradient(90deg,#fb7185,#fecaca);box-shadow:0 0 6px rgba(251,113,133,.45);transition:width .55s cubic-bezier(.4,0,.2,1) .12s}' +

        '.hero-dmg-float{position:fixed;pointer-events:none;z-index:10000;font-weight:900;color:#f87171;font-family:Microsoft YaHei,sans-serif;text-shadow:0 2px 8px rgba(0,0,0,.6),0 0 14px rgba(248,113,113,.55);white-space:nowrap;will-change:transform,opacity;animation:hansenHeroDmg 1s cubic-bezier(.2,.7,.3,1) forwards}' +
        '@keyframes hansenHeroDmg{0%{transform:translate(-50%,0) scale(.5);opacity:0}18%{transform:translate(-50%,-9px) scale(1.18);opacity:1}46%{transform:translate(-50%,-20px) scale(1);opacity:1}100%{transform:translate(-50%,-46px) scale(.92);opacity:0}}';
      (document.head || document.documentElement).appendChild(_hhc);
    }

    window.HansenHeroHit = function(dmg, newHP, maxHP){
      try {
        dmg = Math.round(dmg || 0); if(dmg <= 0) return;
        maxHP = maxHP || 100;
        if(typeof newHP !== 'number') newHP = maxHP;
        var newPct = Math.max(0, Math.min(100, (newHP / maxHP) * 100));
        var oldPct = Math.max(0, Math.min(100, ((newHP + dmg) / maxHP) * 100));

        var bar = document.querySelector('#bossScreen .hero-hp-bar');
        if(bar){
          var trail = bar.querySelector('.hero-hp-trail');
          if(!trail){
            trail = document.createElement('div');
            trail.className = 'hero-hp-trail';
            bar.insertBefore(trail, bar.firstChild);
          }
          trail.style.transition = 'none';
          trail.style.width = oldPct + '%';
          void trail.offsetWidth;
          trail.style.transition = '';
          requestAnimationFrame(function(){ trail.style.width = newPct + '%'; });
        }

        var anchor = document.querySelector('#bossScreen .hero-section') || document.getElementById('heroHPText') || bar;
        var x = window.innerWidth / 2, y = window.innerHeight / 2;
        if(anchor){ var r = anchor.getBoundingClientRect(); y = r.top + r.height / 2; }
        var _bspr614 = document.getElementById('bossSprite') || document.querySelector('.boss-sprite');
        if(_bspr614){ var _br614 = _bspr614.getBoundingClientRect(); if(_br614.width>0) x = _br614.left + _br614.width/2; }

        try{ if(typeof window.__hsnDmgX==='number'){ x=window.__hsnDmgX; window.__hsnDmgX=null; } }catch(_e){}
        var f = document.createElement('div');
        f.className = 'hero-dmg-float';
        f.textContent = '-' + dmg;
        f.style.left = x + 'px';
        f.style.top = y + 'px';
        f.style.fontSize = (dmg >= 18 ? 30 : 25) + 'px';
        document.body.appendChild(f);
        setTimeout(function(){ if(f.parentNode) f.parentNode.removeChild(f); }, 1050);
      } catch(e){}
    };

    console.log('%c[HansenBossUpgrade]%c v391 加载: boss战返回键智能跳转 (战斗中→boss选择, picker→主菜单)',
                'color:#dc2626;font-weight:bold', 'color:#94a3b8');

    window.HBU_RUNTIME_VERSION = 'v996';
    setTimeout(function(){
      try {
        var versions = new Set();
        document.querySelectorAll('script[src*="?v="], img[src*="?v="]').forEach(function(el){
          var src = el.getAttribute('src') || '';
          var m = src.match(/\?v=([a-zA-Z0-9_]+)/);
          if(m) versions.add(m[1]);
        });

        document.querySelectorAll('image').forEach(function(el){
          var href = el.getAttribute('href') || el.getAttribute('xlink:href') || '';
          var m = href.match(/\?v=([a-zA-Z0-9_]+)/);
          if(m) versions.add(m[1]);
        });

        if(versions.size > 1){
          var vs = Array.from(versions).join(', ');
          console.error('%c⚠️ 版本不一致! 发现多个 ?v= 版本:', 'color:#dc2626;font-weight:bold;font-size:14px', vs);

          var w = document.createElement('div');
          w.id = '__hansen_version_mismatch_warning';
          w.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#dc2626;color:#fff;padding:10px;font-weight:900;z-index:100000;text-align:center;font-size:13px;box-shadow:0 2px 12px rgba(0,0,0,.5);border-bottom:2px solid #fbbf24;cursor:pointer';
          w.innerHTML = '⚠️ 版本不一致! 发现 ?v=' + vs + ' &nbsp; (点击关闭) &nbsp; 请重新部署最新 zip';
          w.onclick = function(){ w.remove(); };
          document.body.appendChild(w);
          setTimeout(function(){ if(w.parentNode) w.remove(); }, 15000);
        } else if(versions.size === 1) {
          var v = Array.from(versions)[0];
          console.log('%c✅ 版本一致性自检通过: ?v=' + v, 'color:#22c55e;font-weight:bold');
        }
      } catch(e){ console.warn('版本自检失败:', e); }
    }, 500);

  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

(function(){
  'use strict';
  if(window.__hansenBossAdminBridgeV953) return;
  window.__hansenBossAdminBridgeV953=true;

  var pending=null;
  var openPending=null;
  var watcher=null;

  function exportedGate(){
    return typeof window.__hsnOpenBossAdminGate==='function'
      ? window.__hsnOpenBossAdminGate : null;
  }

  function exportedRefresh(){
    return typeof window.__hsnEnsureBossFxSettingsEntry==='function'
      ? window.__hsnEnsureBossFxSettingsEntry : null;
  }

  function waitForLoader(){
    return new Promise(function(resolve){
      var tries=0;
      (function poll(){
        if(typeof window.__hansenBossFXReady==='function'){
          resolve(window.__hansenBossFXReady);
          return;
        }
        tries++;
        if(tries>=120){ resolve(null); return; }
        setTimeout(poll,25);
      })();
    });
  }

  function waitForExportedGate(){
    return new Promise(function(resolve){
      var tries=0;
      (function poll(){
        if(exportedGate()){ resolve(true); return; }
        tries++;
        if(tries>=240){ resolve(false); return; }
        setTimeout(poll,25);
      })();
    });
  }

  function ensureLoaded(){
    if(exportedGate()) return Promise.resolve(true);
    if(pending) return pending;
    pending=waitForLoader().then(function(ready){
      if(!ready) return false;
      var started;
      try{ started=ready(); }catch(e){ return false; }
      var gateReady=waitForExportedGate();
      if(started&&typeof started.then==='function'){
        return Promise.race([
          gateReady,
          Promise.resolve(started).then(function(){
            return !!exportedGate();
          },function(){ return false; })
        ]);
      }
      return gateReady;
    }).then(function(ok){
      if(!ok) pending=null;
      return ok;
    },function(){
      pending=null;
      return false;
    });
    return pending;
  }

  function refresh(){
    return ensureLoaded().then(function(ok){
      var fn=exportedRefresh();
      if(ok&&fn){ try{fn();}catch(e){} }
      return ok;
    });
  }

  function open(){
    if(openPending) return openPending;
    openPending=ensureLoaded().then(function(ok){
      var fn=exportedGate();
      if(ok&&fn){ fn(); return true; }
      return false;
    }).then(function(ok){
      openPending=null;
      return ok;
    },function(){
      openPending=null;
      return false;
    });
    return openPending;
  }

  function isSecretFooter(target){
    if(!target||target.nodeType!==1) return false;
    if(target.children&&target.children.length>0) return false;
    var text=target.textContent||'';
    return text.length<40&&text.indexOf('进度自动保存到本设备')>=0;
  }

  try{
    document.addEventListener('click',function(event){
      var target=event&&event.target;
      if(!isSecretFooter(target)) return;
      try{ if(event.preventDefault)event.preventDefault(); }catch(e){}
      try{ if(event.stopImmediatePropagation)event.stopImmediatePropagation(); }catch(e){}
      open();
    },true);
  }catch(e){}

  function armSettings(){
    var settings=document.getElementById('settingsContent');

    if(!settings) return;
    function onSettingsContent(){
      if(settings.firstChild) refresh();
    }
    onSettingsContent();
    try{
      watcher=new MutationObserver(onSettingsContent);
      watcher.observe(settings,{childList:true});
    }catch(e){
      setInterval(onSettingsContent,1200);
    }
  }

  window.HansenBossAdminBridge={
    ensureLoaded:ensureLoaded,
    open:open,
    refresh:refresh
  };

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',armSettings,{once:true});
  }else{
    armSettings();
  }
})();
