
(function(){
  'use strict';
  if(window.__hansenPaletteLoaded) return; window.__hansenPaletteLoaded=true;

  var KEY='hansen_palette_global';

  var PALETTES=[
    {id:'cosmos', name:'深空蓝', emoji:'🌌', light:false, isDefault:true},
    {id:'violet', name:'暗夜紫', emoji:'🔮', light:false, vars:{
      c1:'#2e1065',c2:'#4c1d95',c1rgb:'46,16,101',navA:'rgba(46,16,101,.92)',navB:'rgba(23,10,50,.95)',
      s1:'#191033',s2:'#251a44',s3:'#37295e',s4:'#4a3a78',
      ink:'#fff',inkHi:'#ede9fe',ink2:'#d6ccf5',ink3:'#a695d6',line:'167,139,250',
      glassA:'rgba(37,26,68,.60)',glassB:'rgba(25,16,51,.60)',
      deep:'#170b30',mid:'#2b1657',glow:'#4c1d95',
      n1:'rgba(192,132,252,.35)',n2:'rgba(129,140,248,.35)',n3:'rgba(236,72,153,.22)',n4:'rgba(56,189,248,.18)'}},
    {id:'aurora', name:'极光青', emoji:'🌊', light:false, vars:{
      c1:'#083344',c2:'#155e75',c1rgb:'8,51,68',navA:'rgba(8,51,68,.92)',navB:'rgba(4,25,31,.95)',
      s1:'#0a222b',s2:'#123441',s3:'#1c4a59',s4:'#2a6173',
      ink:'#fff',inkHi:'#e0fbf6',ink2:'#c4ece4',ink3:'#85bdb2',line:'45,212,191',
      glassA:'rgba(18,52,65,.60)',glassB:'rgba(10,34,43,.60)',
      deep:'#04191f',mid:'#0b3a45',glow:'#0e7490',
      n1:'rgba(45,212,191,.30)',n2:'rgba(34,211,238,.32)',n3:'rgba(59,130,246,.22)',n4:'rgba(163,230,53,.14)'}},
    {id:'woods', name:'森野绿', emoji:'🌲', light:false, vars:{
      c1:'#14532d',c2:'#166534',c1rgb:'20,83,45',navA:'rgba(20,83,45,.92)',navB:'rgba(9,30,17,.95)',
      s1:'#0f2417',s2:'#1a3524',s3:'#274a33',s4:'#366146',
      ink:'#fff',inkHi:'#e7fbe9',ink2:'#cfeed4',ink3:'#93bf9d',line:'74,222,128',
      glassA:'rgba(26,53,36,.60)',glassB:'rgba(15,36,23,.60)',
      deep:'#0b1f11',mid:'#1c4426',glow:'#3f6212',
      n1:'rgba(74,222,128,.28)',n2:'rgba(163,230,53,.26)',n3:'rgba(253,224,71,.16)',n4:'rgba(45,212,191,.16)'}},
    {id:'cloud', name:'云端白', emoji:'☁️', light:true, vars:{
      c1:'#ffffff',c2:'#eef2ff',c1rgb:'255,255,255',navA:'rgba(255,255,255,.94)',navB:'rgba(238,242,255,.96)',
      s1:'#e3eaf6',s2:'#f4f7fd',s3:'#ffffff',s4:'#d3ddee',
      ink:'#1c2942',inkHi:'#24324d',ink2:'#46587a',ink3:'#7387a8',accentText:'#3730a3',line:'99,102,241',
      glassA:'rgba(255,255,255,.80)',glassB:'rgba(238,243,252,.72)',
      deep:'#e8effc',mid:'#f6f9ff',glow:'#dbe7fb',
      n1:'rgba(129,140,248,.20)',n2:'rgba(56,189,248,.18)',n3:'rgba(244,114,182,.12)',n4:'rgba(52,211,153,.12)'}},
    {id:'sakura', name:'樱花粉', emoji:'🌸', light:true, vars:{
      c1:'#fff1f7',c2:'#fce7f1',c1rgb:'255,241,247',navA:'rgba(255,244,249,.94)',navB:'rgba(252,231,241,.96)',
      s1:'#f6e3ec',s2:'#fdf4f8',s3:'#ffffff',s4:'#ecd2de',
      ink:'#431c31',inkHi:'#4f2440',ink2:'#7c4a63',ink3:'#a97e92',accentText:'#9f1239',line:'236,72,153',
      glassA:'rgba(255,246,250,.82)',glassB:'rgba(251,233,241,.74)',
      deep:'#fbe7f0',mid:'#fdf3f8',glow:'#f9d8e8',
      n1:'rgba(244,114,182,.20)',n2:'rgba(192,132,252,.14)',n3:'rgba(251,191,36,.10)',n4:'rgba(56,189,248,.10)'}},
    {id:'cream', name:'奶油杏', emoji:'🍦', light:true, vars:{
      c1:'#fff8ed',c2:'#faedd6',c1rgb:'255,248,237',navA:'rgba(255,250,240,.94)',navB:'rgba(250,237,214,.96)',
      s1:'#f2e4cd',s2:'#fbf3e4',s3:'#fffdf7',s4:'#e8d3b2',
      ink:'#43301a',inkHi:'#4d3a22',ink2:'#79603f',ink3:'#a68a63',accentText:'#1e40af',line:'217,119,6',
      glassA:'rgba(255,250,241,.82)',glassB:'rgba(250,240,220,.74)',
      deep:'#f7ecd9',mid:'#fcf6ea',glow:'#f3e0c2',
      n1:'rgba(251,146,60,.16)',n2:'rgba(251,191,36,.16)',n3:'rgba(244,114,182,.10)',n4:'rgba(163,230,53,.08)'}},
    {id:'mint', name:'薄荷绿', emoji:'🌿', light:true, vars:{
      c1:'#f4fdf8',c2:'#e2f6ec',c1rgb:'244,253,248',navA:'rgba(246,253,249,.94)',navB:'rgba(226,246,236,.96)',
      s1:'#ddefe5',s2:'#f1faf5',s3:'#ffffff',s4:'#cbe5d6',
      ink:'#15342a',inkHi:'#1d4033',ink2:'#46705f',ink3:'#729a89',accentText:'#065f46',line:'16,185,129',
      glassA:'rgba(246,253,249,.82)',glassB:'rgba(228,246,237,.74)',
      deep:'#e2f5ea',mid:'#f2fbf6',glow:'#d2eede',
      n1:'rgba(52,211,153,.18)',n2:'rgba(45,212,191,.16)',n3:'rgba(56,189,248,.12)',n4:'rgba(163,230,53,.10)'}}
  ];

  function byId(id){ for(var i=0;i<PALETTES.length;i++) if(PALETTES[i].id===id) return PALETTES[i]; return PALETTES[0]; }

  function buildCSS(){
    var css='';
    for(var i=0;i<PALETTES.length;i++){
      var p=PALETTES[i]; if(p.isDefault) continue; var v=p.vars;
      css+='html.hsn-pal-'+p.id+'{'
        +'--pal-chrome-1:'+v.c1+';--pal-chrome-2:'+v.c2+';--pal-c1rgb:'+v.c1rgb+';'
        +'--pal-nav-a:'+v.navA+';--pal-nav-b:'+v.navB+';'
        +'--pal-surf-1:'+v.s1+';--pal-surf-2:'+v.s2+';--pal-surf-3:'+v.s3+';--pal-surf-4:'+v.s4+';'
        +'--pal-ink:'+v.ink+';--pal-ink-hi:'+v.inkHi+';--pal-ink-2:'+v.ink2+';--pal-ink-3:'+v.ink3+';--pal-accent-text:'+(v.accentText||v.inkHi)+';'
        +'--pal-line-rgb:'+v.line+';--pal-glass-a:'+v.glassA+';--pal-glass-b:'+v.glassB+'}\n';

      css+='html.hsn-pal-'+p.id+' body{'
        +'--th-bg-deep:'+v.deep+';--th-bg-mid:'+v.mid+';--th-bg-glow:'+v.glow+';'
        +'--th-cosmos-1:'+v.n1+';--th-cosmos-2:'+v.n2+';--th-cosmos-3:'+v.n3+';--th-cosmos-4:'+v.n4+'}\n';
    }

    var S='html[class*="hsn-pal-"] ';
    css+=S+'.top-bar{background:linear-gradient(135deg,var(--pal-chrome-1),var(--pal-chrome-2))!important;box-shadow:0 4px 18px rgba(0,0,0,.16)!important}\n';
    css+=S+'.bottom-nav{background:linear-gradient(180deg,var(--pal-nav-a),var(--pal-nav-b))!important;border-top:1px solid rgba(var(--pal-line-rgb),.32)!important}\n';
    css+=S+'.settings-section{background:linear-gradient(135deg,var(--pal-glass-a),var(--pal-glass-b))!important;border-color:rgba(var(--pal-line-rgb),.30)!important}\n';

    css+=S+'[style*="color:#fff"]{color:var(--pal-ink)!important}\n';
    css+=S+'[style*="color:#e2e8f0"]{color:var(--pal-ink-hi)!important}\n';
    css+=S+'[style*="color:#cbd5e1"]{color:var(--pal-ink-2)!important}\n';
    css+=S+'[style*="color:#94a3b8"]{color:var(--pal-ink-3)!important}\n';
    css+=S+'[style*="background:linear-gradient(135deg,#1e293b"]{background:linear-gradient(135deg,var(--pal-surf-2),var(--pal-surf-1))!important}\n';
    css+=S+'[style*="background:#0f172a"]{background:var(--pal-surf-1)!important}\n';
    css+=S+'[style*="background:#1e293b"]{background:var(--pal-surf-2)!important}\n';
    css+=S+'[style*="background:#334155"]{background:var(--pal-surf-3)!important}\n';
    css+=S+'[style*="background:#475569"]{background:var(--pal-surf-4)!important}\n';

    css+=S+'#bossScreen [style*="color:#fff"]{color:#fff!important}\n';
    css+=S+'#bossScreen [style*="color:#e2e8f0"]{color:#e2e8f0!important}\n';
    css+=S+'#bossScreen [style*="color:#cbd5e1"]{color:#cbd5e1!important}\n';
    css+=S+'#bossScreen [style*="color:#94a3b8"]{color:#94a3b8!important}\n';
    css+=S+'#bossScreen [style*="background:linear-gradient(135deg,#1e293b"]{background:linear-gradient(135deg,#1e293b,#0f172a)!important}\n';
    css+=S+'#bossScreen [style*="background:#0f172a"]{background:#0f172a!important}\n';
    css+=S+'#bossScreen [style*="background:#1e293b"]{background:#1e293b!important}\n';
    css+=S+'#bossScreen [style*="background:#334155"]{background:#334155!important}\n';
    css+=S+'#bossScreen [style*="background:#475569"]{background:#475569!important}\n';

    css+='#hsnSeasonBar .hsn-ex-tag, #hsnSeasonBar .hsn-ex-enter{color:#3b0764!important;text-shadow:none!important}\n';
    css+='#hsnSeasonBar [style*="color:#fff"]{color:#fff!important}\n';
    css+='#hsnSeasonBar [style*="color:#c4b5fd"]{color:#c4b5fd!important}\n';
    css+='#hsnSeasonBar [style*="color:#94a3b8"]{color:#94a3b8!important}\n';
    css+='#hsnSeasonBar [style*="color:#fcd34d"]{color:#fcd34d!important}\n';

    css+='#hsnSeasonEntry [style*="color:#fff"]{color:#fff!important}\n';
    css+='#hsnSeasonEntry [style*="color:#e2e8f0"]{color:#e2e8f0!important}\n';
    css+='#hsnSeasonEntry [style*="color:#cbd5e1"]{color:#cbd5e1!important}\n';
    css+='#hsnSeasonEntry [style*="color:#94a3b8"]{color:#94a3b8!important}\n';
    css+='#hsnSeasonEntry, #hsnSeasonEntry *{--pal-ink:#f1f5f9;--pal-ink-2:#cbd5e1;--pal-ink-3:#94a3b8}\n';

    var L='html.hsn-pal-light ';

    css+=L+'#bossScreen{background:transparent!important}\n';
    css+=L+'#bossScreen::before{background:linear-gradient(180deg,#131c3a,#0c1538)!important}\n';
    css+=L+'#bossScreen, '+L+'#bossScreen *{--pal-ink:#f1f5f9;--pal-ink-2:#cbd5e1;--pal-ink-3:#94a3b8}\n';
    css+=L+'#bossScreen{color:#e2e8f0}\n';

    var DK=['.util-card','.psw-nmrow','.psw-cap','.lkk','.ach-total'];
    css+=DK.map(function(d){return L+d+','+L+d+' *';}).join(',')+'{color:#e2e8f0}\n';
    ['#fbbf24','#fde047','#fde68a','#facc15','#fef3c7','#fcd34d'].forEach(function(gold){
      css+=DK.map(function(d){return L+d+' [style*="color:'+gold+'"]';}).join(',')+'{color:'+gold+'!important}\n';
    });

    ['#fbbf24','#fde047','#fde68a','#facc15','#fcd34d'].forEach(function(gold){
      css+=L+'[style*="color:'+gold+'"]{color:var(--pal-accent-text,#1e40af)!important}\n';
    });
    css+=L+'.quest-reward,'+L+'.ach-reward,'+L+'.ach-bar-count{color:var(--pal-accent-text,#1e40af)!important}\n';
    css+=L+'.pet-name{color:var(--pal-accent-text,#1e40af)!important;text-shadow:none!important}\n';
    css+=L+'.psw-sub,'+L+'.rsb{color:#475569!important}\n';

    css+=L+'.mode-card,'+L+'.mode-card *{color:#fff!important;text-shadow:0 1px 3px rgba(0,0,0,.55)!important}\n';

    css+=L+'[style*="linear-gradient(135deg,#fbbf24"] *, '+L+'[style*="linear-gradient(135deg, #fbbf24"] *{color:#1a1200!important;text-shadow:none!important}\n';

    css+=L+'.screen-title,'+L+'.screen-title *{text-shadow:none!important}\n';

    ['#fbbf24','#fde68a','#fde047','#facc15'].forEach(function(gold){
      css+='#hsnSeasonEntry [style*="color:'+gold+'"]{color:'+gold+'!important}\n';
    });

    css+=L+'body{--pal-ink-2:#475569;--pal-ink-3:#64748b}\n';

    css+=L+'.back-btn{color:#e2e8f0!important}\n';

    css+=L+'.ach-foot2,'+L+'.ach-prog{color:var(--pal-accent-text,#1e40af)!important}\n';

    css+=L+'#petScreen .st{color:#475569!important}\n';
    css+=L+'.psw-sub b,'+L+'.psw-sub span{color:var(--pal-accent-text,#1e40af)!important}\n';

    css+=L+'.settings-section{background:rgba(255,255,255,.66)!important;border-color:rgba(0,0,0,.08)!important}\n';
    css+=L+'.settings-stat{background:rgba(255,255,255,.55)!important;border-color:rgba(0,0,0,.06)!important}\n';
    css+=L+'[style*="color:#22c55e"]{color:#15803d!important}\n';

    css+=L+'.screen *{text-shadow:none}\n';
    css+=L+'.island-hero *, '+L+'.section-label{text-shadow:none!important}\n';

    css+=L+'[style*="background:#1e1b4b"], '+L+'[style*="background:#1e1b4b"] *, '+L+'[style*="background: #1e1b4b"] *, '+L+'[style*="background:rgb(30, 27, 75"] *{color:#e2e8f0}\n';

    css+=L+'#petScreen{color:#334155}\n';
    css+=L+'#petScreen .nm,'+L+'#petScreen .rnm{color:#334155!important}\n';
    css+=L+'#petScreen .now{color:var(--pal-accent-text,#1e40af)!important}\n';
    css+=L+'.pet-text{color:#334155!important;text-shadow:none!important}\n';

    css+=L+'#settingsContent > div{background:rgba(255,255,255,.66)!important;border-color:rgba(0,0,0,.08)!important;color:#334155}\n';
    css+=L+'#settingsContent h3{color:var(--pal-accent-text,#1e40af)!important;text-shadow:none!important}\n';
    css+=L+'.settings-stat span{color:var(--pal-accent-text,#1e40af)!important}\n';

    css+=L+'#petScreen .psw-nmrow, '+L+'#petScreen .psw-nmrow *{color:#e2e8f0!important}\n';

    css+=L+'.settings-stat b{color:#1e3a8a!important}\n';

    css+=L+'[style*="color:#cbd5e1"]{color:#475569!important}\n';

    css+=L+'[style*="background:rgba(30,41,59,.55)"]{background:rgba(255,255,255,.72)!important;border:1px solid rgba(0,0,0,.06)!important}\n';

    css+=L+'.chest-badge{color:#fff!important;text-shadow:none!important}\n';

    css+=L+'#landGachaBody, '+L+'#landGachaBody *{--pal-ink:#f1f5f9;--pal-ink-hi:#e2e8f0;--pal-ink-2:#cbd5e1;--pal-ink-3:#94a3b8}\n';
    css+=L+'#landGachaBody [style*="color:#cbd5e1"]{color:#cbd5e1!important}\n';
    ['#fbbf24','#fde047','#fde68a','#facc15','#fcd34d'].forEach(function(gold){
      css+=L+'#landGachaBody [style*="color:'+gold+'"]{color:'+gold+'!important}\n';
    });
    css+=L+'#landGachaBody [style*="color:#22c55e"]{color:#22c55e!important}\n';

    css+=L+'.lg-banner, '+L+'.lg-banner *{--pal-ink:#fff;--pal-ink-hi:#f5f3ff;--pal-ink-2:#ddd6fe;--pal-ink-3:#c4b5fd}\n';
    ['.util-card','.psw-nmrow','.psw-cap','.lkk','.ach-total'].forEach(function(d){
      css+=L+d+' [style*="color:#cbd5e1"]{color:#cbd5e1!important}\n';
    });
    css+=L+'[style*="background:#1e1b4b"] [style*="color:#cbd5e1"]{color:#cbd5e1!important}\n';

    css+=L+'.psw-th, '+L+'.psw-th span, '+L+'.psw-th b{color:var(--pal-accent-text,#1e40af)!important;text-shadow:none!important}\n';

    css+=L+'[style*="linear-gradient(135deg,#1e1b4b"] *{color:#e2e8f0!important}\n';

    css+=L+'[style*="background:rgba(0,0,0,.5)"][style*="color:#fff"]{color:#fff!important;text-shadow:0 1px 2px rgba(0,0,0,.55)!important}\n';

    css+='html.hsn-pal-light body{color:var(--pal-ink)}\n';

    var _L='html.hsn-pal-light ';
    var _LS='html[class*="hsn-pal-"].hsn-pal-light ';
    var _SF='linear-gradient(135deg,#ffffff,var(--pal-surf-2,#eef2f8))';
    var _BD='1px solid rgba(var(--pal-line-rgb,99,102,241),.28)';
    var _SH='0 2px 10px rgba(30,41,59,.07)';
    var _AM='var(--pal-accent-text,#1e40af)';
    var _IK='var(--pal-ink,#1c2942)';
    var _IK2='var(--pal-ink-2,#46587a)';
    ['.exp-card','.modal','.mode-card','.util-card','.ach-card2','.ach-total','.ach-bar',
     '.psw-cap','.psw-hero','.psw-ped','.psw-bar','.psw-pethalo','.scramble-cn','.moles-prompt',
     '.ms-item','.fs-item','.settings-textarea','.small-btn.gray','.match-back'].forEach(function(sel){
      css+=_L+sel+'{background:'+_SF+'!important;border:'+_BD+'!important;box-shadow:'+_SH+'!important;color:'+_IK+'!important}\n';
    });
    css+=_L+'.exp-card .word{color:'+_IK+'!important}\n';
    css+=_L+'.exp-card .cn{color:'+_IK2+'!important}\n';
    css+=_L+'.cat-title{color:#4338ca!important}\n';
    css+=_L+'.cat-progress,'+_L+'.section-label,'+_L+'.st,'+_L+'.psw-sub,'+_L+'.pet-text{color:'+_IK2+'!important}\n';
    css+=_L+'.ach-tier,'+_L+'.pet-stage,'+_L+'.rsb{color:'+_IK+'!important}\n';
    css+=_L+'.exp-card.learned{background:linear-gradient(135deg,#f0fdf4,#dcfce7)!important;border:1px solid #22c55e!important}\n';
    css+=_L+'.exp-card.learned .word,'+_L+'.exp-card.learned .cn{color:#14532d!important}\n';
    css+=_L+'.modal .m-word{color:'+_IK+'!important}\n';
    css+=_L+'.modal .m-pn{color:#4338ca!important}\n';
    css+=_L+'.modal .m-cn{color:'+_AM+'!important}\n';
    css+=_L+'.modal .m-ex{color:'+_IK+'!important}\n';
    css+=_L+'.modal .m-excn{color:'+_AM+'!important}\n';
    css+=_L+'.modal .close{background:#ef4444!important;color:#fff!important;border-color:#dc2626!important}\n';
    css+=_L+'.m-btn,'+_L+'.game-btn,'+_L+'.back-btn,'+_L+'.danger-btn{color:#fff!important;text-shadow:0 1px 2px rgba(0,0,0,.35)!important}\n';
    css+=_L+'.m-btn.listen{background:linear-gradient(135deg,#6366f1,#4f46e5)!important;border:none!important}\n';
    css+=_L+'.m-btn.slow{background:linear-gradient(135deg,#14b8a6,#0f766e)!important;border:none!important}\n';
    css+=_L+'.m-btn.sentence{background:linear-gradient(135deg,#f59e0b,#d97706)!important;border:none!important}\n';
    css+=_L+'.m-btn.got-it{background:linear-gradient(135deg,#22c55e,#16a34a)!important;border:none!important}\n';
    css+=_L+'.back-btn{background:linear-gradient(135deg,#6366f1,#4338ca)!important;border:none!important}\n';

    css+=_L+'.hbafx-entry b{color:#5b21b6!important}\n';
    css+=_L+'.hbafx-entry span{color:#6d28d9!important}\n';

    css+=_L+'[style*="color:#cbd5e1"],'+_L+'[style*="color:#e2e8f0"],'+_L+'[style*="color:#94a3b8"]{color:'+_IK+'!important}\n';

    css+=_L+'.d-label.boss-card-label{text-shadow:0 1px 3px rgba(0,0,0,.95),0 0 7px rgba(0,0,0,.75),0 0 2px rgba(0,0,0,.9)!important}\n';
    css+=_L+'.top-name{color:'+_AM+'!important;text-shadow:none!important}\n';
    css+=_L+'.ni-label{color:'+_AM+'!important;text-shadow:none!important}\n';
    css+=_L+'.m-title,'+_L+'.d-label{color:'+_IK+'!important;text-shadow:none!important}\n';

    css+=_L+'.ach-name2,'+_L+'.ach-bar-name,'+_L+'.u-label,'+_L+'.nm,'+_L+'.d-label,'+_L+'.rt{color:'+_IK+'!important;text-shadow:none!important}\n';
    css+=_L+'.ach-desc2{color:'+_IK2+'!important}\n';

    css+=_L+'.m-btn.slow{background:linear-gradient(135deg,#0f766e,#115e59)!important}\n';
    css+=_L+'.m-btn.sentence{background:linear-gradient(135deg,#b45309,#92400e)!important}\n';
    css+=_L+'.m-btn.got-it{background:linear-gradient(135deg,#16a34a,#15803d)!important}\n';
    css+=_L+'.game-btn{background:linear-gradient(135deg,#4f46e5,#4338ca)!important}\n';

    css+=_LS+'.htm-complete,'+_LS+'.htm-complete *{color:#334155!important}\n';
    css+=_LS+'.htm-complete h2{color:var(--pal-accent-text,#1e40af)!important;text-shadow:none!important}\n';
    css+=_LS+'.htm-complete p,'+_LS+'.htm-complete p *{color:#475569!important;text-shadow:none!important}\n';
    css+=_LS+'.htm-complete p b,'+_LS+'.htm-complete p strong{color:#0f172a!important}\n';
    css+=_LS+'.htm-complete button{color:#fff!important}\n';
    css+=_LS+'.htm-focus-head{color:#0f172a!important;text-shadow:none!important}\n';
    css+=_LS+'.htm-rule{color:#475569!important}\n';
    css+=_LS+'.htm-pause{color:#0f172a!important}\n';
    css+=_LS+'.htm-focus-feedback{color:var(--pal-accent-text,#1e40af)!important;text-shadow:none!important}\n';
    css+=_LS+'.htm-focus-setup,'+_LS+'.htm-focus-setup *{color:#334155!important}\n';
    css+=_LS+'#typingContent [style*="color:#fff"]:not([style*="linear-gradient"]){color:#0f172a!important}\n';
    css+=_LS+'#typingContent [style*="color:#cbd5e1"]{color:#475569!important}\n';
    css+=_LS+'#typingContent [style*="color:#fde047"],'+_LS+'#typingContent [style*="color:#fde68a"]{color:var(--pal-accent-text,#1e40af)!important}\n';

    css+=_L+'#hr_rvrw_card{background:linear-gradient(135deg,#78350f,#92400e)!important;border-color:#f59e0b!important;color:#fde68a!important}\n';
    css+=_L+'#hr_rvrw_card, '+_L+'#hr_rvrw_card *{--pal-ink:#fef3c7;--pal-ink-hi:#fde68a;--pal-ink-2:#fcd34d;--pal-ink-3:#e7cfa0;--pal-accent-text:#fbbf24}\n';
    ['#fbbf24','#fde047','#fde68a','#facc15','#fcd34d'].forEach(function(gold){
      css+=_L+'#hr_rvrw_card [style*="color:'+gold+'"]{color:'+gold+'!important}\n';
    });
    css+=_L+'#hr_rvrw_card [style*="color:#34d399"]{color:#34d399!important}\n';
    css+=_L+'#hr_rvrw_card [style*="color:#64748b"]{color:#e7cfa0!important}\n';
    css+=_L+'#hr_rvrw_card [style*="color:#c4b5fd"]{color:#f3e8ff!important}\n';
    css+=_L+'#hr_rvrw_card [style*="color:#a5b4fc"]{color:#e0e7ff!important}\n';
    css+=_L+'#hr_rvrw_card [style*="color:#cbd5e1"]{color:#fde68a!important}\n';
    css+=_L+'#hr_rvrw_card [style*="color:#e2e8f0"]{color:#fef3c7!important}\n';
    css+=_L+'#hr_rvrw_card [style*="color:#fff"]{color:#fff!important}\n';

    css+=_L+'.ach-total,'+_L+'.ach-total *{color:#334155!important}\n';
    ['#fbbf24','#fde047','#fde68a','#facc15','#fcd34d'].forEach(function(gold){
      css+=_L+'.ach-total [style*="color:'+gold+'"]{color:var(--pal-accent-text,#1e40af)!important}\n';
    });

    css+=_L+'.ach-prog-txt{color:#1d4ed8!important}\n';

    css+=_L+'#petScreen .psw-nmrow,'+_L+'#petScreen .psw-nmrow *{color:#334155!important}\n';
    css+=_L+'.psw-hero .sg{color:var(--pal-accent-text,#1e40af)!important}\n';
    css+=_L+'.psw-hero .qt,'+_L+'.psw-barlab{color:#475569!important}\n';
    css+=_L+'.psw-barlab b{color:#1c2942!important}\n';
    css+=_L+'.lkk{color:#334155!important}\n';

    css+=_L+'[style*="background:#1e1b4b"] [style*="color:#cbd5e1"],'+_L+'[style*="background: #1e1b4b"] [style*="color:#cbd5e1"]{color:#e2e8f0!important}\n';

    css+=_L+'[style*="linear-gradient(135deg,#7f1d1d"] [style*="color:#fde047"],'+_L+'[style*="linear-gradient(135deg,#7f1d1d"] [style*="color:#fbbf24"]{color:#fde047!important}\n';

    css+=_L+'#hsnBossThemePicker [style*="color:#fff"]{color:#fff!important}\n';

    css+=_L+'#themeBox [style*="color:#fbbf24"],'+_L+'#themeBox [style*="color:#fde047"]{color:#fbbf24!important}\n';

    css+=_L+'[style*="linear-gradient(135deg,#1e1b4b"] [style*="color:#cbd5e1"]{color:#e2e8f0!important}\n';

    css+=_L+'#themeBox [style*="color:#fff"]{color:#fff!important}\n';

    css+=_L+'[style*="linear-gradient(90deg,#fbbf24"] [style*="color:#fef3c7"]{color:#0f172a!important}\n';

    css+=_L+'[style*="linear-gradient(135deg,#1e1b4b"] [style*="background:#0f172a"],'+_L+'[style*="background:#1e1b4b"] [style*="background:#0f172a"]{background:#0f172a!important}\n';
    css+=_L+'[style*="linear-gradient(135deg,#1e1b4b"] [style*="background:#1e293b"],'+_L+'[style*="background:#1e1b4b"] [style*="background:#1e293b"]{background:#1e293b!important}\n';

    css+=_L+'[style*="linear-gradient(135deg,#7f1d1d"] [style*="color:#cbd5e1"]{color:#e2e8f0!important}\n';

    css+=_L+'[style*="background:linear-gradient"][style*="#fbbf24"] [style*="color:#fef3c7"]{color:#0f172a!important}\n';

    css+=_L+'.hr_btm_hint{color:#cbd5e1!important}\n';

    css+=_L+'#cardsScreen [style*="color:#475569"]{color:#1f2937!important}\n';

    css+=_L+'#hr_today{background:linear-gradient(180deg,#f8fafc 0%,#eef2ff 60%,#e0e7ff 100%)!important}\n';
    css+=_L+'#hr_today, '+_L+'#hr_today *{--pal-ink:#0f172a;--pal-ink-hi:#020617;--pal-ink-2:#334155;--pal-ink-3:#64748b}\n';
    css+=_L+'#hr_today [style*="color:#fff"]{color:#0f172a!important}\n';
    css+=_L+'#hr_today [style*="color:#cbd5e1"]{color:#334155!important}\n';
    css+=_L+'#hr_today [style*="color:#94a3b8"]{color:#475569!important}\n';
    css+=_L+'#hr_today [style*="color:#fbbf24"],'+_L+'#hr_today [style*="color:#fde047"],'+_L+'#hr_today [style*="color:#fde68a"]{color:var(--pal-accent-text,#1e40af)!important}\n';
    css+=_L+'#hr_today [style*="color:#34d399"]{color:#065f46!important}\n';
    css+=_L+'#hr_today [style*="rgba(255,255,255,.55)"],'+_L+'#hr_today [style*="rgba(255,255,255,.6)"]{color:#475569!important}\n';
    css+=_L+'#hr_today .ht_prog{color:var(--pal-accent-text,#1e40af)!important}\n';
    css+=_L+'#hr_today .ht_top{color:#0f172a!important}\n';
    css+=_L+'#hr_today .ht_top button{background:rgba(15,23,42,.08)!important;color:#334155!important}\n';
    css+=_L+'#hr_today .ht_bar{background:rgba(15,23,42,.12)!important}\n';

    css+=_L+'#hr_today[style*="linear-gradient(180deg,#7c2d12"]{background:linear-gradient(180deg,#fff7ed 0%,#fef3c7 55%,#eef2ff 100%)!important}\n';

    ['#hr_center','#hr_flashcard'].forEach(function(ov){
      css+=_L+ov+'{background:linear-gradient(180deg,#f8fafc 0%,#eef2ff 60%,#e0e7ff 100%)!important}\n';
      css+=_L+ov+', '+_L+ov+' *{--pal-ink:#0f172a;--pal-ink-hi:#020617;--pal-ink-2:#334155;--pal-ink-3:#64748b}\n';

      css+=_L+ov+' .hr_title,'+_L+ov+' .hr_wb_title{color:var(--pal-accent-text,#1e40af)!important}\n';
      css+=_L+ov+' .hr_sub,'+_L+ov+' .hr_wb_intro,'+_L+ov+' .lbl,'+_L+ov+' .hr_fc_progress{color:#475569!important}\n';
      css+=_L+ov+' .hr_section_title,'+_L+ov+' .hr_back,'+_L+ov+' .hr_wb_back{color:#334155!important}\n';
      css+=_L+ov+' .num{color:var(--pal-accent-text,#1e40af)!important}\n';
      css+=_L+ov+' .hr_btm_hint{color:#64748b!important}\n';

      css+=_L+ov+' .hr_card,'+_L+ov+' .hr_card *{color:#fff!important}\n';
      css+=_L+ov+' .hr_card .hr_card_cn{color:#fde047!important}\n';
      css+=_L+ov+' .hr_card .hr_card_tap_hint{color:rgba(255,255,255,.75)!important}\n';
      css+=_L+ov+' .hr_badge,'+_L+ov+' .hr_red_dot{color:#fff!important}\n';
      css+=_L+ov+' .hr_cal_m{color:#fff!important}\n';
      css+=_L+ov+' .hr_desc{color:rgba(255,255,255,.85)!important}\n';
      css+=_L+ov+' .hr_fc_top{color:#0f172a!important}\n';
      css+=_L+ov+' .hr_wb_item,'+_L+ov+' .hr_wb_count{color:#0f172a!important}\n';
      css+=_L+ov+' .hr_wb_cn{color:var(--pal-accent-text,#1e40af)!important}\n';

      css+=_L+ov+' [style*="background:rgba(255,255,255,.08)"],'+_L+ov+' [style*="background:rgba(255,255,255,.12)"]{background:rgba(15,23,42,.07)!important}\n';

      css+=_L+ov+' .hr_stat{background:rgba(255,255,255,.75)!important;border-color:rgba(15,23,42,.10)!important}\n';

      css+=_L+ov+' .hr_cal_d{color:#1c1c1e!important}\n';

      css+=_L+ov+' .hr_stat .num{color:var(--pal-accent-text,#1e40af)!important;text-shadow:none!important}\n';
      css+=_L+ov+' .hr_stat .lbl{color:#475569!important}\n';
    });

    css+=_L+'#hsn-ml{background:linear-gradient(180deg,#f8fafc 0%,#eef2ff 55%,#e0e7ff 100%)!important}\n';
    css+=_L+'#hsn-ml, '+_L+'#hsn-ml *{--pal-ink:#0f172a;--pal-ink-hi:#020617;--pal-ink-2:#334155;--pal-ink-3:#64748b}\n';

    css+=_L+'#hsn-ml .hsn-ml-title{color:#0f172a!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-sec{color:#334155!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-empty{color:#64748b!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-foot,'+_L+'#hsn-ml .cnt{color:#4338ca!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-back{background:rgba(15,23,42,.08)!important;color:#334155!important}\n';

    css+=_L+'#hsn-ml .hsn-ml-isl{background:rgba(255,255,255,.75)!important;border-color:rgba(15,23,42,.10)!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-isl .nm{color:#0f172a!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-isl .ago{color:#64748b!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-isl .row2,'+_L+'#hsn-ml .hsn-ml-isl .l{color:#475569!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-isl .v{color:#0f172a!important}\n';
    css+=_L+'#hsn-ml .hsn-ml-bar{background:rgba(15,23,42,.12)!important}\n';

    css+=_L+'#hsn-ml [style*="linear-gradient(135deg,#1e293b,#312e81)"] *,'+_L+'#hsn-ml [style*="linear-gradient(135deg,#064e3b,#065f46)"] *,'+_L+'#hsn-ml [style*="linear-gradient(135deg,#7c2d12,#9a3412)"] *{color:#fff!important}\n';
    css+=_L+'#hsn-ml [style*="linear-gradient(135deg,#1e293b,#312e81)"] .hsn-ml-bignum{color:#fde047!important}\n';
    css+=_L+'#hsn-ml [style*="linear-gradient(135deg,#1e293b,#312e81)"] .hsn-ml-biglbl{color:#cbd5e1!important}\n';

    css+=_L+'.boss-opt{background:linear-gradient(135deg,#ffffff,#f1f5f9)!important;border-color:#94a3b8!important;color:#0f172a!important}\n';

    css+=_L+'.boss-opt.correct{background:linear-gradient(135deg,#dcfce7,#bbf7d0)!important;border-color:#16a34a!important;color:#14532d!important}\n';

    css+=_L+'.boss-opt.wrong{background:linear-gradient(135deg,#fee2e2,#fecaca)!important;border-color:#dc2626!important;color:#7f1d1d!important}/*HSN-RED-OK 答错语义*/\n';

    var _LS='html[class*="hsn-pal-"].hsn-pal-light ';
    css+=_LS+'[style*="linear-gradient"][style*="color:#fff"]{color:#fff!important;text-shadow:0 1px 2px rgba(0,0,0,.25)!important}\n';
    css+=_LS+'[style*="linear-gradient"][style*="color:#fff"] *{color:#fff!important}\n';

    css+=_L+'#spQ > [style*="color:#fff"]{color:#0f172a!important}\n';

    css+=_LS+'.bubble{color:#fff!important;text-shadow:0 2px 5px rgba(0,0,0,.55),0 0 2px rgba(0,0,0,.4)!important}\n';

    css+=_LS+'.bubble-stats .bs-item{background:#ffffff!important;border:1px solid rgba(15,23,42,.10)!important;color:#334155!important;box-shadow:0 2px 6px rgba(15,23,42,.08)!important}\n';

    css+=_LS+'.bubble-stats .bs-item:not(#bbLvlBadge) *{color:#334155!important;text-shadow:none!important}\n';
    css+=_LS+'.bubble-stats .bs-item b{color:var(--pal-accent-text,#1e40af)!important}\n';

    css+=_LS+'#bbLvlBadge{color:#fff!important;border-color:transparent!important;box-shadow:0 2px 8px rgba(220,38,38,.28)!important}\n';

    css+=_LS+'.bubble-area{background:linear-gradient(180deg,#38bdf8 0%,#0ea5e9 45%,#0284c7 100%)!important;box-shadow:0 6px 20px rgba(2,132,199,.18)!important}\n';

    css+=_LS+'.bubble-prompt{background:rgba(255,255,255,.96)!important;color:#0f172a!important;box-shadow:0 4px 16px rgba(15,23,42,.18)!important}\n';
    css+=_LS+'.bubble-prompt *{color:#0f172a!important}\n';

    css+=_LS+'.cloze-sentence{background:#ffffff!important;border:1px solid rgba(15,23,42,.10)!important;color:#0f172a!important;box-shadow:0 3px 10px rgba(15,23,42,.08)!important}\n';
    css+=_LS+'.cloze-sentence *{color:#0f172a!important}\n';

    css+=_LS+'.cloze-sentence .cloze-blank{color:#1e3a8a!important;border-bottom-color:#f59e0b!important}\n';

    css+=_LS+'.cloze-cn{color:#334155!important}\n';
    css+=_LS+'.cloze-cn [style*="color:#fbbf24"]{color:#1e3a8a!important;background:linear-gradient(180deg,transparent 52%,#fde68a 52%)!important;padding:0 4px!important;border-radius:3px!important;font-weight:900!important}\n';

    css+=_LS+'.cloze-opt.correct{background:linear-gradient(135deg,#dcfce7,#bbf7d0)!important;border-color:#16a34a!important;color:#14532d!important}\n';
    css+=_LS+'.cloze-opt.wrong{background:linear-gradient(135deg,#fee2e2,#fecaca)!important;border-color:#dc2626!important;color:#7f1d1d!important}/*HSN-RED-OK 答错语义*/\n';

    css+=_LS+'#clozeContent [style*="color:#cbd5e1"]{color:#475569!important}\n';

    css+=_LS+'#clozeContent [style*="color:#fbbf24"]:not(.cloze-blank):not(.cloze-cn *){color:var(--pal-accent-text,#1e40af)!important}\n';
css+=_L+'#hr_toast, '+_L+'#hr_toast *,'+_L+'#hr_empty_msg, '+_L+'#hr_empty_msg *,'+_L+'#hr_to_sub_mask, '+_L+'#hr_to_sub_mask *{--pal-ink:#f1f5f9;--pal-ink-hi:#fff;--pal-ink-2:#cbd5e1;--pal-ink-3:#94a3b8;--pal-accent-text:#fbbf24}\n';

    css+=_L+'#hsp_mask{background:linear-gradient(180deg,#f8fafc 0%,#eef2ff 55%,#e0e7ff 100%)!important}\n';
    css+=_L+'#hsp_mask, '+_L+'#hsp_mask *{--pal-ink:#0f172a;--pal-ink-hi:#020617;--pal-ink-2:#334155;--pal-ink-3:#64748b}\n';

    css+=_L+'#hsp_mask [style*="color:#fff"],'+_L+'#hsp_mask [style*="color:#ffffff"]{color:#0f172a!important}\n';
    css+=_L+'#hsp_mask [style*="color:#cbd5e1"]{color:#334155!important}\n';
    css+=_L+'#hsp_mask [style*="color:#94a3b8"]{color:#64748b!important}\n';

    css+=_L+'#hsp_mask #hspSlots > *{color:#0f172a!important;border-bottom-color:#475569!important}\n';

    css+=_L+'#hsp_mask #hspCloseBtn{background:rgba(15,23,42,0.10)!important;color:#0f172a!important}\n';
    css+=_L+'#hsp_mask #hspSkipBtn{background:rgba(15,23,42,0.08)!important;color:#334155!important}\n';

    css+=_L+'#hsp_mask #hspSpeakBtn{background:#fff!important;color:#0f172a!important;border:1px solid rgba(15,23,42,.12)!important}\n';

    css+=_L+'#hsp_mask #hspKbd button,'+_L+'#hsp_mask #hspKbd [role="button"]{color:#0f172a!important}\n';

    css+=_L+'#hsp_mask #hspDoneBtn{color:#1e293b!important}\n';

    css+=_L+'#hsp_mask [style*="rgba(15,23,42,0.5)"],'+_L+'#hsp_mask [style*="rgba(15,23,42,0.6)"]{background:rgba(255,255,255,0.75)!important}\n';

    css+=_L+'.d-label{color:#fff!important;text-shadow:0 2px 6px rgba(0,0,0,.85),0 0 3px rgba(0,0,0,.9)!important}\n';

    css+=_L+'.d-label.boss-card-label{text-shadow:none!important}\n';
    css+=_L+'[style*="color:#e9d5ff"],'+_L+'[style*="color:#a78bfa"],'+_L+'[style*="color:#c4b5fd"],'+_L+'[style*="color:#ddd6fe"]{color:#5b21b6!important}\n';
    css+=_L+'.stat-card,'+_L+'.stats-card,'+_L+'.st-card{background:'+_SF+'!important;border:'+_BD+'!important;color:'+_IK+'!important}\n';

    var st=document.createElement('style'); st.id='hsnPaletteCSS'; st.textContent=css;
    (document.head||document.documentElement).appendChild(st);
  }

  function apply(id, silent){
    var p=byId(id); var el=document.documentElement;
    var cur=(el.className||'').split(/\s+/).filter(function(c){return c.indexOf('hsn-pal-')!==0;});
    if(!p.isDefault){ cur.push('hsn-pal-'+p.id); if(p.light) cur.push('hsn-pal-light'); }
    el.className=cur.join(' ').replace(/\s+/g,' ').replace(/^\s|\s$/g,'');
    try{ localStorage.setItem(KEY, p.id); }catch(e){}
    refreshPicker();
    if(!silent){ try{ if(typeof window.showToast==='function') window.showToast('🎨 已切换配色: '+p.emoji+' '+p.name); }catch(e){} }
  }
  window.hansenApplyPalette=apply;

  function current(){ var c=''; try{ c=localStorage.getItem(KEY)||''; }catch(e){} return byId(c).id; }

  function swatchBg(p){
    if(p.isDefault) return 'linear-gradient(135deg,#1a2660,#0c1538)';
    return 'linear-gradient(135deg,'+p.vars.c2+','+p.vars.mid+' 55%,'+p.vars.deep+')';
  }
  function ensurePicker(){
    var sc=document.getElementById('settingsContent');
    if(!sc || document.getElementById('hsnPalPicker')) return;
    var cur=current();
    var h='<div class="settings-section" id="hsnPalPicker">'
      +'<h3 style="margin:0 0 4px">🎨 整体配色</h3>'
      +'<div style="font-size:12px;color:var(--pal-ink-3,#94a3b8);margin-bottom:10px">整个游戏换个颜色 · 全部免费 · 全岛通用</div>'
      +'<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px">';
    for(var i=0;i<PALETTES.length;i++){
      var p=PALETTES[i]; var on=(p.id===cur);
      h+='<div class="hsn-pal-sw" data-pal="'+p.id+'" onclick="hansenApplyPalette(\''+p.id+'\')" style="cursor:pointer;text-align:center;-webkit-tap-highlight-color:transparent">'
        +'<div style="position:relative;width:46px;height:46px;margin:0 auto 5px;border-radius:50%;background:'+swatchBg(p)+';border:'+(on?'3px solid #fbbf24':'2px solid rgba(var(--pal-line-rgb,99,102,241),.45)')+';box-shadow:0 3px 10px rgba(0,0,0,.22)">'
        +'<span style="position:absolute;top:-2px;right:-4px;font-size:15px">'+(on?'✅':'')+'</span>'
        +'<span style="position:absolute;left:0;right:0;top:11px;font-size:17px;line-height:1">'+p.emoji+'</span>'
        +'</div>'
        +'<div style="font-size:11.5px;font-weight:800;color:'+(on?'#fbbf24':'var(--pal-ink-2,#cbd5e1)')+'">'+p.name+(p.isDefault?'<span style="font-weight:600;opacity:.75">(默认)</span>':'')+'</div>'
        +'</div>';
    }
    h+='</div></div>';
    var d=document.createElement('div'); d.innerHTML=h;
    sc.insertBefore(d.firstChild, sc.firstChild);
  }
  function refreshPicker(){
    var pk=document.getElementById('hsnPalPicker');
    if(!pk) return;
    pk.parentNode.removeChild(pk);
    ensurePicker();
  }

  buildCSS();
  apply(current(), true);

  var _wrapT=setInterval(function(){
    if(typeof window.renderSettings==='function' && !window.renderSettings.__hsnPal){
      var _o=window.renderSettings;
      window.renderSettings=function(){ var r=_o.apply(this,arguments); try{ensurePicker();}catch(e){} return r; };
      window.renderSettings.__hsnPal=true;
      clearInterval(_wrapT);
    }
  }, 250);
  setTimeout(function(){ clearInterval(_wrapT); }, 15000);
  if(document.readyState!=='loading') ensurePicker();
  else document.addEventListener('DOMContentLoaded', function(){ ensurePicker(); });

  function _hsnPalSync(){ try{ apply(current(), true); }catch(e){} }
  try{ window.addEventListener('storage', function(e){ if(!e || e.key === KEY || e.key === null) _hsnPalSync(); }); }catch(e){}
  try{ window.addEventListener('pageshow', function(){ _hsnPalSync(); }); }catch(e){}
  try{ document.addEventListener('visibilitychange', function(){ if(document.visibilityState === 'visible') _hsnPalSync(); }); }catch(e){}
})();
