import { KV } from '.'

export interface ICallFunctionOptions {
  name: string
  data?: KV<any>
  query?: KV<any>
  search?: string
  parse?: boolean
  // Used for 云函数2.0 CallContainer
  type?: string
  method?: string
  path?: string
  header?: KV<any>
}

export interface ICallFunctionResponse {
  requestId: string
  result: any
}

export type ICallFunction = (options: ICallFunctionOptions, callback?: Function) => Promise<ICallFunctionResponse>

export interface IRetryOptions {
  retries?: number
  factor?: number
  minTimeout?: number
  maxTimeout?: number
  randomize?: boolean
  timeouts?: number[]
  timeoutOps?: {
    timeout: number
    cb: function
  }
}

export interface ICustomReqOpts {
  timeout?: number
  retryOptions?: IRetryOptions
  from?: 'node-sdk'
}
