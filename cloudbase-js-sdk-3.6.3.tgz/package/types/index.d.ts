import { CloudbaseAdapter, SDKAdapterInterface, ResponseObject } from '@cloudbase/adapter-interface'
import { ICloudbaseComponent, ICloudbaseHook } from './component'
import { ICloudbaseRequest } from './request'
import { ICloudbaseCache } from './cache'
import { ICloudbaseAuth } from './auth'
import { ICallFunctionOptions, ICallFunctionResponse } from './functions'
import {
  ICloudbaseUploadFileParams,
  ICloudbaseUploadFileResult,
  ICloudbaseDeleteFileParams,
  ICloudbaseDeleteFileResult,
  ICloudbaseGetTempFileURLParams,
  ICloudbaseGetTempFileURLResult,
  ICloudbaseDownloadFileParams,
  ICloudbaseDownloadFileResult,
  ICloudbaseCopyFileParams,
  ICloudbaseCopyFileResult,
} from './storage'
import { cloudbase } from '../cloudbase/index'

export enum LANGS {
  ZH = 'zh-CN',
  EN = 'en-US',
}

export type Persistence = 'local' | 'session' | 'none'

export interface KV<T> {
  [key: string]: T
}

export interface KVstring {
  [key: string]: string
}

export type EndPointKey = 'CLOUD_API' | 'GATEWAY'

/** 自定义登录凭证信息（从控制台下载的私钥文件） */
export interface ICredentialsInfo {
  /** 私钥 ID */
  private_key_id: string;
  /** RSA 私钥内容 */
  private_key: string;
  /** 所属环境 ID */
  env_id: string;
}

export interface ICloudbaseConfig {
  env: string
  intl?: boolean,
  region?: string
  timeout?: number
  persistence?: Persistence
  oauthClient?: any
  debug?: boolean
  _fromApp?: ICloudbase
  clientId?: string
  oauthInstance?: any
  wxCloud?: any
  i18n?: {
    t: (text: string) => string
    LANG_HEADER_KEY: string
    lang: LANGS
  }
  accessKey?: string
  endPointMode?: EndPointKey // auth请求域名模式，默认CLOUD_API
  useWxCloud?: boolean // 是否使用微信云开发链路
  auth?: {
    detectSessionInUrl?: boolean
    secretId?: string
    secretKey?: string
    sessionToken?: string
    secretType?: 'SESSION_SECRET' | 'SECRET'
    credentials?: ICredentialsInfo // 自定义登录私钥信息，node端使用
  }
  // @cloudbase/functions-framework 函数上下文，只要求部分字段，只在云函数或云托管中有效
  context?: Readonly<{
    eventID: string
    extendedContext?: {
      envId: string // 环境 ID
      // uin: string             // 请求的 UIN
      source: string // 请求来源，如 wx
      accessToken?: string // 调用请求时的 AccessToken
      userId?: string // 请求的用户 ID
      tmpSecret?: {
        // 临时凭证
        secretId: string // secretId
        secretKey: string // secretKey
        token: string // token
      }
    }
  }>
}
// 可更新的配置字段
export type ICloudbaseUpgradedConfig = Pick<ICloudbaseConfig, 'persistence' | 'region' | 'debug'>

export interface ICloudbaseExtension {
  name: string
  invoke: (opts: any, app: ICloudbase) => Promise<any>
}

declare type MethodType = 'request' | 'post' | 'get' | 'head' | 'patch' | 'delete' | 'put'
export interface ICloudbaseApis {
  [apiName: string]: {
    [method in MethodType]: (callApiOptions: ICallApiOptions, opts?: KV<any>) => Promise<ResponseObject['data']>
  }
}

export interface ICloudbase {
  config: ICloudbaseConfig
  platform: ICloudbasePlatformInfo
  cache: ICloudbaseCache
  request: ICloudbaseRequest
  oauthClient: any
  localCache: ICloudbaseCache
  authInstance?: ICloudbaseAuth
  oauthInstance?: any
  apis: ICloudbaseApis
  init: (config: ICloudbaseConfig & { lang?: LANGS }) => cloudbase.app
  updateConfig: (config: ICloudbaseUpgradedConfig) => void
  registerExtension: (ext: ICloudbaseExtension) => void
  invokeExtension: (name: string, opts: any) => Promise<any>
  useAdapters: (adapters: CloudbaseAdapter | CloudbaseAdapter[], options?: any) => void
  registerComponent: (component: ICloudbaseComponent) => void
  registerHook: (hook: ICloudbaseHook) => void
  registerVersion: (version: string) => void
  fire?: (...args: any[]) => void
  updateLang?: (lang: LANGS) => void
  /**
   * 检查当前 Cloudbase 实例是否已完成初始化
   * @returns 是否已初始化
   */
  isInitialized?: () => boolean
  getEndPointWithKey?: (key: EndPointKey) => {
    BASE_URL: string
    PROTOCOL: string
  }
  auth?: (options?: { persistence: cloudbase.auth.Persistence }) => cloudbase.auth.App

  // ---- 云函数 ----
  /** 调用云函数 */
  callFunction?: (options: ICallFunctionOptions, callback?: Function) => Promise<ICallFunctionResponse>

  // ---- 数据库 ----
  /** 获取数据库实例 */
  database?: (dbConfig?: { instance?: string; database?: string }) => cloudbase.database.App

  // ---- 云存储 ----
  /** Storage 命名空间实例（from 分流 + Bucket 管理） */
  storage?: cloudbase.storage.StorageClient
  /** 上传文件 */
  uploadFile?: (params: ICloudbaseUploadFileParams, callback?: Function) => Promise<ICloudbaseUploadFileResult>
  /** 下载文件 */
  downloadFile?: (params: ICloudbaseDownloadFileParams, callback?: Function) => Promise<ICloudbaseDownloadFileResult>
  /** 删除云端文件 */
  deleteFile?: (params: ICloudbaseDeleteFileParams, callback?: Function) => Promise<ICloudbaseDeleteFileResult>
  /** 获取文件临时下载链接 */
  getTempFileURL?: (params: ICloudbaseGetTempFileURLParams, callback?: Function) => Promise<ICloudbaseGetTempFileURLResult>
  /** 复制/移动文件 */
  copyFile?: (params: ICloudbaseCopyFileParams, callback?: Function) => Promise<ICloudbaseCopyFileResult>
}

/**
 * Node.js 端适配器扩展方法
 */
export interface INodeAdapterExtend {
  /**
   * 从环境变量中获取腾讯云临时密钥信息
   * 用于 API 请求签名
   */
  getSecretInfo?: (config?: ICloudbaseConfig) => {
    env: string
    secretId: string
    secretKey: string
    sessionToken: string
    accessKey: string
    secretType: string
  }
  /**
   * 初始化 Node.js 端工具方法，挂载到 js-sdk app 实例上
   * 包含：auth 相关方法、模板消息推送、context 解析
   */
  nodeTool?: (
    /** js-sdk cloudbase 实例 */
    app: any,
    /** 配置信息，包含认证凭证和环境 ID */
    config: ICloudbaseConfig,
  ) => void
}
export interface ICloudbasePlatformInfo {
  adapter?: SDKAdapterInterface & INodeAdapterExtend
  runtime?: string
}

export interface IGenericError<T extends string, P = any> extends Error {
  type: T
  payload: P
  generic: boolean
}

export interface ICallApiOptions {
  /** api标识 */
  name?: string
  /** 请求的path */
  path?: string
  method?: string
  headers?: KV<any>
  /** 请求体，根据content-type可以是不同类型 */
  body?: KV<any> | string
  token?: string
}
