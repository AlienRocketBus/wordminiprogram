import { KVstring } from '.'
import { ICustomReqOpts } from './functions'

export interface ICloudbaseUploadFileParams {
  cloudPath: string;
  filePath: string;
  method?: 'post' | 'put';
  headers?: KVstring;
  onUploadProgress?: Function;
  // 文件内容 Buffer 或 文件可读流, node端使用
  fileContent?: any;
  customReqOpts?: ICustomReqOpts;
}

export interface ICloudbaseUploadFileByPutParams {
  cloudPath: string;
  filePath: string;
  headers?: KVstring;
  onUploadProgress?: Function;
}

export interface ICloudbaseUploadFileResult {
  fileID: string;
  requestId: string;
}

export type ICloudbaseUploadFile = (params: ICloudbaseUploadFileParams, callback?: Function) => Promise<ICloudbaseUploadFileResult>;

export interface ICloudbaseGetUploadMetadataParams {
  cloudPath: string;
  customReqOpts?: ICustomReqOpts;
}

export type ICloudbaseGetUploadMetadata = (params: ICloudbaseGetUploadMetadataParams, callback?: Function) => Promise<any>;

export interface ICloudbaseDeleteFileParams {
  fileList: string[];
  customReqOpts?: ICustomReqOpts;
}

export type ICloudbaseDeleteFile = (params: ICloudbaseDeleteFileParams, callback?: Function) => Promise<ICloudbaseDeleteFileResult>;

export interface ICloudbaseDeleteFileResult {
  code?: string;
  message?: string;
  fileList?: {
    code?: string;
    fileID: string;
  }[];
  requestId?: string;
}

export interface ICloudbaseFileInfo {
  fileID: string;
  maxAge: number;
}

export interface ICloudbaseGetTempFileURLParams {
  fileList: string[] | ICloudbaseFileInfo[];
  customReqOpts?: ICustomReqOpts;
}
export interface ICloudbaseGetTempFileURLResult {
  code?: string;
  message?: string;
  fileList?: {
    code?: string;
    message?: string;
    fileID: string;
    tempFileURL: string;
    download_url?: string;
  }[];
  requestId?: string;
}

export interface ICloudbaseCopyFileParams {
  fileList: Array<{
    srcPath: string
    dstPath: string
    overwrite?: boolean
    removeOriginal?: boolean
  }>
  customReqOpts?: ICustomReqOpts;
}


export interface ICloudbaseCopyFileResult {
  fileList: Array<{
    fileId?: string
    code?: string
    message?: string
  }>
  requestId?: string;
}

export type ICloudbaseGetTempFileURL = (params: ICloudbaseGetTempFileURLParams, callback?: Function) => Promise<ICloudbaseGetTempFileURLResult>;

export interface ICloudbaseDownloadFileParams {
  fileID: string;
  tempFilePath?: string;
  customReqOpts?: ICustomReqOpts;
}

export interface ICloudbaseDownloadFileResult {
  code?: string;
  message?: string;
  fileContent?: any;
  requestId?: string;
}

export type ICloudbaseDownloadFile = (params: ICloudbaseDownloadFileParams, callback?: Function) => Promise<ICloudbaseDownloadFileResult>;

export interface ICloudbaseFileMetaData {
  url: string;
  token: string;
  authorization: string;
  fileId: string;
  cosFileId: string;
  download_url: string;
  code?: string;
  message?: string;
}

export interface ICloudbaseFileMetaDataRes {
  data: ICloudbaseFileMetaData;
  requestId: string;
}
