import { ICloudbaseConfig, KV, ICloudbase } from '.'
import { authModels, UserInfo } from '@cloudbase/oauth'
import { ICloudbaseEventEmitter } from './events'

export type ICloudbaseAuthConfig = Pick<
ICloudbaseConfig,
| 'env'
| 'clientId'
| 'region'
| 'persistence'
| 'debug'
| '_fromApp'
| 'oauthInstance'
| 'wxCloud'
| 'i18n'
| 'accessKey'
| 'useWxCloud'
| 'auth'
> &
ICloudbaseConfig['auth']
& {eventBus?: ICloudbaseEventEmitter}

export interface IAccessTokenInfo {
  accessToken: string
  env: string
}
export interface ICredential {
  // refreshToken: string;
  accessToken?: string
  accessTokenExpire?: string
}
export interface IAuthProvider {
  signInWithRedirect: () => any
}
export interface IUserInfo {
  uid?: string
  loginType?: string
  openid?: string
  wxOpenId?: string
  wxPublicId?: string
  unionId?: string
  qqMiniOpenId?: string
  customUserId?: string
  name?: string
  displayName?: string
  gender?: string
  email?: string
  username?: string
  hasPassword?: boolean
  location?: {
    country?: string
    province?: string
    city?: string
  }
  country?: string
  province?: string
  city?: string
}
export interface IUser extends IUserInfo {
  checkLocalInfo: () => void
  checkLocalInfoAsync: () => Promise<void>
  linkWithTicket?: (ticket: string) => Promise<void>
  linkWithRedirect?: (provider: IAuthProvider) => void
  getLinkedUidList?: () => Promise<{ hasPrimaryUid: boolean; users: IUserInfo[] }>
  setPrimaryUid?: (uid: string) => Promise<void>
  unlink?: (loginType: 'CUSTOM' | 'WECHAT-OPEN' | 'WECHAT-PUBLIC' | 'WECHAT-UNION') => Promise<void>
  update: (userinfo: authModels.UserProfile) => Promise<void>
  refresh: (params?: { version?: string }) => Promise<authModels.UserInfo>
}
export interface ILoginState {
  user: IUser
}
export interface ICloudbaseAuth {
  config: ICloudbaseConfig
  loginType: string
  weixinAuthProvider: any
  anonymousAuthProvider: any
  customAuthProvider: any
  getAccessToken: () => IAccessTokenInfo
  getLoginState: () => Promise<ILoginState | null>
  hasLoginState: () => Promise<ILoginState | null>
  getUserInfo: () => Promise<UserInfo & IUser>
  getAuthHeader: () => Promise<KV<string>>
  onLoginStateChanged: (callback: Function) => void
  onLoginStateExpired: (callback: Function) => void
  onAccessTokenRefreshed: (callback: Function) => void
  onAnonymousConverted: (callback: Function) => void
  onLoginTypeChanged: (callback: Function) => void
  shouldRefreshAccessToken: (hook: Function) => void
  /** 当前登录用户，未登录时为 null */
  currentUser: IUser | null
}

type IProvider = new (...args: any[]) => any

export interface ICloudbaseAuthModule {
  registerAuth: (app: ICloudbase) => void
  registerProvider: (name: string, provider: IProvider) => void
}
