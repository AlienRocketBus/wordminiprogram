import { CloudbaseAdapter } from '@cloudbase/adapter-interface';
import { ICloudbaseConfig, ICloudbaseUpgradedConfig, ICloudbase, ICloudbaseExtension, ICloudbasePlatformInfo, EndPointKey, ICloudbaseApis } from '@cloudbase/types';
import { ICloudbaseAuth } from '@cloudbase/types/auth';
import { ICloudbaseComponent, ICloudbaseHook } from '@cloudbase/types/component';
import { ICloudbaseCache } from '@cloudbase/types/cache';
import { ICloudbaseRequest } from '@cloudbase/types/request';
import { type ISetEndPointWithKey } from './constants/common';
import { LANGS } from './libs/lang';
export { getBaseEndPoint } from './constants/common';
export { LANGS } from './libs/lang';
declare class Cloudbase implements ICloudbase {
    authInstance: ICloudbaseAuth;
    oauthInstance: any;
    requestClient: any;
    oauthClient: any;
    version: string;
    auth: ICloudbase['auth'] & ICloudbaseAuth;
    apis: ICloudbaseApis;
    private cloudbaseConfig;
    constructor(config?: ICloudbaseConfig);
    get config(): ICloudbaseConfig;
    get platform(): ICloudbasePlatformInfo;
    get cache(): ICloudbaseCache;
    get localCache(): ICloudbaseCache;
    get request(): ICloudbaseRequest;
    init(config?: ICloudbaseConfig & {
        lang?: LANGS;
    }): Cloudbase;
    updateConfig(config: ICloudbaseUpgradedConfig): void;
    updateLang(lang: LANGS): void;
    registerExtension(ext: ICloudbaseExtension): void;
    invokeExtension(name: string, opts: any): any;
    useAdapters(adapters: CloudbaseAdapter | CloudbaseAdapter[], options?: any): void;
    registerHook(hook: ICloudbaseHook): void;
    registerComponent(component: ICloudbaseComponent): void;
    registerVersion(version: string): void;
    registerSdkName(name: string): void;
    isInitialized(config?: ICloudbaseConfig): boolean;
    registerEndPoint(url: string, protocol?: 'http' | 'https'): void;
    registerEndPointWithKey(props: ISetEndPointWithKey): void;
    registerHost(host: string, protocol?: 'http' | 'https'): void;
    getEndPointWithKey(key: EndPointKey): {
        BASE_URL: string;
        PROTOCOL: "https:" | "http:" | "http" | "https";
    };
    parseCaptcha(url: any): {
        error: string;
        error_description: string;
        state?: undefined;
        token?: undefined;
        captchaData?: undefined;
    } | {
        state: any;
        token: any;
        captchaData: any;
        error?: undefined;
        error_description?: undefined;
    };
    private useDefaultAdapter;
    private isNodeEnv;
    private formatTimeout;
    private try2InitAuth;
    private dealNodeAdapterConfig;
}
export type { Cloudbase };
export declare const cloudbase: ICloudbase;
export default cloudbase;
