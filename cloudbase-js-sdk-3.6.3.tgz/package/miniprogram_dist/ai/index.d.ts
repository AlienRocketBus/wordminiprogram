import type { SDKRequestInterface } from '@cloudbase/adapter-interface';
import type { ICloudbase, ICloudbaseConfig } from '@cloudbase/types';
import { AI } from './AI';
import { Bot } from './bot';
import * as models from './models';
import * as utils from './utils';
declare const restModels: {
    ZhiPuSimpleModel: typeof models.ZhiPuSimpleModel;
    HunYuanBetaSimpleModel: typeof models.HunYuanBetaSimpleModel;
    HunYuanSimpleModel: typeof models.HunYuanSimpleModel;
    ArkSimpleModel: typeof models.ArkSimpleModel;
    DSSimpleModel: typeof models.DSSimpleModel;
    YiSimpleModel: typeof models.YiSimpleModel;
    MoonshotSimpleModel: typeof models.MoonshotSimpleModel;
    HunYuanExpSimpleModel: typeof models.HunYuanExpSimpleModel;
    HunYuanOpenSimpleModel: typeof models.HunYuanOpenSimpleModel;
    DefaultSimpleModel: typeof models.DefaultSimpleModel;
    DefaultImageModel: typeof models.DefaultImageModel;
    ReactModel: typeof models.ReactModel;
    toolMap: Map<string, CallableFunction>;
};
interface IHandleRequestInstance {
    req: SDKRequestInterface;
}
type HandleRequestInstanceFunc = (options: IHandleRequestInstance) => SDKRequestInterface;
interface ICreateAI {
    req: SDKRequestInterface;
    baseUrl?: string;
    getBaseUrl?: () => string;
    env?: string;
    getAccessToken?: () => Promise<{
        accessToken: string;
    }>;
    handleReqInstance?: HandleRequestInstanceFunc;
    i18n?: ICloudbaseConfig['i18n'];
}
declare function createAI({ env, baseUrl, getBaseUrl: getBaseUrlFunc, req, getAccessToken, handleReqInstance, i18n }: ICreateAI): AI;
declare const createAi: typeof createAI;
declare function registerAi(app: ICloudbase): void;
export { AI, Bot, createAi, createAI, restModels as models, registerAi, utils };
export * from './type';
export * from './errors';
